<#
 Builds the solution, runs EACH test project separately, and verifies from the TRX result files that:
   1. every project reported at least the expected number of tests, with zero failures, and
   2. each named, security-critical test was discovered AND passed.
 Exit code 0 = everything verified. Non-zero = something is missing or failed.
#>
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

# Expected case counts (xUnit [Fact]s + [InlineData] rows). Update when tests are added.
$expected = [ordered]@{
    'SecureUSB.Cryptography.Tests' = 71
    'SecureUSB.Security.Tests'     = 105
    'SecureUSB.Storage.Tests'      = 176
    'SecureUSB.Core.Tests'         = 75
    'SecureUSB.ViewModels.Tests'   = 188
    'SecureUSB.UI.Tests'           = 33
}

# Security-critical tests that must exist and pass. Matched by method name (theory rows all must pass).
$required = [ordered]@{
    'Argon2id RFC 9106 vector'         = @('KonsciousArgon2id_MatchesRfc9106Vector')
    'Argon2id determinism/salt/unicode'= @('SameInputs_SameKey','DifferentSalt_DifferentKey','UnicodeNormalization_ComposedAndDecomposedMatch')
    'AES-256-GCM'                      = @('SealOpen_RoundTrips','Open_WrongKey_Fails','Open_WrongAad_Fails','Open_AnyBitFlip_Fails','Seal_UsesFreshNonceEveryTime')
    'Master key generation'            = @('EveryVault_HasUniqueIdSaltAndMasterKey','CreateThenUnlock_YieldsSameMasterKey','Unlock_WrongPassword_Throws')
    'Key wrap / unwrap'                = @('FileKeyWrap_RoundTrips','UnwrapWithWrongFileId_Fails','UnwrapWithAnotherVaultsKeys_Fails','TamperedWrappedFileKey_Fails')
    'Chunked encrypt/decrypt'          = @('RoundTrip_AcrossChunkBoundaries','RoundTrip_WithDefaultChunkSize','EndToEnd_PasswordToFile_SurvivesLockAndUnlock')
    'Tamper detection'                 = @('FlippingAnySingleByte_IsDetected','BitFlipInAnyAuthenticatedHeaderField_PreventsUnlock','TamperedKdfCost_PreventsUnlock','WrongFileId_Fails_PreventsSwappingBlobsBetweenFiles')
    'Truncation'                       = @('TruncationAtAnyPoint_IsDetected','TruncationExactlyAtChunkBoundary_IsDetected')
    'Reordering / duplication'         = @('ReorderedChunks_AreDetected','DuplicatedChunk_IsDetected')
    'Appending'                        = @('AppendedData_IsDetected')
    'Password change'                  = @('ChangePassword_KeepsMasterKey_NewPasswordWorks_OldFails','ChangePassword_WrongCurrentPassword_Throws_AndOriginalHeaderStillWorks','ChangePassword_CanRaiseKdfCost')
    'Password policy'                  = @('WeakPasswords_AreRejected','StrongPasswords_AreAccepted')
    'STEP2 atomic writes'              = @('AtomicWrite_CreatesAndReplaces_WithoutLeavingTemp','AtomicWrite_Failure_LeavesOriginalIntact')
    'STEP2 header backup and crashes'  = @('Commit_ReplacesPrimaryAndBackup_AndOldPasswordStopsWorking','Crash_AfterTempWritten_KeepsOldHeader_AndHealRemovesTemp','Crash_BetweenDeleteAndRename_UsesPendingTemp','StructurallyDamagedPrimary_FallsBackToBackup')
    'STEP2 encrypted index'            = @('IndexFile_ContainsNoReadableNames','EveryBitFlip_IsRejected','EveryTruncation_IsRejected','Crash_AfterOldMovedToPrev_PrimaryMissing_TempIsRecovered','CorruptPrimary_FallsBackToPrevious_AndHealRestoresPrimary')
    'STEP2 encrypted blobs'            = @('BlobFile_ContainsNoPlaintext_AndHasRandomName','EverySingleByteFlip_IsDetected','EveryTruncation_IsDetected','BlobSwappedBetweenFiles_IsDetected')
    'STEP2 interrupted writes / USB removal' = @('SourceFailure_MidWrite_LeavesNoTempFile','SourceFailureMidAdd_LeavesNoTraceAndVaultStaysUsable','IndexSaveFailure_RollsBack_AndRemovesTheNewBlob','Preflight_DriveRemoved_FailsCleanly','Open_RemovesUnfinishedBlobWrites','Open_RecoversNewerIndexLeftInTempFile','LockedKeys_StopAllOperations')
    'STEP2 drive capacity'             = @('SystemDriveInfo_ReportsRealCapacity','StorageUsage_SeparatesPhysicalVaultApplicationAndOther','Fat32_HasFourGibFileLimit','Preflight_RefusesWhenDriveIsTooFull')
    'STEP2 integrity scanner / repair' = @('HealthyVault_IsCleanShallowAndDeep','Scanner_DeepScanFindsSameSizeCorruption_ShallowDoesNot','Scanner_FindsMissingBlob_AndRepairCanRemoveTheEntry','CorruptPrimaryIndex_FallsBackToPrevious_ThenOrphanIsRecovered','LostIndex_RequiresExplicitRecovery_AndDataComesBack','Repair_NeverDeletesFilesOutsideTheVault','Scanner_DetectsAndRepairsHeaderProblems')
    'STEP2 end to end'                 = @('AddedFile_SurvivesLockAndUnlockWithThePassword','NothingReadableIsWrittenToTheUsb_NeitherContentNorNames','ExportOfTamperedBlob_FailsAndLeavesNoPlaintextBehind','SecondInstance_CannotOpenTheSameVault','ParallelAdds_AreSerialisedSafely')
    'STEP3 attempt counter / delays'   = @('DelaysGrowProgressively_AndStopAtThirtyMinutes','Counter_SurvivesRestart','AnySingleByteChange_IsDetected','ClockMovedBackwards_DoesNotShortenTheDelay','KnownLimitation_DeletingTheFileResetsTheCounter')
    'STEP3 filename and path sanitizer' = @('KnownInputs_ProduceTheExpectedSafeName','RandomHostileInput_AlwaysYieldsAValidSeparatorFreeName','CombineInsideDirectory_AlwaysProducesAChildOfTheDirectory','FolderPaths_AreNormalisedAndTraversalIsDropped')
    'STEP3 temporary files'            = @('CleanupAll_RemovesEverything_IncludingFilesOtherProgramsCreated','HostileNames_CannotEscapeTheSessionDirectory','WriterFailure_WipesThePartialFile','SweepStale_RemovesSessionsAbandonedByACrashedRun','SweepStale_NeverTouchesLiveSessionsOrForeignFolders','Dispose_RemovesTheWholeSessionDirectory_AndRefusesNewFiles')
    'STEP3 encrypted activity log'     = @('LogFile_ContainsNoReadableText','ModifiedRecord_IsDetected','RemovedMiddleRecord_IsDetected','ReorderedRecords_AreDetected','HalfWrittenLastRecord_IsDetected_AndRepairedOnNextAppend','BigLog_IsCompacted_KeepingTheNewestEvents')
    'STEP3 USB monitor'                = @('Removal_RaisesTheEventExactlyOnce_AndStaysLatched','MissingLockFile_MeansADifferentStickOrAWipedDrive','BackgroundTimer_DetectsRemoval')
    'STEP3 vault service: create/unlock/lock' = @('CreateVault_RejectsWeakAndMismatchedPasswords_AndCreatesNothing','UnlockWithTheOnePassword_RestoresFilesAndContent','ProgressiveDelays_BlockEvenTheCorrectPassword_UntilTheyExpire','Lockout_SurvivesRestartingTheApplication','SecondInstance_IsToldTheVaultIsInUse_AndLeavesTheFirstOnesTempFilesAlone','Dispose_LocksWipesAndRefusesFurtherUse')
    'STEP3 vault service: recovery'    = @('BitRotInTheHeader_OffersTheBackup_ThenRecovers','LostIndex_IsReportedWithoutPunishingTheUser_AndCanBeRebuilt','StartupSweep_RemovesDecryptedLeftoversOfACrashedRun')
    'STEP3 vault service: file operations' = @('TheVaultsOwnFiles_CannotBeAdded','AFolderContainingTheVault_CannotBeAdded','Export_WritesInsideTheChosenFolder_AndProtectsExistingFiles','TemporaryCopy_IsDecrypted_AndWipedWhenTheVaultLocks','ActivityLog_RecordsWhatTheUserDid_AndSurvivesLocking')
    'STEP3 USB removal'                = @('UsbRemoval_LocksImmediately_WipesPlaintextAndKeys','UsbRemovedInTheMiddleOfAnImport_AbortsSafely_AndNothingIsCorrupted','BackgroundPolling_LocksTheVaultByItself')
    'STEP3 change password'            = @('ChangePassword_ReplacesThePassword_AndKeepsEveryFile','ChangePassword_WhenTheHeaderCannotBeWritten_KeepsTheOldPassword','ChangePassword_IsSubjectToTheSameLockout')
    'STEP4 UI: one-password flow'       = @('TheCorrectPassword_OpensTheDashboard_AndIsForgotten','CreatingTheVault_UnlocksItAndOpensTheDashboard','WeakPassword_CannotBeUsed_EvenWhenConfirmedAndAcknowledged','TheUserMustAcknowledgeThatThereIsNoRecovery','UnlockingWithThePassword_LeadsToTheDashboard_WithTheFiles')
    'STEP4 UI: attempts and cooldown'   = @('RepeatedFailures_StartACooldown_ThatCountsDownAndEnds','DuringACooldown_EvenTheCorrectPasswordIsNotTried','ACooldownIsShownImmediately_WhenTheApplicationIsReopened','AWrongPassword_IsRejected_WithoutRevealingAnythingElse')
    'STEP4 UI: lock and USB removal'    = @('TheLockButton_ReturnsToTheUnlockScreen_AndClearsTheDashboard','RemovingTheUsb_ImmediatelyShowsTheLockedState_WithAWarning','RemovingTheUsb_ClosesDialogsThatShowVaultData','AfterTheIdleTime_TheVaultLocksItself','ClosingTheApplication_LocksTheVaultAndWipesTemporaryFiles','LockingWhileAnOperationRuns_StopsItQuietly')
    'STEP4 UI: file operations'         = @('AddingFiles_EncryptsThemIntoTheCurrentFolder','AddingTheFolderThatContainsTheVault_IsRefusedWithAClearMessage','Export_WarnsThatTheCopyIsUnprotected_ThenWritesIt','Export_NeverReplacesAnExistingFile','Delete_AsksFirst_ThenRemovesTheFile','Rename_RejectsDangerousNames_WithAReason','CancellingHalfwayThrough_KeepsWhatWasDone','WhileBusy_OtherActionsAreDisabled_ButCancelIsAvailable')
    'STEP4 UI: no plaintext by default' = @('OpeningAFileInAnotherProgram_IsOffByDefault','OpeningInAnotherProgram_Declined_CreatesNoPlaintextCopy','ATextFile_IsPreviewedFromMemory','AnImage_IsHandedToTheViewAsBytes_AndWipedWhenTheSelectionChanges')
    'STEP4 UI: safe error messages'     = @('IoErrors_NeverRevealPathsOrFileNames','UnknownExceptions_ShowNothingFromTheException','ArgumentErrors_OnlyShowSecureUsbsOwnSentences','UnexpectedProblems_AreShownWithoutInternals')
    'STEP4 UI: dialogs and settings'    = @('Success_ClosesTheDialog_ClearsTheFields_AndTheNewPasswordWorks','AWrongCurrentPassword_IsExplained_AndNothingChanges','EnablingOpenInOtherPrograms_RequiresAnInformedYes','AQuickCheckOfAHealthyVault_ReportsNoProblems','OnlyTheFullCheck_FindsSilentCorruption','AboutTheProduct_IsHonestAboutLimits','CloseVaultModals_ClosesTheCurrentOne_AndCancelsWaitingVaultModals')
    'STEP4 WPF smoke tests'             = @('LightAndDarkThemes_DefineExactlyTheSameKeys','EveryViewModel_HasAView','EveryView_LoadsItsXamlAndStyles','PasswordInput_ShowsThePlainTextOnlyWhenAsked','TheWindow_ShowsTheWelcomePage_ThroughItsViewTemplate','ADialog_AppearsOverTheWindow_AndGoesAway')
}

Write-Host '== restore/build ==' -ForegroundColor Cyan
dotnet restore SecureUSB.sln;                                   if ($LASTEXITCODE) { exit 1 }
dotnet build SecureUSB.sln -c Release --no-restore;             if ($LASTEXITCODE) { exit 1 }

$results = Join-Path $PSScriptRoot 'TestResults'
if (Test-Path $results) { Remove-Item $results -Recurse -Force }
$problems = New-Object System.Collections.Generic.List[string]
$allResults = @()

foreach ($name in $expected.Keys) {
    Write-Host "`n== running $name ==" -ForegroundColor Cyan
    dotnet test "tests/$name/$name.csproj" -c Release --no-build `
        --logger "trx;LogFileName=$name.trx" --results-directory $results
    if ($LASTEXITCODE) { $problems.Add("${name}: dotnet test returned exit code ${LASTEXITCODE}") }

    $trx = Join-Path $results "$name.trx"
    if (-not (Test-Path $trx)) { $problems.Add("${name}: no TRX result file produced (tests did not run)"); continue }

    [xml]$x = Get-Content $trx
    $c = $x.TestRun.ResultSummary.Counters
    $total = [int]$c.total; $passed = [int]$c.passed; $failed = [int]$c.failed
    Write-Host ("   {0}: total={1} passed={2} failed={3} (expected >= {4})" -f $name,$total,$passed,$failed,$expected[$name])
    if ($total -lt $expected[$name]) { $problems.Add("${name}: only ${total} tests ran, expected $($expected[$name])") }
    if ($failed -gt 0)               { $problems.Add("${name}: ${failed} test(s) failed") }
    $allResults += @($x.TestRun.Results.UnitTestResult)
}

Write-Host "`n== required security-critical tests ==" -ForegroundColor Cyan
foreach ($area in $required.Keys) {
    foreach ($method in $required[$area]) {
        $pattern = '\.' + [regex]::Escape($method) + '(\(|$)'
        $hits = @($allResults | Where-Object { $_.testName -match $pattern })
        if ($hits.Count -eq 0) {
            Write-Host ("  MISSING  [{0}] {1}" -f $area,$method) -ForegroundColor Red
            $problems.Add("required test not found: $method")
        }
        elseif (@($hits | Where-Object { $_.outcome -ne 'Passed' }).Count -gt 0) {
            Write-Host ("  FAILED   [{0}] {1}" -f $area,$method) -ForegroundColor Red
            $problems.Add("required test did not pass: $method")
        }
        else {
            Write-Host ("  passed   [{0}] {1} ({2} case(s))" -f $area,$method,$hits.Count) -ForegroundColor Green
        }
    }
}

Write-Host ''
if ($problems.Count -gt 0) {
    Write-Host 'VERIFICATION FAILED:' -ForegroundColor Red
    $problems | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    exit 1
}
$grand = ($expected.Values | Measure-Object -Sum).Sum
Write-Host "VERIFIED: all $grand expected test cases ran and passed, and every required test is present." -ForegroundColor Green
exit 0
