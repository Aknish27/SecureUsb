@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ==============================================
echo SecureUSB - verify, publish, and package
 echo ==============================================

where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: .NET SDK was not found. Install the .NET 8 SDK and reopen this terminal.
  exit /b 1
)

if not exist "src\SecureUSB.UI\SecureUSB.UI.csproj" (
  echo ERROR: Run this script from the extracted SecureUSB project root.
  exit /b 1
)

echo.
echo [1/3] Running the full build and test verification...
call "%~dp0build-and-test.cmd"
if errorlevel 1 (
  echo.
  echo ERROR: Verification failed. Packaging is stopped. Fix the failing build/tests first.
  exit /b 1
)

echo.
echo [2/3] Publishing self-contained Windows x64 app...
if exist "%~dp0publish\win-x64" rmdir /s /q "%~dp0publish\win-x64"
dotnet publish "%~dp0src\SecureUSB.UI\SecureUSB.UI.csproj" -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true ^
  -p:EnableCompressionInSingleFile=true -p:DebugType=None -p:DebugSymbols=false ^
  -o "%~dp0publish\win-x64"
if errorlevel 1 (
  echo ERROR: Publish failed. See the output above.
  exit /b 1
)

if not exist "%~dp0publish\win-x64\SecureUSB.UI.exe" (
  echo ERROR: Expected apphost SecureUSB.UI.exe was not produced.
  exit /b 1
)

echo.
echo [3/3] Creating release folder and ZIP...
set "RELEASE=%~dp0release\SecureUSB-v1.0.0-win-x64"
if not exist "%~dp0release" mkdir "%~dp0release"
if exist "%RELEASE%" rmdir /s /q "%RELEASE%"
mkdir "%RELEASE%"
copy /y "%~dp0publish\win-x64\SecureUSB.UI.exe" "%RELEASE%\SecureUSB.exe" >nul
if errorlevel 1 exit /b 1
copy /y "%~dp0docs\USER-MANUAL.md" "%RELEASE%\USER-MANUAL.md" >nul
copy /y "%~dp0docs\THREAT-MODEL.md" "%RELEASE%\THREAT-MODEL.md" >nul
copy /y "%~dp0docs\FINAL-TEST-PLAN.md" "%RELEASE%\FINAL-TEST-PLAN.md" >nul
(
  echo SecureUSB v1.0.0 - Windows x64
  echo.
  echo Start the application by double-clicking SecureUSB.exe.
  echo This release is intended for Windows 10/11 x64.
  echo Keep a separate backup of important files before using any encryption tool.
  echo There is no password recovery. If the password is lost, encrypted files may be unrecoverable.
  echo Read USER-MANUAL.md before creating a vault.
  echo.
  echo This package is a candidate release. Use only after the complete build-and-test verification passes.
) > "%RELEASE%\README-FIRST.txt"

set "ZIP=%~dp0release\SecureUSB-v1.0.0-win-x64.zip"
if exist "%ZIP%" del /q "%ZIP%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '%RELEASE%\*' -DestinationPath '%ZIP%' -Force"
if errorlevel 1 (
  echo ERROR: ZIP packaging failed.
  exit /b 1
)

echo.
echo SUCCESS: release package created:
echo   %ZIP%
echo Verify the package on a clean Windows 10/11 x64 machine before distributing it.
exit /b 0
