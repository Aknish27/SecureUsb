#!/usr/bin/env sh
# Runs each test project separately (dotnet prints one summary per project).
set -e
dotnet restore SecureUSB.sln
dotnet build SecureUSB.sln -c Release --no-restore
for p in SecureUSB.Cryptography.Tests SecureUSB.Security.Tests SecureUSB.Storage.Tests SecureUSB.Core.Tests SecureUSB.ViewModels.Tests; do
  echo "== $p =="
  dotnet test "tests/$p/$p.csproj" -c Release --no-build
done
echo "Expected totals: Cryptography.Tests=71, Security.Tests=105, Storage.Tests=176, Core.Tests=75, ViewModels.Tests=188, UI.Tests=33 (648 cases)."
