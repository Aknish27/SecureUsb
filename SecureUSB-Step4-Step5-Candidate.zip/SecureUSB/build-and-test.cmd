@echo off
rem Builds, runs every test project separately, and verifies the expected tests actually executed.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0verify-tests.ps1"
exit /b %ERRORLEVEL%
