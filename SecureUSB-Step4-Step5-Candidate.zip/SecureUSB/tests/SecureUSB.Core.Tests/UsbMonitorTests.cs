namespace SecureUSB.Core.Tests;

public class UsbMonitorTests : IDisposable
{
    private readonly TempVault _t = new();

    public UsbMonitorTests()
    {
        Directory.CreateDirectory(_t.Paths.DataDirectory);
        File.WriteAllText(_t.Paths.LockPath, "held by the running vault");
    }

    public void Dispose() => _t.Dispose();

    private UsbMonitor NewMonitor(int failuresRequired = 1) => new(_t.Drive, _t.Paths, failuresRequired);

    [Fact]
    public void PresentDrive_RaisesNothing()
    {
        using UsbMonitor m = NewMonitor();
        int raised = 0;
        m.DriveRemoved += (_, _) => raised++;

        Assert.True(m.CheckNow());
        Assert.True(m.CheckNow());
        Assert.Equal(0, raised);
        Assert.False(m.IsRemoved);
    }

    [Fact]
    public void Removal_RaisesTheEventExactlyOnce_AndStaysLatched()
    {
        using UsbMonitor m = NewMonitor();
        int raised = 0;
        m.DriveRemoved += (_, _) => raised++;

        _t.Drive.Available = false;
        Assert.False(m.CheckNow());
        Assert.False(m.CheckNow());
        Assert.Equal(1, raised);
        Assert.True(m.IsRemoved);

        _t.Drive.Available = true;   // plugging it back in does not un-remove: the vault is already locked
        Assert.True(m.CheckNow());
        Assert.True(m.IsRemoved);
        Assert.Equal(1, raised);
    }

    [Fact]
    public void MissingLockFile_MeansADifferentStickOrAWipedDrive()
    {
        using UsbMonitor m = NewMonitor();
        bool raised = false;
        m.DriveRemoved += (_, _) => raised = true;

        File.Delete(_t.Paths.LockPath);
        Assert.False(m.CheckNow());
        Assert.True(raised);
    }

    [Fact]
    public void MissingVaultFolder_CountsAsRemoval()
    {
        using UsbMonitor m = NewMonitor();
        bool raised = false;
        m.DriveRemoved += (_, _) => raised = true;

        Directory.Delete(_t.Paths.DataDirectory, recursive: true);
        Assert.False(m.CheckNow());
        Assert.True(raised);
    }

    [Fact]
    public void Debounce_RequiresConsecutiveFailures()
    {
        using UsbMonitor m = NewMonitor(failuresRequired: 3);
        int raised = 0;
        m.DriveRemoved += (_, _) => raised++;

        _t.Drive.Available = false;
        m.CheckNow();
        m.CheckNow();
        Assert.Equal(0, raised);

        _t.Drive.Available = true;   // a hiccup that recovers resets the count
        m.CheckNow();
        _t.Drive.Available = false;
        m.CheckNow();
        m.CheckNow();
        Assert.Equal(0, raised);

        m.CheckNow();
        Assert.Equal(1, raised);
    }

    [Fact]
    public void BackgroundTimer_DetectsRemoval()
    {
        using UsbMonitor m = NewMonitor();
        using var done = new ManualResetEventSlim();
        m.DriveRemoved += (_, _) => done.Set();

        m.Start(TimeSpan.FromMilliseconds(30));
        Assert.False(done.Wait(TimeSpan.FromMilliseconds(200)));   // nothing while the drive is present

        _t.Drive.Available = false;
        Assert.True(done.Wait(TimeSpan.FromSeconds(10)));
    }

    [Fact]
    public void AfterDispose_NothingHappens()
    {
        UsbMonitor m = NewMonitor();
        bool raised = false;
        m.DriveRemoved += (_, _) => raised = true;
        m.Dispose();

        _t.Drive.Available = false;
        Assert.True(m.CheckNow());
        Assert.False(raised);
    }

    [Fact]
    public void FaultyHandler_CannotBreakTheMonitor()
    {
        using UsbMonitor m = NewMonitor();
        m.DriveRemoved += (_, _) => throw new InvalidOperationException("UI bug");

        _t.Drive.Available = false;
        Assert.False(m.CheckNow());
        Assert.True(m.IsRemoved);
    }

    [Fact]
    public void Start_RejectsNonPositiveInterval()
    {
        using UsbMonitor m = NewMonitor();
        Assert.Throws<ArgumentOutOfRangeException>(() => m.Start(TimeSpan.Zero));
    }
}
