using SecureUSB.Models;
using SecureUSB.Security;
using SecureUSB.Storage;

namespace SecureUSB.Core.Tests;

public class VaultServiceTests : IDisposable
{
    private readonly ServiceFixture _f = new();

    public void Dispose() => _f.Dispose();

    private VaultService Svc => _f.Service;
    private VaultPaths Paths => _f.T.Paths;

    private static FileEntry Single(VaultService svc) => Assert.Single(svc.ListFiles());

    private List<VaultLockedEventArgs> Watch(VaultService svc)
    {
        var list = new List<VaultLockedEventArgs>();
        svc.Locked += (_, e) => list.Add(e);
        return list;
    }

    // ================================================================== create

    [Fact]
    public void NewUsb_IsNotInitialised_AndUnlockSaysSo()
    {
        Assert.Equal(VaultState.NotInitialized, Svc.State);
        UnlockResult r = Svc.Unlock(Harness.P1);
        Assert.Equal(UnlockStatus.VaultNotInitialized, r.Status);
        Assert.Null(Svc.VaultId);
    }

    [Fact]
    public void OperationsOnAVaultThatDoesNotExist_AreRefused()
    {
        Assert.Throws<VaultLockedException>(() => Svc.ListFiles());
    }

    [Fact]
    public void CreateVault_RejectsWeakAndMismatchedPasswords_AndCreatesNothing()
    {
        var weak = Assert.Throws<PasswordRejectedException>(() => Svc.CreateVault("password123", "password123"));
        Assert.NotEmpty(weak.Issues);

        var mismatch = Assert.Throws<PasswordRejectedException>(() => Svc.CreateVault(Harness.P1, Harness.P2));
        Assert.Contains(mismatch.Issues, i => i.Contains("do not match"));

        Assert.Throws<PasswordRejectedException>(() => Svc.CreateVault("", ""));

        Assert.Equal(VaultState.NotInitialized, Svc.State);
        Assert.False(File.Exists(Paths.HeaderPath));
        Assert.False(Directory.Exists(Paths.DataDirectory));
    }

    [Fact]
    public void CreateVault_LeavesAnUnlockedVault_WithEncryptedFilesOnDisk()
    {
        Svc.CreateVault(Harness.P1, Harness.P1);

        Assert.Equal(VaultState.Unlocked, Svc.State);
        Assert.True(Svc.IsUnlocked);
        Assert.NotNull(Svc.VaultId);
        Assert.Empty(Svc.ListFiles());
        Assert.True(File.Exists(Paths.HeaderPath));
        Assert.True(File.Exists(Paths.HeaderBackupPath));
        Assert.True(File.Exists(Paths.IndexPath));
        Assert.Contains(Svc.ReadActivityLog().Events, e => e.Kind == ActivityKind.VaultCreated);
    }

    [Fact]
    public void CreateVault_Twice_IsRefused()
    {
        _f.Unlocked();
        Assert.Throws<InvalidOperationException>(() => Svc.CreateVault(Harness.P2, Harness.P2));

        Svc.Lock();
        Assert.Throws<InvalidOperationException>(() => Svc.CreateVault(Harness.P2, Harness.P2));
    }

    // ================================================================== lock / unlock

    [Fact]
    public void Lock_RefusesFurtherOperations_AndRaisesTheEventOnce()
    {
        _f.Unlocked();
        List<VaultLockedEventArgs> events = Watch(Svc);

        Svc.Lock();
        Svc.Lock();

        Assert.Equal(VaultState.Locked, Svc.State);
        Assert.Null(Svc.VaultId);
        Assert.Throws<VaultLockedException>(() => Svc.ListFiles());
        Assert.Throws<VaultLockedException>(() => Svc.SearchFiles("x"));
        Assert.Throws<VaultLockedException>(() => Svc.GetStorageUsage());
        Assert.Throws<VaultLockedException>(() => Svc.ReadActivityLog());
        VaultLockedEventArgs only = Assert.Single(events);
        Assert.Equal(LockReason.User, only.Reason);
        Assert.True(only.TempCleanup.IsComplete);
    }

    [Fact]
    public void UnlockWithTheOnePassword_RestoresFilesAndContent()
    {
        _f.Unlocked();
        byte[] content = Harness.Data(120_000);
        FileEntry added = Svc.AddFile(_f.Source("confidential.pdf", content));

        Svc.Lock();
        UnlockResult r = Svc.Unlock(Harness.P1);

        Assert.True(r.Succeeded);
        Assert.Equal(VaultState.Unlocked, Svc.State);
        FileEntry listed = Single(Svc);
        Assert.Equal(added.Id, listed.Id);

        string outDir = _f.T.NewSubfolder("out");
        string path = Svc.ExportFile(listed.Id, outDir);
        Assert.Equal(content, File.ReadAllBytes(path));
    }

    [Fact]
    public void UnlockWhileUnlocked_IsAProgrammingError()
    {
        _f.Unlocked();
        Assert.Throws<InvalidOperationException>(() => Svc.Unlock(Harness.P1));
    }

    [Fact]
    public void WrongPassword_IsRejectedAndCounted()
    {
        _f.Unlocked();
        Svc.Lock();

        UnlockResult r = Svc.Unlock(Harness.Wrong);

        Assert.Equal(UnlockStatus.WrongPasswordOrDamagedVault, r.Status);
        Assert.Equal(1, r.FailedAttempts);
        Assert.Equal(TimeSpan.Zero, r.RetryAfter);
        Assert.False(r.BackupHeaderAvailable);
        Assert.Equal(VaultState.Locked, Svc.State);
        Assert.Equal(1, Svc.GetLoginStatus().ConsecutiveFailures);
        Assert.Throws<VaultLockedException>(() => Svc.ListFiles());
    }

    [Fact]
    public void ProgressiveDelays_BlockEvenTheCorrectPassword_UntilTheyExpire()
    {
        _f.Unlocked();
        Svc.Lock();

        Svc.Unlock(Harness.Wrong);
        Svc.Unlock(Harness.Wrong);
        UnlockResult third = Svc.Unlock(Harness.Wrong);
        Assert.Equal(3, third.FailedAttempts);
        Assert.Equal(TimeSpan.FromSeconds(5), third.RetryAfter);
        Assert.Contains("second", third.Message);

        UnlockResult blocked = Svc.Unlock(Harness.P1);   // right password, but refused without being tried
        Assert.Equal(UnlockStatus.LockedOut, blocked.Status);
        Assert.Equal(3, Svc.GetLoginStatus().ConsecutiveFailures);   // attempts during a lockout are not counted

        _f.T.Time.Advance(TimeSpan.FromSeconds(4));
        Assert.Equal(UnlockStatus.LockedOut, Svc.Unlock(Harness.P1).Status);

        _f.T.Time.Advance(TimeSpan.FromSeconds(1));
        Assert.True(Svc.Unlock(Harness.P1).Succeeded);
    }

    [Fact]
    public void DelaysKeepGrowing()
    {
        _f.Unlocked();
        Svc.Lock();

        UnlockResult r = default!;
        for (int i = 0; i < 5; i++)
        {
            r = Svc.Unlock(Harness.Wrong);
            _f.T.Time.Advance(TimeSpan.FromHours(1));   // wait out every delay so the next attempt is evaluated
        }
        Assert.Equal(5, r.FailedAttempts);
        Assert.Equal(TimeSpan.FromSeconds(30), r.RetryAfter);
    }

    [Fact]
    public void Success_ResetsTheCounter_AndTheFailuresAreReportedInTheLog()
    {
        _f.Unlocked();
        Svc.Lock();
        Svc.Unlock(Harness.Wrong);
        Svc.Unlock(Harness.Wrong);

        Assert.True(Svc.Unlock(Harness.P1).Succeeded);

        Assert.Equal(0, Svc.GetLoginStatus().ConsecutiveFailures);
        Assert.False(File.Exists(Paths.GuardPath));
        ActivityEvent report = Assert.Single(Svc.ReadActivityLog().Events, e => e.Kind == ActivityKind.UnlockFailuresReported);
        Assert.Contains("2 failed", report.Message);
    }

    [Fact]
    public void EmptyPassword_AsksForOne_AndIsNotCounted()
    {
        _f.Unlocked();
        Svc.Lock();

        UnlockResult r = Svc.Unlock("");

        Assert.Equal(UnlockStatus.PasswordRequired, r.Status);
        Assert.Equal(0, Svc.GetLoginStatus().ConsecutiveFailures);
    }

    [Fact]
    public void Lockout_SurvivesRestartingTheApplication()
    {
        _f.Unlocked();
        Svc.Lock();
        for (int i = 0; i < 3; i++) Svc.Unlock(Harness.Wrong);
        Svc.Dispose();

        VaultService restarted = _f.Create();   // "closed and reopened SecureUSB.exe"
        Assert.True(restarted.GetLoginStatus().IsLockedOut);
        Assert.Equal(UnlockStatus.LockedOut, restarted.Unlock(Harness.P1).Status);
    }

    [Fact]
    public void UnplugBeforeUnlock_IsReportedAsUsbUnavailable_NotAsAWrongPassword()
    {
        _f.Unlocked();
        Svc.Lock();
        _f.T.Drive.Available = false;

        UnlockResult r = Svc.Unlock(Harness.P1);

        Assert.Equal(UnlockStatus.UsbUnavailable, r.Status);
        _f.T.Drive.Available = true;
        Assert.Equal(0, Svc.GetLoginStatus().ConsecutiveFailures);
        Assert.True(Svc.Unlock(Harness.P1).Succeeded);
    }

    [Fact]
    public void SecondInstance_IsToldTheVaultIsInUse_AndLeavesTheFirstOnesTempFilesAlone()
    {
        _f.Unlocked();
        FileEntry e = Svc.AddFile(_f.Source("a.docx"));
        string temp = Svc.OpenTemporaryCopy(e.Id);

        VaultService second = _f.Create();   // its startup sweep must not delete the live session of the first
        UnlockResult r = second.Unlock(Harness.P1);

        Assert.Equal(UnlockStatus.VaultInUse, r.Status);
        Assert.Equal(0, second.GetLoginStatus().ConsecutiveFailures);
        Assert.True(File.Exists(temp));
        Assert.True(Svc.IsUnlocked);
    }

    // ================================================================== header / index trouble

    [Fact]
    public void BitRotInTheHeader_OffersTheBackup_ThenRecovers()
    {
        _f.Unlocked();
        Svc.Lock();
        Harness.FlipByte(Paths.HeaderPath, VaultHeader.WrappedKeyOffset + 5);

        UnlockResult r = Svc.Unlock(Harness.P1);
        Assert.Equal(UnlockStatus.WrongPasswordOrDamagedVault, r.Status);
        Assert.True(r.BackupHeaderAvailable);

        UnlockResult recovered = Svc.UnlockUsingBackupHeader(Harness.P1);
        Assert.True(recovered.Succeeded);
        Assert.Equal(File.ReadAllBytes(Paths.HeaderBackupPath), File.ReadAllBytes(Paths.HeaderPath));
        Assert.Contains(Svc.ReadActivityLog().Events, x => x.Kind == ActivityKind.HeaderRecoveredFromBackup);

        Svc.Lock();
        Assert.True(Svc.Unlock(Harness.P1).Succeeded);   // the normal path works again
    }

    [Fact]
    public void StructurallyDamagedPrimaryHeader_IsRepairedAutomatically()
    {
        _f.Unlocked();
        Svc.Lock();
        Harness.FlipByte(Paths.HeaderPath, 0);

        Assert.True(Svc.Unlock(Harness.P1).Succeeded);
        VaultHeader.Parse(File.ReadAllBytes(Paths.HeaderPath));   // valid again
        Assert.Equal(File.ReadAllBytes(Paths.HeaderBackupPath), File.ReadAllBytes(Paths.HeaderPath));
    }

    [Fact]
    public void LostIndex_IsReportedWithoutPunishingTheUser_AndCanBeRebuilt()
    {
        _f.Unlocked();
        Svc.AddFile(_f.Source("a.bin", Harness.Data(500, 1)));
        Svc.AddFile(_f.Source("b.bin", Harness.Data(700, 2)));
        Svc.Lock();
        foreach (string p in new[] { Paths.IndexPath, Paths.IndexPrevPath, Paths.IndexTempPath })
            if (File.Exists(p)) File.Delete(p);

        UnlockResult r = Svc.Unlock(Harness.P1);
        Assert.Equal(UnlockStatus.IndexDamaged, r.Status);
        Assert.Equal(0, Svc.GetLoginStatus().ConsecutiveFailures);   // the password was right
        Assert.Equal(VaultState.Locked, Svc.State);

        UnlockResult rebuilt = Svc.RebuildIndexAndUnlock(Harness.P1);
        Assert.True(rebuilt.Succeeded);
        Assert.Equal(2, Svc.ListFiles().Count);
        Assert.All(Svc.ListFiles(), f => Assert.Equal("Recovered", f.FolderPath));
    }

    // ================================================================== adding files

    [Fact]
    public void AddFile_SanitizesTheFolderPath()
    {
        _f.Unlocked();
        FileEntry e = Svc.AddFile(_f.Source("report.pdf"), "../../Legal\\2026");

        Assert.Equal("Legal/2026", e.FolderPath);
        Assert.Equal("report.pdf", e.Name);
        Assert.Contains(Svc.ReadActivityLog().Events, x => x.Kind == ActivityKind.FileAdded && x.Message.Contains("report.pdf"));
    }

    [Fact]
    public void AddingTheSameFileTwice_RenamesTheSecondCopy()
    {
        _f.Unlocked();
        string src = _f.Source("report.pdf");
        Svc.AddFile(src);
        FileEntry second = Svc.AddFile(src);

        Assert.Equal("report (2).pdf", second.Name);
        Assert.Throws<DuplicateEntryException>(() => Svc.AddFile(src, conflict: ConflictPolicy.Reject));
    }

    [Fact]
    public void TheVaultsOwnFiles_CannotBeAdded()
    {
        _f.Unlocked();
        Assert.Throws<ArgumentException>(() => Svc.AddFile(Paths.HeaderPath));
        Assert.Throws<ArgumentException>(() => Svc.AddFile(Paths.IndexPath));
        Assert.Empty(Svc.ListFiles());
    }

    [Fact]
    public void AFolderContainingTheVault_CannotBeAdded()
    {
        _f.Unlocked();
        Assert.Throws<ArgumentException>(() => Svc.AddFolder(_f.T.Root));                    // the "USB root"
        Assert.Throws<ArgumentException>(() => Svc.AddFolder(Paths.DataDirectory));
        Assert.Throws<ArgumentException>(() => Svc.AddFolder(Paths.BlobsDirectory));
        Assert.Throws<ArgumentException>(() => Svc.AddFolder(_f.T.Root + Path.DirectorySeparatorChar));
        Assert.Empty(Svc.ListFiles());
    }

    [Fact]
    public void AddFolder_ImportsTheTree()
    {
        _f.Unlocked();
        string root = _f.T.NewSubfolder("Project X");
        File.WriteAllBytes(Path.Combine(root, "a.txt"), Harness.Data(100, 1));
        Directory.CreateDirectory(Path.Combine(root, "sub"));
        File.WriteAllBytes(Path.Combine(root, "sub", "b.txt"), Harness.Data(100, 2));

        AddFolderResult r = Svc.AddFolder(root);

        Assert.Equal(2, r.Added);
        Assert.Empty(r.Failures);
        Assert.Equal(new[] { "Project X/a.txt", "Project X/sub/b.txt" },
            Svc.ListFiles().Select(f => f.FullPath).OrderBy(p => p, StringComparer.Ordinal).ToArray());
        Assert.Contains(Svc.ReadActivityLog().Events, x => x.Kind == ActivityKind.FolderAdded);
    }

    // ================================================================== rename / delete / search

    [Fact]
    public void Rename_ValidatesWhatTheUserTypes()
    {
        _f.Unlocked();
        FileEntry a = Svc.AddFile(_f.Source("a.txt"));
        Svc.AddFile(_f.Source("b.txt"));

        FileEntry renamed = Svc.RenameFile(a.Id, "renamed.txt");
        Assert.Equal("renamed.txt", renamed.Name);

        Assert.Throws<InvalidEntryNameException>(() => Svc.RenameFile(a.Id, "bad/name.txt"));
        Assert.Throws<InvalidEntryNameException>(() => Svc.RenameFile(a.Id, "CON"));
        Assert.Throws<DuplicateEntryException>(() => Svc.RenameFile(a.Id, "B.TXT"));
        Assert.Throws<EntryNotFoundException>(() => Svc.RenameFile(Guid.NewGuid(), "x.txt"));
        Assert.Contains(Svc.ReadActivityLog().Events, x => x.Kind == ActivityKind.FileRenamed);
    }

    [Fact]
    public void Delete_RemovesTheFile()
    {
        _f.Unlocked();
        FileEntry a = Svc.AddFile(_f.Source("a.txt"));

        Svc.DeleteFile(a.Id);

        Assert.Empty(Svc.ListFiles());
        Assert.Throws<EntryNotFoundException>(() => Svc.DeleteFile(a.Id));
        Assert.Contains(Svc.ReadActivityLog().Events, x => x.Kind == ActivityKind.FileDeleted && x.Message.Contains("a.txt"));
    }

    [Fact]
    public void Search_FindsByNameAndFolder()
    {
        _f.Unlocked();
        Svc.AddFile(_f.Source("Annual Report.pdf"), "Finance");
        Svc.AddFile(_f.Source("photo.jpg"), "HR");

        Assert.Equal(new[] { "Annual Report.pdf" }, Svc.SearchFiles("report").Select(f => f.Name).ToArray());
        Assert.Equal(new[] { "photo.jpg" }, Svc.SearchFiles("hr").Select(f => f.Name).ToArray());
        Assert.Equal(2, Svc.SearchFiles("").Count);
    }

    // ================================================================== export / temp copies

    [Fact]
    public void Export_WritesInsideTheChosenFolder_AndProtectsExistingFiles()
    {
        _f.Unlocked();
        byte[] content = Harness.Data(5000);
        FileEntry e = Svc.AddFile(_f.Source("doc.bin", content));
        string outDir = _f.T.NewSubfolder("out");

        string path = Svc.ExportFile(e.Id, outDir);
        Assert.Equal(Path.Combine(outDir, "doc.bin"), path);
        Assert.Equal(content, File.ReadAllBytes(path));

        Assert.ThrowsAny<IOException>(() => Svc.ExportFile(e.Id, outDir));            // no silent overwrite
        Assert.Equal(content, File.ReadAllBytes(path));
        Assert.Equal(path, Svc.ExportFile(e.Id, outDir, overwrite: true));

        string hostile = Svc.ExportFile(e.Id, outDir, fileName: "..\\..\\escape.bin");
        Assert.Equal(Path.Combine(outDir, "escape.bin"), hostile);
        Assert.False(File.Exists(Path.Combine(_f.T.Root, "escape.bin")));
        Assert.Contains(Svc.ReadActivityLog().Events, x => x.Kind == ActivityKind.FileExported);
    }

    [Fact]
    public void Export_RefusesBadDestinations()
    {
        _f.Unlocked();
        FileEntry e = Svc.AddFile(_f.Source("doc.bin"));

        Assert.Throws<DirectoryNotFoundException>(() => Svc.ExportFile(e.Id, Path.Combine(_f.T.Root, "nope")));
        Assert.Throws<ArgumentException>(() => Svc.ExportFile(e.Id, Paths.DataDirectory));
        Assert.Throws<EntryNotFoundException>(() => Svc.ExportFile(Guid.NewGuid(), _f.T.Root));
    }

    [Fact]
    public void Export_OfATamperedFile_FailsAndLeavesNothing()
    {
        _f.Unlocked();
        FileEntry e = Svc.AddFile(_f.Source("doc.bin", Harness.Data(3 * 1024 * 1024)));
        Harness.FlipByte(Paths.BlobPath(e.Id), 2_500_000);
        string outDir = _f.T.NewSubfolder("out");

        Assert.ThrowsAny<System.Security.Cryptography.CryptographicException>(() => Svc.ExportFile(e.Id, outDir));
        Assert.Empty(Directory.GetFiles(outDir));
    }

    [Fact]
    public void TemporaryCopy_IsDecrypted_AndWipedWhenTheVaultLocks()
    {
        _f.Unlocked();
        byte[] content = Harness.Data(4000);
        FileEntry e = Svc.AddFile(_f.Source("memo.docx", content));
        List<VaultLockedEventArgs> events = Watch(Svc);

        string path = Svc.OpenTemporaryCopy(e.Id);
        Assert.Equal(content, File.ReadAllBytes(path));
        Assert.Equal("memo.docx", Path.GetFileName(path));
        Assert.Equal(1, Svc.TemporaryFileCount);

        Svc.Lock();

        Assert.False(File.Exists(path));
        Assert.Equal(0, Svc.TemporaryFileCount);
        Assert.Equal(1, Assert.Single(events).TempCleanup.Deleted);
        Assert.All(Directory.GetFiles(_f.TempRoot, "*", SearchOption.AllDirectories),
            f => Assert.Equal(TempFileManager.MarkerFileName, Path.GetFileName(f)));
    }

    [Fact]
    public void Preview_DecryptsInMemory_WithoutTouchingTheDisk()
    {
        _f.Unlocked();
        byte[] content = Harness.Data(3000);
        FileEntry e = Svc.AddFile(_f.Source("pic.jpg", content));

        Assert.Equal(content, Svc.ReadFileForPreview(e.Id, 1_000_000));
        Assert.Equal(0, Svc.TemporaryFileCount);
        Assert.Throws<InvalidOperationException>(() => Svc.ReadFileForPreview(e.Id, 100));
    }

    [Fact]
    public void CleanTemporaryFiles_WipesOnDemand()
    {
        _f.Unlocked();
        FileEntry e = Svc.AddFile(_f.Source("a.txt"));
        string temp = Svc.OpenTemporaryCopy(e.Id);

        CleanupReport r = Svc.CleanTemporaryFiles();

        Assert.Equal(1, r.Deleted);
        Assert.False(File.Exists(temp));
        Assert.True(Svc.IsUnlocked);
    }

    [Fact]
    public void ACopyStillOpenInAnotherProgram_IsReportedWhenLocking()
    {
        if (!OperatingSystem.IsWindows()) return;   // other systems allow deleting open files

        _f.Unlocked();
        FileEntry e = Svc.AddFile(_f.Source("a.docx"));
        string temp = Svc.OpenTemporaryCopy(e.Id);
        List<VaultLockedEventArgs> events = Watch(Svc);

        using (new FileStream(temp, FileMode.Open, FileAccess.Read, FileShare.Read))   // "Word has it open"
        {
            Svc.Lock();
        }

        Assert.False(Assert.Single(events).TempCleanup.IsComplete);
        Assert.True(Svc.CleanTemporaryFiles().IsComplete);   // retry once the program let go
        Assert.False(File.Exists(temp));
    }

    // ================================================================== USB removal

    [Fact]
    public void UsbRemoval_LocksImmediately_WipesPlaintextAndKeys()
    {
        _f.Unlocked();
        FileEntry e = Svc.AddFile(_f.Source("secret.docx"));
        string temp = Svc.OpenTemporaryCopy(e.Id);
        List<VaultLockedEventArgs> events = Watch(Svc);

        _f.T.Drive.Available = false;   // the stick is pulled out
        bool present = Svc.CheckUsbNow();

        Assert.False(present);
        Assert.Equal(VaultState.Locked, Svc.State);
        Assert.False(File.Exists(temp));
        Assert.Equal(LockReason.UsbRemoved, Assert.Single(events).Reason);
        Assert.Throws<VaultLockedException>(() => Svc.ListFiles());
        Assert.Throws<VaultLockedException>(() => Svc.OpenTemporaryCopy(e.Id));
        Assert.Throws<VaultLockedException>(() => Svc.AddFile(_f.Source("late.txt")));
    }

    [Fact]
    public void AfterReinsertingTheUsb_TheUserUnlocksAgain_AndTheRemovalIsInTheLog()
    {
        _f.Unlocked();
        Svc.AddFile(_f.Source("a.txt"));
        _f.T.Drive.Available = false;
        Svc.CheckUsbNow();
        _f.T.Drive.Available = true;

        Assert.True(Svc.Unlock(Harness.P1).Succeeded);

        Assert.Single(Svc.ListFiles());
        Assert.Contains(Svc.ReadActivityLog().Events, x => x.Kind == ActivityKind.UsbRemoved && x.Message.Contains("removed"));
    }

    [Fact]
    public void UsbRemovedInTheMiddleOfAnImport_AbortsSafely_AndNothingIsCorrupted()
    {
        _f.Unlocked();
        string root = _f.T.NewSubfolder("bulk");
        for (int i = 0; i < 6; i++) File.WriteAllBytes(Path.Combine(root, $"f{i}.bin"), Harness.Data(2000, i));

        int count = 0;
        var progress = new SyncProgress<string>(_ =>
        {
            if (++count == 3)
            {
                _f.T.Drive.Available = false;
                Svc.CheckUsbNow();   // the removal is noticed while the import is running
            }
        });

        Assert.Throws<VaultLockedException>(() => Svc.AddFolder(root, progress: progress));

        Assert.Equal(VaultState.Locked, Svc.State);
        Assert.Equal(0, Svc.TemporaryFileCount);
        Assert.Empty(Directory.GetFiles(Paths.BlobsDirectory, "*.tmp"));

        // plug it back in: the vault is consistent; interrupted work shows up as recoverable leftovers, never as errors
        _f.T.Drive.Available = true;
        Assert.True(Svc.Unlock(Harness.P1).Succeeded);
        IntegrityReport report = Svc.CheckIntegrity(deep: true);
        Assert.False(report.HasErrors);

        int orphans = report.OfKind(IssueKind.OrphanBlob).Count();
        RepairResult repaired = Svc.RepairIntegrity(report, new RepairOptions { Orphans = OrphanAction.Recover });
        Assert.Equal(orphans, repaired.OrphansRecovered);
        Assert.Equal(orphans, Svc.ListFiles().Count);
        Assert.True(Svc.CheckIntegrity(deep: true).IsClean);
    }

    [Fact]
    public void BackgroundPolling_LocksTheVaultByItself()
    {
        using var f = new ServiceFixture(pollInterval: TimeSpan.FromMilliseconds(50));
        f.Unlocked();
        using var done = new ManualResetEventSlim();
        LockReason? reason = null;
        f.Service.Locked += (_, e) => { reason = e.Reason; done.Set(); };

        f.T.Drive.Available = false;

        Assert.True(done.Wait(TimeSpan.FromSeconds(15)));
        Assert.Equal(LockReason.UsbRemoved, reason);
        Assert.Equal(VaultState.Locked, f.Service.State);
    }

    // ================================================================== change password

    [Fact]
    public void ChangePassword_ReplacesThePassword_AndKeepsEveryFile()
    {
        _f.Unlocked();
        byte[] content = Harness.Data(60_000);
        FileEntry e = Svc.AddFile(_f.Source("keep.bin", content));

        ChangePasswordResult r = Svc.ChangePassword(Harness.P1, Harness.P2, Harness.P2);
        Assert.True(r.Succeeded);
        Assert.Contains(Svc.ReadActivityLog().Events, x => x.Kind == ActivityKind.PasswordChanged);

        Svc.Lock();
        Assert.Equal(UnlockStatus.WrongPasswordOrDamagedVault, Svc.Unlock(Harness.P1).Status);
        Assert.Equal(UnlockStatus.WrongPasswordOrDamagedVault, Svc.UnlockUsingBackupHeader(Harness.P1).Status);   // the backup header is new too
        Assert.True(Svc.Unlock(Harness.P2).Succeeded);

        Assert.Equal(content, Svc.ReadFileForPreview(e.Id, 1_000_000));
        Assert.Equal(File.ReadAllBytes(Paths.HeaderPath), File.ReadAllBytes(Paths.HeaderBackupPath));
    }

    [Fact]
    public void ChangePassword_WithWrongCurrentPassword_ChangesNothing_AndCounts()
    {
        _f.Unlocked();
        byte[] headerBefore = File.ReadAllBytes(Paths.HeaderPath);

        ChangePasswordResult r = Svc.ChangePassword(Harness.Wrong, Harness.P2, Harness.P2);

        Assert.Equal(ChangePasswordStatus.WrongCurrentPassword, r.Status);
        Assert.Equal(1, Svc.GetLoginStatus().ConsecutiveFailures);
        Assert.Equal(headerBefore, File.ReadAllBytes(Paths.HeaderPath));
        Svc.Lock();
        Assert.True(Svc.Unlock(Harness.P1).Succeeded);   // the old password still works
    }

    [Fact]
    public void ChangePassword_RejectsWeakSameAndMismatchedNewPasswords_BeforeTouchingAnything()
    {
        _f.Unlocked();
        byte[] headerBefore = File.ReadAllBytes(Paths.HeaderPath);

        Assert.Throws<PasswordRejectedException>(() => Svc.ChangePassword(Harness.P1, "short", "short"));
        Assert.Throws<PasswordRejectedException>(() => Svc.ChangePassword(Harness.P1, Harness.P2, Harness.P3));
        Assert.Throws<PasswordRejectedException>(() => Svc.ChangePassword(Harness.P1, Harness.P1, Harness.P1));

        Assert.Equal(headerBefore, File.ReadAllBytes(Paths.HeaderPath));
        Assert.Equal(0, Svc.GetLoginStatus().ConsecutiveFailures);
    }

    [Fact]
    public void ChangePassword_IsSubjectToTheSameLockout()
    {
        _f.Unlocked();
        Svc.ChangePassword(Harness.Wrong, Harness.P2, Harness.P2);
        Svc.ChangePassword(Harness.Wrong, Harness.P2, Harness.P2);
        ChangePasswordResult third = Svc.ChangePassword(Harness.Wrong, Harness.P2, Harness.P2);

        Assert.Equal(ChangePasswordStatus.LockedOut, third.Status);
        Assert.True(third.RetryAfter > TimeSpan.Zero);
        Assert.Equal(ChangePasswordStatus.LockedOut, Svc.ChangePassword(Harness.P1, Harness.P2, Harness.P2).Status);
    }

    [Fact]
    public void ChangePassword_WhenTheHeaderCannotBeWritten_KeepsTheOldPassword()
    {
        _f.Unlocked();
        Directory.CreateDirectory(Paths.HeaderTempPath);   // simulated drive failure while saving the new header

        Assert.ThrowsAny<Exception>(() => Svc.ChangePassword(Harness.P1, Harness.P2, Harness.P2));

        Directory.Delete(Paths.HeaderTempPath);
        Svc.Lock();
        Assert.True(Svc.Unlock(Harness.P1).Succeeded);
        Svc.Lock();
        Assert.Equal(UnlockStatus.WrongPasswordOrDamagedVault, Svc.Unlock(Harness.P2).Status);
    }

    [Fact]
    public void ChangePassword_WhileLocked_IsRefused()
    {
        _f.Unlocked();
        Svc.Lock();
        Assert.Throws<VaultLockedException>(() => Svc.ChangePassword(Harness.P1, Harness.P2, Harness.P2));
    }

    // ================================================================== log, integrity, storage, shutdown

    [Fact]
    public void ActivityLog_RecordsWhatTheUserDid_AndSurvivesLocking()
    {
        _f.Unlocked();
        FileEntry e = Svc.AddFile(_f.Source("a.txt"));
        Svc.RenameFile(e.Id, "b.txt");
        Svc.ExportFile(e.Id, _f.T.NewSubfolder("out"));
        Svc.DeleteFile(e.Id);
        Svc.Lock();
        Svc.Unlock(Harness.P1);

        ActivityKind[] kinds = Svc.ReadActivityLog().Events.Select(x => x.Kind).ToArray();
        Assert.Equal(new[]
        {
            ActivityKind.VaultCreated, ActivityKind.FileAdded, ActivityKind.FileRenamed, ActivityKind.FileExported,
            ActivityKind.FileDeleted, ActivityKind.VaultLocked, ActivityKind.UnlockSucceeded
        }, kinds);
        Assert.False(Svc.ReadActivityLog().TamperDetected);
        Assert.Equal(0, Svc.LogWriteFailures);
    }

    [Fact]
    public void IntegrityCheck_FindsAndRepairsProblems()
    {
        _f.Unlocked();
        FileEntry a = Svc.AddFile(_f.Source("a.bin"));
        Svc.AddFile(_f.Source("b.bin"));
        Assert.True(Svc.CheckIntegrity(deep: false).IsClean);

        File.Delete(Paths.BlobPath(a.Id));
        IntegrityReport report = Svc.CheckIntegrity(deep: false);
        Assert.True(report.HasErrors);

        Svc.RepairIntegrity(report, new RepairOptions { RemoveEntriesWithMissingBlobs = true });
        Assert.Single(Svc.ListFiles());
        Assert.True(Svc.CheckIntegrity(deep: true).IsClean);
        Assert.Contains(Svc.ReadActivityLog().Events, x => x.Kind == ActivityKind.IntegrityRepaired);
    }

    [Fact]
    public void StorageUsage_SeparatesDriveVaultAndApplication()
    {
        _f.Unlocked();
        _f.T.Drive.Total = 32L << 30;
        _f.T.Drive.Free = 20L << 30;
        File.WriteAllBytes(Path.Combine(_f.T.Root, "SecureUSB.exe"), new byte[4321]);
        Svc.AddFile(_f.Source("a.bin", Harness.Data(50_000)));

        StorageUsage u = Svc.GetStorageUsage();

        Assert.Equal(32L << 30, u.TotalBytes);
        Assert.Equal(20L << 30, u.FreeBytes);
        Assert.Equal(4321, u.ApplicationBytes);
        Assert.True(u.VaultBytes > 50_000);
        Assert.True(u.VaultBytes < u.UsedBytes);
    }

    [Fact]
    public void StartupSweep_RemovesDecryptedLeftoversOfACrashedRun()
    {
        string stale = Path.Combine(_f.TempRoot, TempFileManager.SessionPrefix + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(stale);
        File.WriteAllText(Path.Combine(stale, TempFileManager.MarkerFileName), "marker");
        File.WriteAllBytes(Path.Combine(stale, "plaintext.docx"), new byte[1000]);

        VaultService fresh = _f.Create();   // "next start of SecureUSB.exe"

        Assert.False(Directory.Exists(stale));
        Assert.True(fresh.StaleTempFilesCleanedAtStartup >= 1);
    }

    [Fact]
    public void Dispose_LocksWipesAndRefusesFurtherUse()
    {
        _f.Unlocked();
        FileEntry e = Svc.AddFile(_f.Source("a.txt"));
        string temp = Svc.OpenTemporaryCopy(e.Id);
        List<VaultLockedEventArgs> events = Watch(Svc);

        Svc.Dispose();

        Assert.False(File.Exists(temp));
        Assert.Equal(LockReason.Shutdown, Assert.Single(events).Reason);
        Assert.Empty(Directory.GetDirectories(_f.TempRoot));
        Assert.Throws<ObjectDisposedException>(() => Svc.ListFiles());
        Svc.Dispose();   // idempotent
    }

    [Fact]
    public void VaultId_IsStableAcrossLockAndUnlock()
    {
        _f.Unlocked();
        Guid? first = Svc.VaultId;
        Svc.Lock();
        Svc.Unlock(Harness.P1);
        Assert.Equal(first, Svc.VaultId);
    }
}
