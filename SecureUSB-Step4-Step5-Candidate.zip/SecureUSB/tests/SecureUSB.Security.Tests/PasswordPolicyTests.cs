using SecureUSB.Security;

namespace SecureUSB.Security.Tests;

public class PasswordPolicyTests
{
    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("Company123!")]          // 11 chars + common stem
    [InlineData("Password123456!")]      // common stem with digits/symbol suffix
    [InlineData("P@ssw0rd!2024")]        // leetspeak variant of "password"
    [InlineData("aaaaaaaaaaaaaaaa")]     // repetition
    [InlineData("abcdefghijkl1234")]     // sequences
    [InlineData("123456789012")]         // digit sequence
    [InlineData("qwertyqwerty")]         // common keyboard walk
    public void WeakPasswords_AreRejected(string? password)
    {
        var result = PasswordPolicy.Evaluate(password);
        Assert.False(result.MeetsPolicy);
        Assert.NotEmpty(result.Issues);
        Assert.True(result.Strength <= PasswordStrength.Fair);
    }

    [Theory]
    [InlineData("correct horse battery staple")]
    [InlineData("k9#Vx2!qLm8@Zr4$")]
    [InlineData("tulip granite harbor violin mosaic")]
    public void StrongPasswords_AreAccepted(string password)
    {
        var result = PasswordPolicy.Evaluate(password);
        Assert.True(result.MeetsPolicy, string.Join("; ", result.Issues));
        Assert.Empty(result.Issues);
        Assert.True(result.Strength >= PasswordStrength.Strong);
    }

    [Fact]
    public void ShortPasswords_FailEvenIfVaried()
    {
        var result = PasswordPolicy.Evaluate("k9#Vx2!qLm8");   // 11 chars
        Assert.False(result.MeetsPolicy);
        Assert.Contains(result.Issues, i => i.Contains("12"));
        Assert.True(result.Strength <= PasswordStrength.Weak);
    }

    [Fact]
    public void FailingPasswords_GetPassphraseSuggestion()
    {
        var result = PasswordPolicy.Evaluate("password");
        Assert.Contains(result.Suggestions, s => s.Contains("passphrase"));
    }

    [Fact]
    public void MoreCharacters_NeverLowersEstimate()
    {
        double shorter = PasswordPolicy.Evaluate("tulip granite harbor").EstimatedBits;
        double longer = PasswordPolicy.Evaluate("tulip granite harbor violin").EstimatedBits;
        Assert.True(longer >= shorter);
    }
}
