using SecureUSB.Models;
using SecureUSB.Security;

namespace SecureUSB.Security.Tests;

public class FilenameSanitizerTests
{
    [Theory]
    [InlineData("report.pdf", "report.pdf")]
    [InlineData("C:\\Users\\bob\\secret.docx", "secret.docx")]
    [InlineData("../../etc/passwd", "passwd")]
    [InlineData("..\\..\\windows\\system32\\config", "config")]
    [InlineData("a/b/c.txt", "c.txt")]
    [InlineData("con.txt", "_con.txt")]
    [InlineData("NUL", "_NUL")]
    [InlineData("COM1.tar.gz", "_COM1.tar.gz")]
    [InlineData("lpt9", "_lpt9")]
    [InlineData("con ", "_con")]
    [InlineData("AUX.", "_AUX")]
    [InlineData("file:name?.txt", "file_name_.txt")]
    [InlineData("<>:\"|?*.txt", "_______.txt")]
    [InlineData("???", "___")]
    [InlineData("  spaced.txt", "spaced.txt")]
    [InlineData("trailing. . ", "trailing")]
    [InlineData("evil\u202Egpj.exe", "evilgpj.exe")]
    [InlineData("zero\u200Bwidth.txt", "zerowidth.txt")]
    [InlineData("tab\there.txt", "tab_here.txt")]
    [InlineData("nul\0byte.txt", "nul_byte.txt")]
    [InlineData(".gitignore", ".gitignore")]
    [InlineData("\u65E5\u672C\u8A9E.pdf", "\u65E5\u672C\u8A9E.pdf")]
    [InlineData("e\u0301.txt", "\u00E9.txt")]
    [InlineData("\U0001F600.txt", "\U0001F600.txt")]
    [InlineData("", "file")]
    [InlineData("   ", "file")]
    [InlineData("...", "file")]
    [InlineData("..", "file")]
    [InlineData("/", "file")]
    [InlineData("dir/", "file")]
    [InlineData("\\\\", "file")]
    [InlineData(null, "file")]
    public void KnownInputs_ProduceTheExpectedSafeName(string? input, string expected)
    {
        Assert.Equal(expected, FilenameSanitizer.SanitizeFileName(input));
    }

    [Fact]
    public void LoneSurrogates_AreReplaced()
    {
        // kept out of the data-row attributes: attribute arguments are stored as UTF-8, which cannot hold a lone surrogate
        Assert.Equal("a_b.txt", FilenameSanitizer.SanitizeFileName("a\uD800b.txt"));
        Assert.Equal("a_b.txt", FilenameSanitizer.SanitizeFileName("a\uDC00b.txt"));
    }

    [Fact]
    public void CustomFallback_IsUsed_AndInvalidFallbackIsReplaced()
    {
        Assert.Equal("fallback.bin", FilenameSanitizer.SanitizeFileName("", "fallback.bin"));
        Assert.Equal("file", FilenameSanitizer.SanitizeFileName("", "../bad"));
    }

    [Fact]
    public void LongNames_AreTruncatedKeepingTheExtension()
    {
        string withExt = FilenameSanitizer.SanitizeFileName(new string('a', 300) + ".txt");
        Assert.Equal(EntryNames.MaxNameLength, withExt.Length);
        Assert.EndsWith(".txt", withExt);
        Assert.True(EntryNames.IsValidName(withExt, out _));

        string noExt = FilenameSanitizer.SanitizeFileName(new string('a', 300));
        Assert.Equal(EntryNames.MaxNameLength, noExt.Length);
    }

    [Fact]
    public void Truncation_NeverSplitsASurrogatePair()
    {
        string name = FilenameSanitizer.SanitizeFileName(new string('a', 254) + "\U0001F600zzzz");
        Assert.True(name.Length <= EntryNames.MaxNameLength);
        Assert.True(EntryNames.IsValidName(name, out _));
        Assert.False(HasLoneSurrogate(name));
    }

    [Fact]
    public void RandomHostileInput_AlwaysYieldsAValidSeparatorFreeName()
    {
        string[] tokens =
        {
            "a", "b", "Z", "0", " ", ".", "..", "/", "\\", ":", "*", "?", "\"", "<", ">", "|", "\t", "\0",
            "\u202E", "\u200B", "\uD800", "\uDC00", "\U0001F600", "\u00E9", "e\u0301", "con", "NUL", "COM1", "lpt2",
            "aux", ".txt", "\u00A0", "~", "-", "C:", "\u3000"
        };
        var rng = new Random(20260101);

        for (int i = 0; i < 4000; i++)
        {
            var sb = new System.Text.StringBuilder();
            int count = rng.Next(0, 14);
            for (int t = 0; t < count; t++) sb.Append(tokens[rng.Next(tokens.Length)]);
            string input = sb.ToString();

            string result = FilenameSanitizer.SanitizeFileName(input);
            Assert.True(EntryNames.IsValidName(result, out string reason), $"Input #{i} gave an invalid name ({reason}).");
            Assert.DoesNotContain('/', result);
            Assert.DoesNotContain('\\', result);
            Assert.False(HasLoneSurrogate(result));

            string folder = FilenameSanitizer.SanitizeFolderPath(input);
            Assert.True(EntryNames.IsValidFolderPath(folder, out reason), $"Input #{i} gave an invalid folder ({reason}).");
            Assert.DoesNotContain("..", folder.Split('/'));
        }
    }

    [Theory]
    [InlineData("A/B/C", "A/B/C")]
    [InlineData("A\\B", "A/B")]
    [InlineData("../../x", "x")]
    [InlineData("a/../b", "a/b")]
    [InlineData("/abs/path/", "abs/path")]
    [InlineData("a//b", "a/b")]
    [InlineData("./a/./b", "a/b")]
    [InlineData("con/aux", "_con/_aux")]
    [InlineData("C:\\Users", "C_/Users")]
    [InlineData("  ", "")]
    [InlineData("", "")]
    [InlineData(null, "")]
    public void FolderPaths_AreNormalisedAndTraversalIsDropped(string? input, string expected)
    {
        Assert.Equal(expected, FilenameSanitizer.SanitizeFolderPath(input));
    }

    [Fact]
    public void FolderDepthAndLength_AreLimited()
    {
        string deep = FilenameSanitizer.SanitizeFolderPath(string.Join("/", Enumerable.Repeat("d", 40)));
        Assert.Equal(EntryNames.MaxFolderDepth, deep.Split('/').Length);

        string wide = FilenameSanitizer.SanitizeFolderPath(string.Join("/", Enumerable.Repeat(new string('a', 200), 10)));
        Assert.True(wide.Length <= EntryNames.MaxFolderPathLength);
        Assert.Equal(5, wide.Split('/').Length);
        Assert.True(EntryNames.IsValidFolderPath(wide, out _));
    }

    [Fact]
    public void CombineInsideDirectory_AlwaysProducesAChildOfTheDirectory()
    {
        using var dir = new TempDir();
        string expectedDir = Path.TrimEndingDirectorySeparator(Path.GetFullPath(dir.Root));

        foreach (string hostile in new[] { "../evil.txt", "..\\..\\evil.txt", "C:\\Windows\\evil.txt", "/etc/evil.txt", "a/b/evil.txt", "evil.txt" })
        {
            string path = FilenameSanitizer.CombineInsideDirectory(dir.Root, hostile);
            Assert.Equal(expectedDir, Path.TrimEndingDirectorySeparator(Path.GetDirectoryName(path)!));
            Assert.Equal("evil.txt", Path.GetFileName(path));
        }

        Assert.Equal("file", Path.GetFileName(FilenameSanitizer.CombineInsideDirectory(dir.Root + Path.DirectorySeparatorChar, "")));
    }

    private static bool HasLoneSurrogate(string s)
    {
        for (int i = 0; i < s.Length; i++)
        {
            if (char.IsHighSurrogate(s[i]))
            {
                if (i + 1 >= s.Length || !char.IsLowSurrogate(s[i + 1])) return true;
                i++;
            }
            else if (char.IsLowSurrogate(s[i]))
            {
                return true;
            }
        }
        return false;
    }
}
