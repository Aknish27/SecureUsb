using SecureUSB.Core;
using SecureUSB.Models;
using SecureUSB.Storage;
using SecureUSB.ViewModels.Mvvm;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels.Tests;

public class DashboardLoadingAndNavigationTests : IDisposable
{
    private readonly DashboardKit _k = new(initialize: false);

    public void Dispose() => _k.Dispose();

    private DashboardViewModel D => _k.Dashboard;

    [Fact]
    public async Task OpeningTheDashboard_ShowsFilesStorageAndHealth()
    {
        _k.Seed("a.pdf");
        _k.Seed("b.txt");
        _k.Seed("x.docx", null, "Legal");

        await D.InitializeAsync();

        Assert.Equal(new[] { "Legal", "a.pdf", "b.txt" }, D.Items.Select(i => i.Name).ToArray());
        Assert.True(D.HasItems);
        Assert.Equal("3 items", D.ItemCountText);
        Assert.Equal("32.0 GB", D.Storage.TotalText);
        Assert.Equal("20.0 GB", D.Storage.FreeText);
        Assert.Equal(0.375, D.Storage.UsedFraction, 3);
        Assert.NotEqual("\u2014", D.Storage.VaultText);
        Assert.Equal("exFAT \u00B7 Removable drive", D.Storage.DriveText.Replace("TESTUSB \u00B7 ", ""));
        Assert.Equal(HealthLevel.Healthy, D.Health.Level);
        Assert.Equal("Test USB", D.VaultName);
    }

    [Fact]
    public async Task InitializeIsIdempotent()
    {
        Task first = D.InitializeAsync();
        Task second = D.InitializeAsync();
        Assert.Same(first, second);
        await first;
    }

    [Fact]
    public async Task AnEmptyVault_ExplainsHowToStart()
    {
        await D.InitializeAsync();
        Assert.False(D.HasItems);
        Assert.Contains("Add files", D.EmptyText);
        Assert.Equal("0 items", D.ItemCountText);
    }

    [Fact]
    public async Task Folders_CanBeOpened_AndLeftAgain()
    {
        _k.Seed("a.txt", null, "Legal");
        _k.Seed("b.txt", null, "Legal/2026");
        await D.InitializeAsync();

        D.OpenItemCommand.Execute(_k.Item("Legal"));
        Assert.Equal("Legal", D.CurrentFolder);
        Assert.Equal(new[] { "Vault", "Legal" }, D.Breadcrumbs.Select(b => b.Name).ToArray());
        Assert.Equal(new[] { "2026", "a.txt" }, D.Items.Select(i => i.Name).ToArray());
        Assert.True(D.UpCommand.CanExecute(null));

        D.OpenItemCommand.Execute(_k.Item("2026"));
        Assert.Equal("Legal/2026", D.CurrentFolder);
        Assert.Equal(new[] { "Vault", "Legal", "2026" }, D.Breadcrumbs.Select(b => b.Name).ToArray());

        D.UpCommand.Execute(null);
        Assert.Equal("Legal", D.CurrentFolder);

        D.NavigateToCommand.Execute(new BreadcrumbItem("Vault", ""));
        Assert.Equal("", D.CurrentFolder);
        Assert.False(D.UpCommand.CanExecute(null));
    }

    [Fact]
    public async Task Search_FiltersAcrossAllFolders_AndCanBeCleared()
    {
        _k.Seed("Annual Report.pdf", null, "Finance");
        _k.Seed("photo.jpg", null, "HR");
        _k.Seed("notes.txt");
        await D.InitializeAsync();

        D.SearchText = "report";

        Assert.True(D.IsSearching);
        Assert.Equal(new[] { "Annual Report.pdf" }, D.Items.Select(i => i.Name).ToArray());
        Assert.Equal("1 result", D.ItemCountText);
        Assert.False(D.UpCommand.CanExecute(null));
        Assert.True(D.ClearSearchCommand.CanExecute(null));

        D.SearchText = "zzz";
        Assert.Equal("No files match your search.", D.EmptyText);
        Assert.False(D.HasItems);

        D.ClearSearchCommand.Execute(null);
        Assert.False(D.IsSearching);
        Assert.Equal(3, D.Items.Count);
        Assert.False(D.ClearSearchCommand.CanExecute(null));
    }

    [Fact]
    public async Task NavigatingAway_ClearsTheSearch()
    {
        _k.Seed("a.txt", null, "Legal");
        await D.InitializeAsync();
        D.SearchText = "a";

        D.NavigateTo("Legal");

        Assert.Equal("", D.SearchText);
        Assert.False(D.IsSearching);
    }

    [Fact]
    public async Task UserActivity_IsReportedForTheAutoLockCountdown()
    {
        await D.InitializeAsync();
        int before = _k.Nav.ActivityCount;

        D.SearchText = "x";
        D.SetSelection(Array.Empty<VaultItemViewModel>());

        Assert.True(_k.Nav.ActivityCount >= before + 2);
    }

    [Fact]
    public async Task Selection_DrivesWhichButtonsAreEnabled()
    {
        _k.Seed("a.txt");
        _k.Seed("b.txt");
        _k.Seed("c.txt", null, "Legal");
        await D.InitializeAsync();

        Assert.False(D.ExportCommand.CanExecute(null));
        Assert.False(D.DeleteCommand.CanExecute(null));
        Assert.False(D.RenameCommand.CanExecute(null));
        Assert.Equal("", D.SelectionSummary);

        _k.Select("a.txt");
        Assert.True(D.ExportCommand.CanExecute(null));
        Assert.True(D.DeleteCommand.CanExecute(null));
        Assert.True(D.RenameCommand.CanExecute(null));
        Assert.Equal("a.txt", D.SelectionSummary);

        _k.Select("a.txt", "b.txt");
        Assert.True(D.ExportCommand.CanExecute(null));
        Assert.False(D.RenameCommand.CanExecute(null));   // one file at a time
        Assert.Equal("2 items selected", D.SelectionSummary);

        _k.Select("Legal");
        Assert.True(D.ExportCommand.CanExecute(null));
        Assert.True(D.DeleteCommand.CanExecute(null));
        Assert.False(D.RenameCommand.CanExecute(null));   // folders cannot be renamed
    }

    [Fact]
    public async Task OpeningAFileInAnotherProgram_IsOffByDefault()
    {
        _k.Seed("a.txt");
        await D.InitializeAsync();
        _k.Select("a.txt");

        Assert.False(D.OpenExternalAvailable);
        Assert.False(D.OpenExternalCommand.CanExecute(null));

        _k.Settings.AllowOpenInOtherPrograms = true;
        Assert.True(D.OpenExternalAvailable);
        Assert.True(D.OpenExternalCommand.CanExecute(null));
    }

    [Fact]
    public async Task ADamagedFile_IsMarked_AndTheHealthBadgeTurnsRed()
    {
        FileEntry bad = _k.Seed("bad.pdf");
        _k.Seed("good.pdf");
        await D.InitializeAsync();
        Assert.Equal(HealthLevel.Healthy, D.Health.Level);

        File.Delete(_k.Paths.BlobPath(bad.Id));
        await D.RefreshCommand.ExecuteAsync();

        Assert.Equal(HealthLevel.Error, D.Health.Level);
        Assert.Contains("1 problem", D.Health.Text);
        Assert.Equal("Damaged", _k.Item("bad.pdf").StatusText);
        Assert.True(_k.Item("bad.pdf").IsDamaged);
        Assert.Equal("Encrypted", _k.Item("good.pdf").StatusText);
    }

    [Fact]
    public async Task IfTheDriveDisappears_StorageShowsUnavailable_NotAnError()
    {
        await D.InitializeAsync();
        _k.T.Drive.Available = false;

        await D.RefreshStorageAsync();

        Assert.False(D.Storage.IsAvailable);
        Assert.Equal("Drive information unavailable", D.Storage.DriveText);
        Assert.Empty(_k.Dialogs.Messages);
    }

    [Fact]
    public async Task Dispose_EmptiesEverythingTheScreenWasShowing()
    {
        _k.Seed("a.txt");
        await D.InitializeAsync();
        _k.Select("a.txt");

        D.Dispose();

        Assert.Empty(D.Items);
        Assert.Equal(PreviewKind.None, D.PreviewKind);
        Assert.Null(D.PreviewImageData);
        Assert.Equal("", D.PreviewText);
        await D.RefreshAsync();   // does nothing after disposal
        Assert.Empty(D.Items);
    }
}

public class DashboardFileOperationTests : IDisposable
{
    private readonly DashboardKit _k = new(initialize: false);

    public void Dispose() => _k.Dispose();

    private DashboardViewModel D => _k.Dashboard;

    // ------------------------------------------------------------------ add

    [Fact]
    public async Task AddingFiles_EncryptsThemIntoTheCurrentFolder()
    {
        await D.InitializeAsync();
        D.NavigateTo("Legal");
        _k.Files.FilesToPick.Add(_k.Source("a.pdf"));
        _k.Files.FilesToPick.Add(_k.Source("b.txt"));

        await D.AddFilesCommand.ExecuteAsync();

        Assert.All(_k.Service.ListFiles(), f => Assert.Equal("Legal", f.FolderPath));
        Assert.Equal(new[] { "a.pdf", "b.txt" }, D.Items.Select(i => i.Name).ToArray());
        Assert.Equal("2 files added to the vault.", D.StatusMessage);
        Assert.False(D.IsBusy);
        Assert.Empty(_k.Dialogs.Messages);
        Assert.NotEqual("\u2014", D.Storage.VaultText);
    }

    [Fact]
    public async Task CancellingTheFilePicker_DoesNothing()
    {
        await D.InitializeAsync();
        await D.AddFilesCommand.ExecuteAsync();

        Assert.Equal(1, _k.Files.FilePicks);
        Assert.Empty(D.Items);
        Assert.Equal("", D.StatusMessage);
    }

    [Fact]
    public async Task AFileThatCannotBeAdded_IsReported_WithoutStoppingTheOthers()
    {
        await D.InitializeAsync();
        string missing = Path.Combine(_k.T.Root, "gone.bin");
        _k.Files.FilesToPick.Add(missing);
        _k.Files.FilesToPick.Add(_k.Source("ok.txt"));

        await D.AddFilesCommand.ExecuteAsync();

        Assert.Equal(new[] { "ok.txt" }, D.Items.Select(i => i.Name).ToArray());
        Assert.Equal("1 file added to the vault. 1 could not be processed.", D.StatusMessage);
        var message = Assert.Single(_k.Dialogs.Messages);
        Assert.Equal(MessageKind.Warning, message.Kind);
        Assert.Contains("gone.bin", message.Message);
        Assert.Contains("could not be found", message.Message);
        Assert.DoesNotContain(_k.T.Root, message.Message);   // names yes, host folders no
    }

    [Fact]
    public async Task AddingAFolder_KeepsItsStructure()
    {
        await D.InitializeAsync();
        string tree = _k.T.Sub("Project X");
        File.WriteAllBytes(Path.Combine(tree, "a.txt"), Data.Bytes(100, 1));
        Directory.CreateDirectory(Path.Combine(tree, "sub"));
        File.WriteAllBytes(Path.Combine(tree, "sub", "b.txt"), Data.Bytes(100, 2));
        _k.Files.FolderToPick = tree;

        await D.AddFolderCommand.ExecuteAsync();

        Assert.Equal("2 files added to the vault.", D.StatusMessage);
        Assert.Equal(new[] { "Project X" }, D.Items.Select(i => i.Name).ToArray());
        D.NavigateTo("Project X");
        Assert.Equal(new[] { "sub", "a.txt" }, D.Items.Select(i => i.Name).ToArray());
    }

    [Fact]
    public async Task AddingTheFolderThatContainsTheVault_IsRefusedWithAClearMessage()
    {
        await D.InitializeAsync();
        _k.Files.FolderToPick = _k.T.Root;   // the "USB root": it contains SecureUSB_Data

        await D.AddFolderCommand.ExecuteAsync();

        var message = Assert.Single(_k.Dialogs.Messages);
        Assert.Equal(MessageKind.Error, message.Kind);
        Assert.Contains("contains the SecureUSB vault", message.Message);
        Assert.DoesNotContain(_k.T.Root, message.Message);
        Assert.Empty(_k.Service.ListFiles());
        Assert.Contains("stopped", D.StatusMessage);
        Assert.DoesNotContain("Cancelled", D.StatusMessage);
    }

    [Fact]
    public async Task WhileBusy_OtherActionsAreDisabled_ButCancelIsAvailable()
    {
        await D.InitializeAsync();
        _k.Files.FilesToPick.Add(_k.Source("a.txt"));
        bool? addEnabled = null, deleteEnabled = null, lockEnabled = null, cancelEnabled = null;
        D.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName != nameof(DashboardViewModel.IsBusy) || !D.IsBusy) return;
            addEnabled = D.AddFilesCommand.CanExecute(null);
            deleteEnabled = D.DeleteCommand.CanExecute(null);
            lockEnabled = D.LockCommand.CanExecute(null);
            cancelEnabled = D.CancelCommand.CanExecute(null);
            Assert.Equal("Encrypting files\u2026", D.BusyTitle);
        };

        await D.AddFilesCommand.ExecuteAsync();

        Assert.False(addEnabled);
        Assert.False(deleteEnabled);
        Assert.True(cancelEnabled);
        Assert.True(lockEnabled);             // the Lock button stays usable: it cancels the work
        Assert.False(D.IsBusy);
    }

    [Fact]
    public async Task CancellingHalfwayThrough_KeepsWhatWasDone()
    {
        await D.InitializeAsync();
        for (int i = 1; i <= 3; i++) _k.Files.FilesToPick.Add(_k.Source($"f{i}.txt"));
        D.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(DashboardViewModel.BusyDetail) && D.BusyDetail.StartsWith("2 of 3"))
                D.CancelCommand.Execute(null);
        };

        await D.AddFilesCommand.ExecuteAsync();

        Assert.Equal(1, _k.Service.ListFiles().Count);
        Assert.StartsWith("Cancelled.", D.StatusMessage);
        Assert.Contains("1 file added", D.StatusMessage);
        Assert.False(D.IsBusy);
        Assert.Empty(_k.Dialogs.Messages);
    }

    [Fact]
    public async Task LockingWhileAnOperationRuns_StopsItQuietly()
    {
        await D.InitializeAsync();
        _k.Files.FilesToPick.Add(_k.Source("a.txt"));
        _k.Files.FilesToPick.Add(_k.Source("b.txt"));
        D.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(DashboardViewModel.BusyDetail) && D.BusyDetail.StartsWith("2 of 2"))
                _k.Service.Lock();   // e.g. the USB drive was pulled out
        };

        await D.AddFilesCommand.ExecuteAsync();

        Assert.False(D.IsBusy);
        Assert.Empty(_k.Dialogs.Messages);   // no scary error: the shell shows the locked state instead
        Assert.Equal(VaultState.Locked, _k.Service.State);
    }

    // ------------------------------------------------------------------ export

    [Fact]
    public async Task Export_WarnsThatTheCopyIsUnprotected_ThenWritesIt()
    {
        byte[] content = Data.Bytes(70_000);
        _k.Seed("doc.bin", content);
        await D.InitializeAsync();
        _k.Select("doc.bin");
        string dest = _k.T.Sub("out");
        _k.Files.FolderToPick = dest;

        await D.ExportCommand.ExecuteAsync();

        ConfirmRequest asked = Assert.Single(_k.Dialogs.Confirms);
        Assert.Contains("unprotected", asked.Message);
        Assert.Equal(content, File.ReadAllBytes(Path.Combine(dest, "doc.bin")));
        Assert.Equal("1 file exported.", D.StatusMessage);
        Assert.False(D.IsBusy);
    }

    [Fact]
    public async Task Export_ToTheSameDriveAsTheVault_GetsAStrongerWarning()
    {
        _k.Seed("doc.bin");
        await D.InitializeAsync();
        _k.Select("doc.bin");
        _k.Files.FolderToPick = _k.T.Sub("out");   // same drive as the vault (the scratch drive)

        await D.ExportCommand.ExecuteAsync();

        ConfirmRequest asked = Assert.Single(_k.Dialogs.Confirms);
        Assert.Contains("same drive", asked.Message);
        Assert.True(asked.IsDestructive);
    }

    [Fact]
    public async Task Export_Declined_WritesNothing()
    {
        _k.Seed("doc.bin");
        await D.InitializeAsync();
        _k.Select("doc.bin");
        string dest = _k.T.Sub("out");
        _k.Files.FolderToPick = dest;
        _k.Dialogs.ConfirmAnswers.Enqueue(false);

        await D.ExportCommand.ExecuteAsync();

        Assert.Empty(Directory.GetFiles(dest));
        Assert.Equal("", D.StatusMessage);
    }

    [Fact]
    public async Task Export_WithoutAChosenFolder_AsksNothing()
    {
        _k.Seed("doc.bin");
        await D.InitializeAsync();
        _k.Select("doc.bin");
        _k.Files.FolderToPick = null;

        await D.ExportCommand.ExecuteAsync();

        Assert.Empty(_k.Dialogs.Confirms);
    }

    [Fact]
    public async Task ExportingAFolder_RecreatesItsStructure()
    {
        _k.Seed("a.txt", Data.Bytes(10, 1), "Legal");
        _k.Seed("b.txt", Data.Bytes(10, 2), "Legal/2026");
        _k.Seed("c.txt", Data.Bytes(10, 3));
        await D.InitializeAsync();
        _k.Select("Legal");
        string dest = _k.T.Sub("out");
        _k.Files.FolderToPick = dest;

        await D.ExportCommand.ExecuteAsync();

        Assert.Equal(Data.Bytes(10, 1), File.ReadAllBytes(Path.Combine(dest, "Legal", "a.txt")));
        Assert.Equal(Data.Bytes(10, 2), File.ReadAllBytes(Path.Combine(dest, "Legal", "2026", "b.txt")));
        Assert.False(File.Exists(Path.Combine(dest, "c.txt")));   // not selected
        Assert.Equal("2 files exported.", D.StatusMessage);
    }

    [Fact]
    public async Task Export_NeverReplacesAnExistingFile()
    {
        _k.Seed("doc.bin", Data.Bytes(100));
        await D.InitializeAsync();
        _k.Select("doc.bin");
        string dest = _k.T.Sub("out");
        File.WriteAllText(Path.Combine(dest, "doc.bin"), "precious original");
        _k.Files.FolderToPick = dest;

        await D.ExportCommand.ExecuteAsync();

        Assert.Equal("precious original", File.ReadAllText(Path.Combine(dest, "doc.bin")));
        var message = Assert.Single(_k.Dialogs.Messages);
        Assert.Contains("already exists", message.Message);
        Assert.Equal("0 files exported. 1 could not be processed.", D.StatusMessage);
    }

    [Fact]
    public async Task Export_ToSomethingThatIsNotAFolder_FailsWithoutRevealingPaths()
    {
        _k.Seed("doc.bin");
        await D.InitializeAsync();
        _k.Select("doc.bin");
        string notAFolder = Path.Combine(_k.T.Root, "just-a-file.txt");
        File.WriteAllText(notAFolder, "x");
        _k.Files.FolderToPick = notAFolder;

        await D.ExportCommand.ExecuteAsync();

        var message = Assert.Single(_k.Dialogs.Messages);
        Assert.DoesNotContain(_k.T.Root, message.Message);
        Assert.DoesNotContain("just-a-file", message.Message);
    }

    // ------------------------------------------------------------------ delete

    [Fact]
    public async Task Delete_AsksFirst_ThenRemovesTheFile()
    {
        _k.Seed("a.txt");
        _k.Seed("b.txt");
        await D.InitializeAsync();
        _k.Select("a.txt");

        await D.DeleteCommand.ExecuteAsync();

        ConfirmRequest asked = Assert.Single(_k.Dialogs.Confirms);
        Assert.True(asked.IsDestructive);
        Assert.Contains("cannot be undone", asked.Message);
        Assert.Contains("a.txt", asked.Message);
        Assert.Equal(new[] { "b.txt" }, D.Items.Select(i => i.Name).ToArray());
        Assert.Equal("1 file deleted.", D.StatusMessage);
    }

    [Fact]
    public async Task Delete_Declined_ChangesNothing()
    {
        _k.Seed("a.txt");
        await D.InitializeAsync();
        _k.Select("a.txt");
        _k.Dialogs.ConfirmAnswers.Enqueue(false);

        await D.DeleteCommand.ExecuteAsync();

        Assert.Single(_k.Service.ListFiles());
        Assert.Equal("", D.StatusMessage);
    }

    [Fact]
    public async Task DeletingAFolder_DeletesEverythingInside_AndSaysSo()
    {
        _k.Seed("a.txt", null, "Legal");
        _k.Seed("b.txt", null, "Legal/2026");
        _k.Seed("keep.txt");
        await D.InitializeAsync();
        _k.Select("Legal");

        await D.DeleteCommand.ExecuteAsync();

        Assert.Contains("everything inside", Assert.Single(_k.Dialogs.Confirms).Message);
        Assert.Equal(new[] { "keep.txt" }, _k.Service.ListFiles().Select(f => f.Name).ToArray());
        Assert.Equal("2 files deleted.", D.StatusMessage);
    }

    // ------------------------------------------------------------------ rename

    [Fact]
    public async Task Rename_AsksForTheNewName_StartingFromTheCurrentOne()
    {
        _k.Seed("old.txt");
        await D.InitializeAsync();
        _k.Select("old.txt");
        _k.Dialogs.PromptAnswers.Enqueue("new.txt");

        await D.RenameCommand.ExecuteAsync();

        Assert.Equal("old.txt", Assert.Single(_k.Dialogs.Prompts).InitialValue);
        Assert.Equal(new[] { "new.txt" }, D.Items.Select(i => i.Name).ToArray());
        Assert.Equal("File renamed.", D.StatusMessage);
    }

    [Fact]
    public async Task Rename_RejectsDangerousNames_WithAReason()
    {
        _k.Seed("old.txt");
        await D.InitializeAsync();
        _k.Select("old.txt");
        _k.Dialogs.PromptAnswers.Enqueue("..\\evil.txt");

        await D.RenameCommand.ExecuteAsync();

        var message = Assert.Single(_k.Dialogs.Messages);
        Assert.Equal(MessageKind.Error, message.Kind);
        Assert.Contains("forbidden character", message.Message);
        Assert.Equal(new[] { "old.txt" }, D.Items.Select(i => i.Name).ToArray());
    }

    [Fact]
    public async Task Rename_ToAnExistingName_IsRefused()
    {
        _k.Seed("a.txt");
        _k.Seed("b.txt");
        await D.InitializeAsync();
        _k.Select("a.txt");
        _k.Dialogs.PromptAnswers.Enqueue("B.TXT");

        await D.RenameCommand.ExecuteAsync();

        Assert.Contains("already exists", Assert.Single(_k.Dialogs.Messages).Message);
    }

    [Fact]
    public async Task Rename_CancelledOrUnchanged_DoesNothing()
    {
        _k.Seed("a.txt");
        await D.InitializeAsync();
        _k.Select("a.txt");

        await D.RenameCommand.ExecuteAsync();                       // dialog cancelled (null)
        _k.Dialogs.PromptAnswers.Enqueue("a.txt");
        await D.RenameCommand.ExecuteAsync();                       // same name

        Assert.Empty(_k.Dialogs.Messages);
        Assert.Equal("", D.StatusMessage);
    }

    // ------------------------------------------------------------------ open in another program

    [Fact]
    public async Task OpeningInAnotherProgram_NeedsPermissionInSettings_AndConfirmation()
    {
        byte[] content = Data.Bytes(2000);
        _k.Seed("memo.docx", content);
        await D.InitializeAsync();
        _k.Select("memo.docx");
        _k.Settings.AllowOpenInOtherPrograms = true;

        await D.OpenExternalCommand.ExecuteAsync();

        ConfirmRequest asked = Assert.Single(_k.Dialogs.Confirms);
        Assert.Contains("temporary", asked.Message);
        Assert.Contains("NOT saved back", asked.Message);
        string opened = Assert.Single(_k.Launcher.Opened);
        Assert.Equal(content, _k.Launcher.ContentAtOpen[0]);
        Assert.Equal("memo.docx", Path.GetFileName(opened));
        Assert.Equal(1, _k.Service.TemporaryFileCount);
        Assert.DoesNotContain(opened, D.StatusMessage);               // the temporary location is never displayed
        Assert.DoesNotContain(Path.GetDirectoryName(opened)!, D.StatusMessage);
    }

    [Fact]
    public async Task OpeningInAnotherProgram_Declined_CreatesNoPlaintextCopy()
    {
        _k.Seed("memo.docx");
        await D.InitializeAsync();
        _k.Select("memo.docx");
        _k.Settings.AllowOpenInOtherPrograms = true;
        _k.Dialogs.ConfirmAnswers.Enqueue(false);

        await D.OpenExternalCommand.ExecuteAsync();

        Assert.Empty(_k.Launcher.Opened);
        Assert.Equal(0, _k.Service.TemporaryFileCount);
    }

    [Fact]
    public async Task DoubleClickingAFile_OnlyOpensItExternally_WhenThatIsAllowed()
    {
        _k.Seed("a.txt");
        await D.InitializeAsync();

        D.OpenItemCommand.Execute(_k.Item("a.txt"));
        await Task.Delay(150);
        Assert.Empty(_k.Launcher.Opened);                             // default: only selects (and previews)

        _k.Settings.AllowOpenInOtherPrograms = true;
        D.OpenItemCommand.Execute(_k.Item("a.txt"));
        await Wait.Until(() => _k.Launcher.Opened.Count == 1);
    }

    // ------------------------------------------------------------------ lock, dialogs

    [Fact]
    public async Task TheLockButton_LocksTheVaultThroughCore()
    {
        await D.InitializeAsync();

        await D.LockCommand.ExecuteAsync();

        Assert.Equal(VaultState.Locked, _k.Service.State);
    }

    [Fact]
    public async Task ChangePassword_OpensItsDialog_AndReportsSuccess()
    {
        await D.InitializeAsync();
        _k.Dialogs.ModalHandler = async modal =>
        {
            var vm = Assert.IsType<ChangePasswordViewModel>(modal);
            vm.CurrentPassword = Pw.P1;
            vm.NewPassword = Pw.P2;
            vm.Confirmation = Pw.P2;
            await vm.ChangeCommand.ExecuteAsync();
        };

        await D.ChangePasswordCommand.ExecuteAsync();

        Assert.Equal("Password changed.", D.StatusMessage);
        _k.Service.Lock();
        Assert.True(_k.Service.Unlock(Pw.P2).Succeeded);
    }

    [Fact]
    public async Task TheActivityHealthAndSettingsDialogs_OpenFromTheToolbar()
    {
        await D.InitializeAsync();

        await D.ActivityLogCommand.ExecuteAsync();
        await D.HealthCommand.ExecuteAsync();
        await D.SettingsCommand.ExecuteAsync();

        Assert.IsType<ActivityLogViewModel>(_k.Dialogs.Modals[0]);
        Assert.IsType<HealthViewModel>(_k.Dialogs.Modals[1]);
        var settings = Assert.IsType<SettingsViewModel>(_k.Dialogs.Modals[2]);
        Assert.Equal("1.0.0-test", settings.App.Version);
    }

    [Fact]
    public async Task UnexpectedProblems_AreShownWithoutInternals()
    {
        await D.InitializeAsync();
        _k.Dialogs.ModalHandler = _ => throw new NullReferenceException(@"secret at C:\Users\bob\file.txt");

        await D.ActivityLogCommand.ExecuteAsync();

        var message = Assert.Single(_k.Dialogs.Messages);
        Assert.Equal(ErrorMessages.Unexpected, message.Message);
        Assert.DoesNotContain("bob", message.Message);
    }
}

public class DashboardPreviewTests : IDisposable
{
    private readonly DashboardKit _k = new(initialize: false);

    public void Dispose() => _k.Dispose();

    private DashboardViewModel D => _k.Dashboard;

    [Fact]
    public async Task ATextFile_IsPreviewedFromMemory()
    {
        _k.Seed("notes.txt", System.Text.Encoding.UTF8.GetBytes("Hello vault \u00FC"));
        await D.InitializeAsync();

        _k.Select("notes.txt");
        await D.PreviewTask;

        Assert.Equal(PreviewKind.Text, D.PreviewKind);
        Assert.Equal("Hello vault \u00FC", D.PreviewText);
        Assert.Equal("notes.txt", D.PreviewTitle);
        Assert.Equal(0, _k.Service.TemporaryFileCount);   // nothing was written to the disk
    }

    [Fact]
    public async Task AnImage_IsHandedToTheViewAsBytes_AndWipedWhenTheSelectionChanges()
    {
        byte[] picture = Data.Bytes(3000, 7);
        _k.Seed("pic.png", picture);
        _k.Seed("other.pdf");
        await D.InitializeAsync();

        _k.Select("pic.png");
        await D.PreviewTask;
        Assert.Equal(PreviewKind.Image, D.PreviewKind);
        byte[] shown = D.PreviewImageData!;
        Assert.Equal(picture, shown);

        _k.Select("other.pdf");
        await D.PreviewTask;

        Assert.Null(D.PreviewImageData);
        Assert.All(shown, b => Assert.Equal(0, b));   // the old decrypted bytes were zeroed
    }

    [Fact]
    public async Task UnsupportedAndOversizedFiles_ExplainWhyThereIsNoPreview()
    {
        _k.Seed("report.pdf");
        _k.Seed("huge.png", new byte[9 * 1024 * 1024]);
        await D.InitializeAsync();

        _k.Select("report.pdf");
        await D.PreviewTask;
        Assert.Equal(PreviewKind.Unsupported, D.PreviewKind);
        Assert.Contains("No preview", D.PreviewMessage);

        _k.Select("huge.png");
        await D.PreviewTask;
        Assert.Equal(PreviewKind.TooLarge, D.PreviewKind);
        Assert.Contains("too large", D.PreviewMessage);
    }

    [Fact]
    public async Task FoldersAndMultipleSelections_HaveNoPreview()
    {
        _k.Seed("a.txt");
        _k.Seed("b.txt");
        _k.Seed("c.txt", null, "Legal");
        await D.InitializeAsync();

        _k.Select("Legal");
        await D.PreviewTask;
        Assert.Equal(PreviewKind.None, D.PreviewKind);

        _k.Select("a.txt", "b.txt");
        await D.PreviewTask;
        Assert.Equal(PreviewKind.None, D.PreviewKind);
        Assert.Equal("2 items selected", D.PreviewTitle);
    }

    [Fact]
    public async Task PreviewCanBeSwitchedOff()
    {
        _k.Seed("notes.txt");
        await D.InitializeAsync();
        _k.Settings.ShowPreview = false;

        _k.Select("notes.txt");
        await D.PreviewTask;

        Assert.Equal(PreviewKind.None, D.PreviewKind);
        Assert.Equal("", D.PreviewText);
    }

    [Fact]
    public async Task TurningPreviewOff_ClearsWhatIsShown()
    {
        _k.Seed("notes.txt", System.Text.Encoding.UTF8.GetBytes("secret text"));
        await D.InitializeAsync();
        _k.Select("notes.txt");
        await D.PreviewTask;
        Assert.Equal("secret text", D.PreviewText);

        _k.Settings.ShowPreview = false;
        await D.PreviewTask;

        Assert.Equal("", D.PreviewText);
        Assert.Equal(PreviewKind.None, D.PreviewKind);
    }

    [Fact]
    public async Task APreviewOfADamagedFile_ShowsAFriendlyError()
    {
        FileEntry e = _k.Seed("notes.txt", Data.Bytes(500));
        await D.InitializeAsync();
        Data.FlipByte(_k.Paths.BlobPath(e.Id), 150);

        _k.Select("notes.txt");
        await D.PreviewTask;

        Assert.Equal(PreviewKind.Error, D.PreviewKind);
        Assert.Contains("integrity check", D.PreviewMessage);
        Assert.Equal("", D.PreviewText);
    }
}
