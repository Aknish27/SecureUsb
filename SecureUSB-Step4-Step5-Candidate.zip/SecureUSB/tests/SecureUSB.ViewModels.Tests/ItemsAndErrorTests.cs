using System.Text.RegularExpressions;
using SecureUSB.Core;
using SecureUSB.Models;
using SecureUSB.Storage;

namespace SecureUSB.ViewModels.Tests;

public class VaultItemBuilderTests
{
    private static readonly DateTimeOffset Now = new(2026, 3, 4, 10, 30, 0, TimeSpan.Zero);

    private static FileEntry E(string name, string folder = "", long size = 100, int dayOffset = 0) => new()
    {
        Id = Guid.NewGuid(), Name = name, FolderPath = folder, SizeBytes = size, ChunkSize = 1 << 20,
        AddedUtc = Now, ModifiedUtc = Now.AddDays(dayOffset)
    };

    private static string[] Names(IEnumerable<VaultItemViewModel> items) => items.Select(i => i.Name).ToArray();

    [Fact]
    public void RootListing_ShowsFoldersFirst_ThenFilesSortedByName()
    {
        var all = new List<FileEntry> { E("zeta.txt"), E("alpha.txt"), E("a.pdf", "Legal"), E("b.pdf", "HR/Staff") };
        IReadOnlyList<VaultItemViewModel> rows = VaultItemBuilder.Build(all, "", null);

        Assert.Equal(new[] { "HR", "Legal", "alpha.txt", "zeta.txt" }, Names(rows));
        Assert.True(rows[0].IsFolder && rows[1].IsFolder);
        Assert.False(rows[2].IsFolder);
    }

    [Fact]
    public void FolderRow_SummarisesEverythingInsideIt()
    {
        var all = new List<FileEntry>
        {
            E("a.txt", "Legal", 1024, 1), E("b.txt", "Legal/2026", 2048, 5), E("c.txt", "Other", 1)
        };
        VaultItemViewModel legal = VaultItemBuilder.Build(all, "", null).Single(i => i.Name == "Legal");

        Assert.Equal("Folder", legal.Type);
        Assert.Equal("Legal", legal.FolderFullPath);
        Assert.Equal(3072, legal.SizeBytes);
        Assert.Equal("2 files \u00B7 3.0 KB", legal.SizeText);
        Assert.Equal(Now.AddDays(5), legal.Modified);
        Assert.Null(legal.Entry);
    }

    [Fact]
    public void InsideAFolder_ShowsItsSubfoldersAndFiles()
    {
        var all = new List<FileEntry> { E("a.txt", "Legal"), E("b.txt", "Legal/2026"), E("c.txt", "Legal/2027/Q1"), E("d.txt") };
        IReadOnlyList<VaultItemViewModel> rows = VaultItemBuilder.Build(all, "Legal", null);

        Assert.Equal(new[] { "2026", "2027", "a.txt" }, Names(rows));
        Assert.Equal("Legal/2027", rows[1].FolderFullPath);
        Assert.Equal("Legal", rows[1].Location);
    }

    [Fact]
    public void FolderNames_AreGroupedIgnoringCase()
    {
        var all = new List<FileEntry> { E("a.txt", "Legal"), E("b.txt", "LEGAL") };
        Assert.Single(VaultItemBuilder.Build(all, "", null));
    }

    [Fact]
    public void Search_ShowsMatchingFilesFromEveryFolder_Flat()
    {
        var all = new List<FileEntry> { E("Report.pdf", "Finance"), E("report-old.pdf", "Finance/Archive"), E("photo.jpg", "HR"), E("notes.txt") };
        IReadOnlyList<VaultItemViewModel> rows = VaultItemBuilder.Build(all, "", "REPORT");

        Assert.Equal(new[] { "report-old.pdf", "Report.pdf" }, Names(rows));   // '-' sorts before '.'
        Assert.All(rows, r => Assert.False(r.IsFolder));
        Assert.Equal("Finance/Archive", rows[0].Location);
        Assert.Equal("Finance", rows[1].Location);
    }

    [Fact]
    public void Search_AlsoMatchesFolderNames_AndIgnoresTheCurrentFolder()
    {
        var all = new List<FileEntry> { E("a.txt", "Contracts"), E("b.txt", "Other") };
        Assert.Equal(new[] { "a.txt" }, Names(VaultItemBuilder.Build(all, "Other", "contracts")));
        Assert.Empty(VaultItemBuilder.Build(all, "", "nothing-matches"));
    }

    [Fact]
    public void WhitespaceQuery_IsNotASearch()
    {
        var all = new List<FileEntry> { E("a.txt", "Dir") };
        Assert.Equal(new[] { "Dir" }, Names(VaultItemBuilder.Build(all, "", "   ")));
    }

    [Fact]
    public void DamagedFiles_AreFlagged_AndTheirFoldersNeedAttention()
    {
        FileEntry bad = E("bad.pdf", "Legal");
        FileEntry good = E("good.pdf", "Legal");
        FileEntry rootBad = E("root.pdf");
        var statuses = new Dictionary<Guid, ItemStatus> { [bad.Id] = ItemStatus.Damaged, [rootBad.Id] = ItemStatus.Damaged };
        var all = new List<FileEntry> { bad, good, rootBad };

        IReadOnlyList<VaultItemViewModel> rows = VaultItemBuilder.Build(all, "", null, statuses);
        Assert.Equal("Needs attention", rows.Single(r => r.IsFolder).StatusText);
        Assert.True(rows.Single(r => r.IsFolder).IsDamaged);
        Assert.Equal("Damaged", rows.Single(r => r.Name == "root.pdf").StatusText);

        IReadOnlyList<VaultItemViewModel> inside = VaultItemBuilder.Build(all, "Legal", null, statuses);
        Assert.Equal("Damaged", inside.Single(r => r.Name == "bad.pdf").StatusText);
        Assert.Equal("Encrypted", inside.Single(r => r.Name == "good.pdf").StatusText);
    }

    [Fact]
    public void FileRow_DescribesTypeSizeAndDate()
    {
        VaultItemViewModel row = VaultItemBuilder.Build(new[] { E("report.PDF", "", 1536) }, "", null).Single();

        Assert.Equal("PDF document", row.Type);
        Assert.Equal("1.5 KB", row.SizeText);
        Assert.Matches(new Regex(@"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$"), row.DateText);
        Assert.Equal("Encrypted", row.StatusText);
    }

    [Fact]
    public void FilesUnder_ReturnsTheWholeSubtree()
    {
        var all = new List<FileEntry> { E("a", "Legal"), E("b", "Legal/2026"), E("c", "LegalX"), E("d") };
        Assert.Equal(new[] { "a", "b" }, VaultItemBuilder.FilesUnder(all, "Legal").Select(f => f.Name).OrderBy(n => n).ToArray());
    }

    [Theory]
    [InlineData(".pdf", "PDF document")]
    [InlineData(".DOCX", "Word document")]
    [InlineData(".jpg", "JPEG image")]
    [InlineData(".xyz", "XYZ file")]
    [InlineData("", "File")]
    public void FileTypes_AreDescribedInPlainWords(string extension, string expected)
    {
        Assert.Equal(expected, FileTypeDescriber.Describe(extension));
    }

    [Theory]
    [InlineData(".png", 1000L, PreviewKind.Image)]
    [InlineData(".PNG", 1000L, PreviewKind.Image)]
    [InlineData(".jpg", 9L * 1024 * 1024, PreviewKind.TooLarge)]
    [InlineData(".txt", 1000L, PreviewKind.Text)]
    [InlineData(".json", 2L * 1024 * 1024, PreviewKind.TooLarge)]
    [InlineData(".pdf", 10L, PreviewKind.Unsupported)]
    [InlineData(".exe", 10L, PreviewKind.Unsupported)]
    [InlineData("", 10L, PreviewKind.Unsupported)]
    public void PreviewClassifier_DecidesWhatMayBeShownInMemory(string extension, long size, PreviewKind expected)
    {
        Assert.Equal(expected, PreviewClassifier.Classify(extension, size));
    }
}

public class ErrorMessagesTests
{
    private const string HostPath = @"C:\Users\bob\AppData\Local\Temp\SecureUSB-123\secret-merger.docx";

    [Theory]
    [InlineData("Cannot access " + HostPath)]
    [InlineData("The process cannot access the file 'E:\\SecureUSB_Data\\blobs\\abc.blob'")]
    public void IoErrors_NeverRevealPathsOrFileNames(string raw)
    {
        string text = ErrorMessages.Describe(new IOException(raw));
        Assert.DoesNotContain("C:", text);
        Assert.DoesNotContain("E:", text);
        Assert.DoesNotContain("secret-merger", text);
        Assert.DoesNotContain("SecureUSB_Data", text);
        Assert.Contains("USB drive", text);
    }

    [Fact]
    public void SpecificFileSystemErrors_GetSpecificButSafeWording()
    {
        Assert.Equal("The file could not be found.", ErrorMessages.Describe(new FileNotFoundException("missing " + HostPath, HostPath)));
        Assert.Equal("The folder could not be found.", ErrorMessages.Describe(new DirectoryNotFoundException(HostPath)));
        string denied = ErrorMessages.Describe(new UnauthorizedAccessException("Access to the path '" + HostPath + "' is denied."));
        Assert.DoesNotContain("Users", denied);
        Assert.Contains("denied", denied);
    }

    [Fact]
    public void IntegrityFailures_ExplainTheRiskWithoutInternals()
    {
        string text = ErrorMessages.Describe(new System.Security.Cryptography.CryptographicException("Integrity check failed at chunk 7"));
        Assert.Contains("integrity check", text);
        Assert.DoesNotContain("chunk 7", text);
        string damaged = ErrorMessages.Describe(new VaultCorruptException("No readable vault header at E:\\SecureUSB_Data"));
        Assert.Contains("damaged", damaged);
        Assert.DoesNotContain("E:", damaged);
    }

    [Fact]
    public void MessagesWrittenForUsers_PassThrough()
    {
        Assert.Equal("A file named 'a.txt' already exists in the vault.", ErrorMessages.Describe(new DuplicateEntryException("a.txt")));
        Assert.Contains("Not enough free space", ErrorMessages.Describe(new InsufficientSpaceException(10_000_000, 1_000)));
        Assert.Contains("per-file limit", ErrorMessages.Describe(new FileTooLargeException(5L << 30, 4L << 30, "FAT32")));
        Assert.Equal("Name contains the forbidden character '/'.",
            ErrorMessages.Describe(new InvalidEntryNameException("Name contains the forbidden character '/'.", "name")));
    }

    [Fact]
    public void ParameterNames_AreStrippedFromMessages()
    {
        var ex = new InvalidEntryNameException("Name is empty.", "newName");
        string text = ErrorMessages.Describe(ex);
        Assert.Equal("Name is empty.", text);
        Assert.DoesNotContain("Parameter", text);
    }

    [Fact]
    public void ArgumentErrors_OnlyShowSecureUsbsOwnSentences()
    {
        Assert.Equal("This folder contains the SecureUSB vault itself and cannot be added.",
            ErrorMessages.Describe(new ArgumentException("This folder contains the SecureUSB vault itself and cannot be added.", "sourceDirectory")));

        Assert.Equal(ErrorMessages.Unexpected, ErrorMessages.Describe(new ArgumentException("Illegal characters in path: " + HostPath)));
        Assert.Equal(ErrorMessages.Unexpected, ErrorMessages.Describe(new InvalidOperationException("Sequence contains no elements")));
        // even a SecureUSB-sounding message is blocked if it contains a path
        Assert.Equal(ErrorMessages.Unexpected, ErrorMessages.Describe(new InvalidOperationException("vault problem at " + HostPath)));
    }

    [Fact]
    public void UnknownExceptions_ShowNothingFromTheException()
    {
        string text = ErrorMessages.Describe(new NullReferenceException("password was hunter2 in " + HostPath));
        Assert.Equal(ErrorMessages.Unexpected, text);
        Assert.DoesNotContain("hunter2", text);
    }

    [Fact]
    public void StatesThatAreNotErrors_HaveCalmWording()
    {
        Assert.Equal("The vault is locked.", ErrorMessages.Describe(new VaultLockedException()));
        Assert.Equal("The vault is locked.", ErrorMessages.Describe(new ObjectDisposedException("x")));
        Assert.Equal("The operation was cancelled.", ErrorMessages.Describe(new OperationCanceledException()));
        Assert.Equal("That item no longer exists in the vault.", ErrorMessages.Describe(new EntryNotFoundException(Guid.NewGuid())));
    }

    [Fact]
    public void PasswordRules_AreShownAsWritten()
    {
        var ex = new PasswordRejectedException(new[] { "Use at least 12 characters.", "Try a passphrase." });
        Assert.Equal("Use at least 12 characters. Try a passphrase.", ErrorMessages.Describe(ex));
    }
}
