using SecureUSB.Core;
using SecureUSB.Models;
using SecureUSB.Storage;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels.Tests;

public class ChangePasswordViewModelTests : IDisposable
{
    private readonly ServiceKit _k = new();

    public ChangePasswordViewModelTests() => _k.Unlocked();

    public void Dispose() => _k.Dispose();

    private ChangePasswordViewModel NewVm() => new(_k.Service);

    private static ChangePasswordViewModel Fill(ChangePasswordViewModel vm, string current = Pw.P1, string next = Pw.P2)
    {
        vm.CurrentPassword = current;
        vm.NewPassword = next;
        vm.Confirmation = next;
        return vm;
    }

    [Fact]
    public void ChangeIsOnlyPossibleWhenEverythingIsValid()
    {
        ChangePasswordViewModel vm = NewVm();
        Assert.False(vm.CanChange);
        Assert.False(vm.ChangeCommand.CanExecute(null));

        Fill(vm);
        Assert.True(vm.CanChange);
        Assert.True(vm.ChangeCommand.CanExecute(null));

        vm.Confirmation = Pw.P3;
        Assert.False(vm.CanChange);
        Assert.Equal("The passwords do not match.", vm.MismatchText);

        vm.Confirmation = Pw.P2;
        vm.CurrentPassword = "";
        Assert.False(vm.CanChange);
    }

    [Fact]
    public void AWeakNewPassword_IsRefusedWithAdvice()
    {
        ChangePasswordViewModel vm = Fill(NewVm(), next: "Password123!");
        Assert.False(vm.CanChange);
        Assert.NotEmpty(vm.PolicyMessages);
        Assert.InRange(vm.StrengthLevel, 0, 2);
    }

    [Fact]
    public void TheNewPassword_MustDifferFromTheCurrentOne()
    {
        ChangePasswordViewModel vm = Fill(NewVm(), Pw.P1, Pw.P1);
        Assert.False(vm.CanChange);
    }

    [Fact]
    public void TheStrengthMeterFollowsTheNewPassword()
    {
        ChangePasswordViewModel vm = NewVm();
        Assert.Equal(-1, vm.StrengthLevel);
        vm.NewPassword = Pw.P2;
        Assert.InRange(vm.StrengthLevel, 3, 4);
        Assert.True(vm.StrengthFraction >= 0.8);
        Assert.NotEqual("", vm.StrengthText);
    }

    [Fact]
    public async Task Success_ClosesTheDialog_ClearsTheFields_AndTheNewPasswordWorks()
    {
        ChangePasswordViewModel vm = Fill(NewVm());
        bool closed = false;
        vm.CloseRequested += () => closed = true;

        await vm.ChangeCommand.ExecuteAsync();

        Assert.True(vm.Succeeded);
        Assert.True(closed);
        Assert.Equal("", vm.CurrentPassword);
        Assert.Equal("", vm.NewPassword);
        Assert.Equal("", vm.Confirmation);
        _k.Service.Lock();
        Assert.True(_k.Service.Unlock(Pw.P2).Succeeded);
    }

    [Fact]
    public async Task AWrongCurrentPassword_IsExplained_AndNothingChanges()
    {
        ChangePasswordViewModel vm = Fill(NewVm(), Pw.Wrong, Pw.P2);

        await vm.ChangeCommand.ExecuteAsync();

        Assert.False(vm.Succeeded);
        Assert.Equal("The current password is incorrect.", vm.ErrorMessage);
        Assert.True(vm.HasError);
        Assert.False(vm.IsBusy);
        _k.Service.Lock();
        Assert.True(_k.Service.Unlock(Pw.P1).Succeeded);   // still the old password
    }

    [Fact]
    public async Task RepeatedWrongAttempts_ShowTheCooldown()
    {
        ChangePasswordViewModel vm = Fill(NewVm(), Pw.Wrong, Pw.P2);
        await vm.ChangeCommand.ExecuteAsync();
        await vm.ChangeCommand.ExecuteAsync();
        await vm.ChangeCommand.ExecuteAsync();

        Assert.Contains("Too many failed attempts", vm.ErrorMessage);
        Assert.Contains("5 seconds", vm.ErrorMessage);
    }

    [Fact]
    public async Task IfTheVaultLocksMeanwhile_TheDialogJustCloses()
    {
        ChangePasswordViewModel vm = Fill(NewVm());
        bool closed = false;
        vm.CloseRequested += () => closed = true;
        _k.Service.Lock();

        await vm.ChangeCommand.ExecuteAsync();

        Assert.True(closed);
        Assert.False(vm.Succeeded);
        Assert.Equal("", vm.ErrorMessage);
    }

    [Fact]
    public void ClosingTheDialog_WipesWhatWasTyped()
    {
        ChangePasswordViewModel vm = Fill(NewVm());
        vm.OnClosed();
        Assert.Equal("", vm.CurrentPassword);
        Assert.Equal("", vm.NewPassword);
        Assert.Equal("", vm.Confirmation);
    }

    [Fact]
    public void ShowPasswords_CanBeToggled()
    {
        ChangePasswordViewModel vm = NewVm();
        vm.ToggleShowPasswordsCommand.Execute(null);
        Assert.True(vm.ShowPasswords);
    }

    [Fact]
    public void TheDialogClosesWhenTheVaultLocks()
    {
        Assert.True(NewVm().ClosesOnLock);
    }
}

public class ActivityLogViewModelTests : IDisposable
{
    private readonly ServiceKit _k = new();

    public ActivityLogViewModelTests() => _k.Unlocked();

    public void Dispose() => _k.Dispose();

    [Fact]
    public async Task ShowsTheEvents_NewestFirst_InPlainWords()
    {
        _k.Service.AddFile(_k.Source("report.pdf"));
        _k.Service.Lock();
        _k.Service.Unlock(Pw.P1);

        var vm = new ActivityLogViewModel(_k.Service);
        await vm.LoadTask;

        Assert.False(vm.IsLoading);
        Assert.Equal(new[] { "Unlocked", "Locked", "File added", "Vault created" }, vm.Rows.Select(r => r.Kind).ToArray());
        Assert.Contains("report.pdf", vm.Rows[2].Message);
        Assert.Matches(@"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", vm.Rows[0].Time);
        Assert.False(vm.HasWarning);
    }

    [Fact]
    public async Task TheFilterNarrowsTheList()
    {
        _k.Service.AddFile(_k.Source("report.pdf"));
        var vm = new ActivityLogViewModel(_k.Service);
        await vm.LoadTask;

        vm.FilterText = "report";
        Assert.Single(vm.Rows);

        vm.FilterText = "created";   // matches the readable event name too
        Assert.Single(vm.Rows);

        vm.FilterText = "nothing like this";
        Assert.Empty(vm.Rows);

        vm.FilterText = "";
        Assert.Equal(2, vm.Rows.Count);
    }

    [Fact]
    public async Task ATamperedLog_ShowsAWarning_AndKeepsTheVerifiedPart()
    {
        _k.Service.AddFile(_k.Source("a.txt"));
        _k.Service.AddFile(_k.Source("b.txt"));
        Data.FlipByte(_k.Paths.LogPath, (int)new FileInfo(_k.Paths.LogPath).Length - 10);   // damage the newest record

        var vm = new ActivityLogViewModel(_k.Service);
        await vm.LoadTask;

        Assert.True(vm.HasWarning);
        Assert.Contains("failed verification", vm.WarningText);
        Assert.NotEmpty(vm.Rows);
    }

    [Fact]
    public async Task Refresh_PicksUpNewEvents()
    {
        var vm = new ActivityLogViewModel(_k.Service);
        await vm.LoadTask;
        int before = vm.Rows.Count;

        _k.Service.AddFile(_k.Source("new.txt"));
        await vm.RefreshCommand.ExecuteAsync();

        Assert.Equal(before + 1, vm.Rows.Count);
    }

    [Fact]
    public async Task IfTheVaultLocks_TheDialogCloses()
    {
        var vm = new ActivityLogViewModel(_k.Service);
        await vm.LoadTask;
        bool closed = false;
        vm.CloseRequested += () => closed = true;
        _k.Service.Lock();

        await vm.RefreshCommand.ExecuteAsync();

        Assert.True(closed);
    }
}

public class HealthViewModelTests : IDisposable
{
    private readonly DashboardKit _k = new();
    private readonly HealthStatus _status = new();
    private readonly List<IntegrityReport> _reports = new();
    private int _repaired;

    public void Dispose() => _k.Dispose();

    private HealthViewModel NewVm() =>
        new(_k.Service, _status, _k.Dialogs, _reports.Add, () => _repaired++, _k.T.Time);

    [Fact]
    public async Task AQuickCheckOfAHealthyVault_ReportsNoProblems()
    {
        _k.Seed("a.txt");
        HealthViewModel vm = NewVm();

        await vm.QuickCheckCommand.ExecuteAsync();

        Assert.Equal(HealthLevel.Healthy, _status.Level);
        Assert.Equal("No problems found", _status.Text);
        Assert.False(vm.HasIssues);
        Assert.Single(_reports);
        Assert.Contains("quick", _status.LastChecked);
        Assert.False(vm.RepairCommand.CanExecute(null));   // nothing to repair
    }

    [Fact]
    public async Task AMissingFile_IsShownAsAProblem()
    {
        FileEntry e = _k.Seed("a.txt");
        File.Delete(_k.Paths.BlobPath(e.Id));
        HealthViewModel vm = NewVm();

        await vm.QuickCheckCommand.ExecuteAsync();

        Assert.Equal(HealthLevel.Error, _status.Level);
        Assert.True(vm.HasIssues);
        HealthIssueRow row = Assert.Single(vm.Issues);
        Assert.Equal("Error", row.Severity);
        Assert.Contains("a.txt", row.Message);
        Assert.DoesNotContain(_k.T.Root, row.Message);
        Assert.True(vm.RepairCommand.CanExecute(null));
    }

    [Fact]
    public async Task OnlyTheFullCheck_FindsSilentCorruption()
    {
        FileEntry e = _k.Seed("a.bin", Data.Bytes(50_000));
        Data.FlipByte(_k.Paths.BlobPath(e.Id), 5000);
        HealthViewModel vm = NewVm();

        await vm.QuickCheckCommand.ExecuteAsync();
        Assert.Equal(HealthLevel.Healthy, _status.Level);

        await vm.FullCheckCommand.ExecuteAsync();
        Assert.Equal(HealthLevel.Error, _status.Level);
        Assert.Contains("verification", Assert.Single(vm.Issues).Message);
        Assert.Contains("full check", _status.LastChecked);
    }

    [Fact]
    public async Task Repair_AsksFirst_AndRecoversUnlistedFiles()
    {
        FileEntry a = _k.Seed("a.txt", Data.Bytes(200, 1));
        _k.Seed("b.txt", Data.Bytes(200, 2));
        // simulate a lost index entry: the previous index revision comes back
        _k.Service.Lock();
        Data.FlipByte(_k.Paths.IndexPath, 200);
        Assert.True(_k.Service.Unlock(Pw.P1).Succeeded);
        Assert.Single(_k.Service.ListFiles());

        HealthViewModel vm = NewVm();
        await vm.QuickCheckCommand.ExecuteAsync();
        Assert.True(vm.HasIssues);
        Assert.True(vm.RecoverOrphans);

        await vm.RepairCommand.ExecuteAsync();

        ConfirmRequest asked = Assert.Single(_k.Dialogs.Confirms);
        Assert.False(asked.IsDestructive);
        Assert.Equal(2, _k.Service.ListFiles().Count);
        Assert.Contains("1 file(s) recovered", vm.ResultText);
        Assert.Equal(1, _repaired);
        Assert.Equal(HealthLevel.Healthy, _status.Level);
        Assert.NotNull(a);
    }

    [Fact]
    public async Task DestructiveRepairOptions_NeedAnExplicitWarning()
    {
        FileEntry e = _k.Seed("a.txt");
        File.Delete(_k.Paths.BlobPath(e.Id));
        HealthViewModel vm = NewVm();
        await vm.QuickCheckCommand.ExecuteAsync();
        vm.RemoveMissingEntries = true;

        await vm.RepairCommand.ExecuteAsync();

        Assert.True(Assert.Single(_k.Dialogs.Confirms).IsDestructive);
        Assert.Empty(_k.Service.ListFiles());
        Assert.Equal(HealthLevel.Healthy, _status.Level);
    }

    [Fact]
    public async Task DecliningTheRepairWarning_ChangesNothing()
    {
        FileEntry e = _k.Seed("a.txt");
        File.Delete(_k.Paths.BlobPath(e.Id));
        HealthViewModel vm = NewVm();
        await vm.QuickCheckCommand.ExecuteAsync();
        vm.RemoveMissingEntries = true;
        _k.Dialogs.ConfirmAnswers.Enqueue(false);

        await vm.RepairCommand.ExecuteAsync();

        Assert.Single(_k.Service.ListFiles());
        Assert.Equal(0, _repaired);
    }

    [Fact]
    public void RecoverAndDeleteAreMutuallyExclusive()
    {
        HealthViewModel vm = NewVm();
        Assert.True(vm.RecoverOrphans);

        vm.DeleteOrphans = true;
        Assert.False(vm.RecoverOrphans);

        vm.RecoverOrphans = true;
        Assert.False(vm.DeleteOrphans);
    }

    [Fact]
    public async Task TheDialogShowsTheLatestResultWhenOpenedAgain()
    {
        HealthViewModel first = NewVm();
        await first.QuickCheckCommand.ExecuteAsync();

        HealthViewModel second = NewVm();

        Assert.Equal(HealthLevel.Healthy, second.Status.Level);
        Assert.False(second.QuickCheckCommand.IsRunning);
    }

    [Fact]
    public async Task IfTheVaultLocksDuringACheck_TheDialogCloses()
    {
        HealthViewModel vm = NewVm();
        bool closed = false;
        vm.CloseRequested += () => closed = true;
        _k.Service.Lock();

        await vm.QuickCheckCommand.ExecuteAsync();

        Assert.True(closed);
        Assert.Equal("", vm.ErrorMessage);
    }
}

public class SettingsViewModelTests : IDisposable
{
    private readonly ServiceKit _k = new();
    private readonly SessionSettings _settings = new();
    private readonly FakeDialogs _dialogs = new();

    public SettingsViewModelTests() => _k.Unlocked();

    public void Dispose() => _k.Dispose();

    private SettingsViewModel NewVm() => new(_settings, _k.Service, _dialogs, new AppInfo("SecureUSB", "2.3.4"));

    [Fact]
    public void ShowsTheCurrentSettings()
    {
        SettingsViewModel vm = NewVm();
        Assert.Equal(10, vm.SelectedAutoLock.Minutes);
        Assert.False(vm.AllowOpenInOtherPrograms);
        Assert.True(vm.ShowPreview);
        Assert.True(vm.IsLightTheme);
        Assert.False(vm.IsDarkTheme);
        Assert.Equal(6, vm.AutoLockChoices.Count);
    }

    [Fact]
    public void TheAutoLockChoice_UpdatesTheSettings()
    {
        SettingsViewModel vm = NewVm();
        var changes = new List<string?>();
        vm.PropertyChanged += (_, e) => changes.Add(e.PropertyName);

        vm.SelectedAutoLock = vm.AutoLockChoices.Single(c => c.Minutes == 30);

        Assert.Equal(30, _settings.AutoLockMinutes);
        Assert.Contains("SelectedAutoLock", changes);
    }

    [Fact]
    public async Task EnablingOpenInOtherPrograms_RequiresAnInformedYes()
    {
        SettingsViewModel vm = NewVm();
        _dialogs.ConfirmAnswers.Enqueue(false);
        await vm.ToggleOpenInOtherProgramsCommand.ExecuteAsync();
        Assert.False(_settings.AllowOpenInOtherPrograms);

        _dialogs.ConfirmAnswers.Enqueue(true);
        await vm.ToggleOpenInOtherProgramsCommand.ExecuteAsync();
        Assert.True(_settings.AllowOpenInOtherPrograms);
        Assert.True(vm.AllowOpenInOtherPrograms);

        ConfirmRequest warning = _dialogs.Confirms[0];
        Assert.Contains("temporary decrypted copy", warning.Message);
        Assert.True(warning.IsDestructive);
    }

    [Fact]
    public async Task DisablingItNeedsNoQuestion()
    {
        SettingsViewModel vm = NewVm();
        _settings.AllowOpenInOtherPrograms = true;

        await vm.ToggleOpenInOtherProgramsCommand.ExecuteAsync();

        Assert.False(_settings.AllowOpenInOtherPrograms);
        Assert.Empty(_dialogs.Confirms);
    }

    [Fact]
    public void TheThemeChoices_AreMutuallyExclusive()
    {
        SettingsViewModel vm = NewVm();

        vm.IsDarkTheme = true;
        Assert.Equal(ThemeKind.Dark, _settings.Theme);
        Assert.False(vm.IsLightTheme);

        vm.IsLightTheme = true;
        Assert.Equal(ThemeKind.Light, _settings.Theme);
        Assert.False(vm.IsDarkTheme);
    }

    [Fact]
    public void PreviewCanBeSwitchedOff()
    {
        SettingsViewModel vm = NewVm();
        vm.ShowPreview = false;
        Assert.False(_settings.ShowPreview);
    }

    [Fact]
    public async Task RemovingTemporaryFiles_ReportsWhatHappened()
    {
        SettingsViewModel vm = NewVm();
        await vm.CleanTemporaryFilesCommand.ExecuteAsync();
        Assert.Contains("no temporary decrypted files", vm.TemporaryFilesMessage);

        FileEntry e = _k.Service.AddFile(_k.Source("a.txt"));
        string temp = _k.Service.OpenTemporaryCopy(e.Id);
        await vm.CleanTemporaryFilesCommand.ExecuteAsync();

        Assert.Contains("Removed 1", vm.TemporaryFilesMessage);
        Assert.False(File.Exists(temp));
    }

    [Fact]
    public void AboutTheProduct_IsHonestAboutLimits()
    {
        SettingsViewModel vm = NewVm();

        Assert.Equal("2.3.4", vm.App.Version);
        Assert.Contains(vm.SecuritySummary, l => l.Contains("AES-256-GCM"));
        Assert.Contains(vm.SecuritySummary, l => l.Contains("Argon2id"));
        Assert.Contains(vm.Limitations, l => l.Contains("no backdoor"));
        Assert.Contains(vm.Limitations, l => l.Contains("weak password", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(vm.Limitations, l => l.Contains("keylogger"));
    }

    [Fact]
    public void ChangesMadeElsewhere_AreReflected_AndUnhookedWhenClosed()
    {
        SettingsViewModel vm = NewVm();
        var changes = new List<string?>();
        vm.PropertyChanged += (_, e) => changes.Add(e.PropertyName);

        _settings.Theme = ThemeKind.Dark;
        Assert.Contains("IsDarkTheme", changes);

        vm.OnClosed();
        changes.Clear();
        _settings.Theme = ThemeKind.Light;
        Assert.Empty(changes);
    }
}
