namespace SecureUSB.Cryptography.Tests;

public class SecureBytesAndRandomTests
{
    [Fact]
    public void Dispose_MakesBufferInaccessible()
    {
        var sb = SecureBytes.CopyFrom(new byte[] { 1, 2, 3 });
        Assert.False(sb.IsDisposed);
        sb.Dispose();
        Assert.True(sb.IsDisposed);
        Assert.Throws<ObjectDisposedException>(() => sb.Span.Length);
        sb.Dispose(); // idempotent
    }

    [Fact]
    public void CopyFrom_CopiesData()
    {
        using var sb = SecureBytes.CopyFrom(new byte[] { 9, 8, 7 });
        Assert.Equal(new byte[] { 9, 8, 7 }, sb.Span.ToArray());
    }

    [Fact]
    public void SecureRandom_ProducesDistinctValues()
    {
        Assert.NotEqual(SecureRandom.GetBytes(32), SecureRandom.GetBytes(32));
        Assert.NotEqual(SecureRandom.NewGuid(), SecureRandom.NewGuid());
    }
}
