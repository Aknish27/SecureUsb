using System.Security.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Cryptography.Tests;

public class VaultKeyManagerTests
{
    private static bool SameIndexKey(VaultKeys a, VaultKeys b)
    {
        using var ka = a.DeriveKey(KeyPurpose.Index);
        using var kb = b.DeriveKey(KeyPurpose.Index);
        return CryptographicOperations.FixedTimeEquals(ka.Span, kb.Span);
    }

    [Fact]
    public void CreateThenUnlock_YieldsSameMasterKey()
    {
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        using VaultKeys created = nv.Keys;
        using VaultKeys unlocked = VaultKeyManager.Unlock(TestData.Password, VaultHeader.Parse(nv.Header.ToBytes()));
        Assert.Equal(created.VaultId, unlocked.VaultId);
        Assert.True(SameIndexKey(created, unlocked));
    }

    [Fact]
    public void Unlock_WrongPassword_Throws()
    {
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        nv.Keys.Dispose();
        Assert.Throws<VaultAuthenticationException>(() => VaultKeyManager.Unlock(TestData.OtherPassword, nv.Header));
        Assert.Throws<VaultAuthenticationException>(() => VaultKeyManager.Unlock(TestData.Password + " ", nv.Header));
    }

    [Fact]
    public void EveryVault_HasUniqueIdSaltAndMasterKey()
    {
        var a = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        var b = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf); // same password!
        using (a.Keys) using (b.Keys)
        {
            Assert.NotEqual(a.Header.VaultId, b.Header.VaultId);
            Assert.NotEqual(a.Header.Salt.ToArray(), b.Header.Salt.ToArray());
            Assert.NotEqual(a.Header.WrappedMasterKey.ToArray(), b.Header.WrappedMasterKey.ToArray());
            Assert.False(SameIndexKey(a.Keys, b.Keys));
        }
    }

    [Fact]
    public void HeaderContainsNoPlaintextPasswordOrKey()
    {
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        using (nv.Keys)
        {
            byte[] bytes = nv.Header.ToBytes();
            byte[] pwBytes = System.Text.Encoding.UTF8.GetBytes(TestData.Password);
            Assert.Equal(-1, bytes.AsSpan().IndexOf(pwBytes));
        }
    }

    [Fact]
    public void BitFlipInAnyAuthenticatedHeaderField_PreventsUnlock()
    {
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        nv.Keys.Dispose();
        byte[] good = nv.Header.ToBytes();

        var ranges = new (int Start, int Length)[]
        {
            (VaultHeader.VaultIdOffset, 16),
            (VaultHeader.SaltOffset, KdfParams.SaltLength),
            (VaultHeader.WrappedKeyOffset, VaultHeader.WrappedKeyLength)
        };

        foreach (var (start, length) in ranges)
        {
            for (int i = start; i < start + length; i++)
            {
                byte[] bad = (byte[])good.Clone();
                bad[i] ^= 0x01;
                VaultHeader tampered = VaultHeader.Parse(bad);   // structurally valid
                Assert.Throws<VaultAuthenticationException>(() => VaultKeyManager.Unlock(TestData.Password, tampered));
            }
        }
    }

    [Fact]
    public void TamperedKdfCost_PreventsUnlock()
    {
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        nv.Keys.Dispose();
        byte[] bad = nv.Header.ToBytes();
        bad[VaultHeader.KdfIterationsOffset + 3] = 2;   // iterations 1 -> 2
        VaultHeader tampered = VaultHeader.Parse(bad);
        Assert.Throws<VaultAuthenticationException>(() => VaultKeyManager.Unlock(TestData.Password, tampered));
    }

    [Fact]
    public void ChangePassword_KeepsMasterKey_NewPasswordWorks_OldFails()
    {
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        using VaultKeys original = nv.Keys;

        VaultHeader changed = VaultKeyManager.ChangePassword(TestData.Password, TestData.OtherPassword, nv.Header);

        Assert.Equal(nv.Header.VaultId, changed.VaultId);
        Assert.NotEqual(nv.Header.Salt.ToArray(), changed.Salt.ToArray());                  // fresh salt
        Assert.NotEqual(nv.Header.WrappedMasterKey.ToArray(), changed.WrappedMasterKey.ToArray());

        using VaultKeys viaNew = VaultKeyManager.Unlock(TestData.OtherPassword, changed);
        Assert.True(SameIndexKey(original, viaNew));   // same master key => existing files stay readable
        Assert.Throws<VaultAuthenticationException>(() => VaultKeyManager.Unlock(TestData.Password, changed));
    }

    [Fact]
    public void ChangePassword_WrongCurrentPassword_Throws_AndOriginalHeaderStillWorks()
    {
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        nv.Keys.Dispose();
        Assert.Throws<VaultAuthenticationException>(() =>
            VaultKeyManager.ChangePassword(TestData.OtherPassword, "brand new password phrase", nv.Header));
        VaultKeyManager.Unlock(TestData.Password, nv.Header).Dispose();
    }

    [Fact]
    public void ChangePassword_CanRaiseKdfCost()
    {
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        nv.Keys.Dispose();
        var stronger = new KdfParams(KdfParams.MinMemoryKiB * 2, 2, 1);
        VaultHeader changed = VaultKeyManager.ChangePassword(TestData.Password, TestData.Password, nv.Header, stronger);
        Assert.Equal(stronger, changed.Kdf);
        VaultKeyManager.Unlock(TestData.Password, changed).Dispose();
    }
}
