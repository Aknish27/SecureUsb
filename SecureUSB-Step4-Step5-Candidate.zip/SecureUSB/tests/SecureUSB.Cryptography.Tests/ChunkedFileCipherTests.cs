using System.Security.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Cryptography.Tests;

public class ChunkedFileCipherTests
{
    private const int SmallChunk = 1024;
    private const int StreamHeader = 20;
    private const int Tag = 16;

    private static readonly FileBinding Binding = new(
        Guid.Parse("11111111-1111-1111-1111-111111111111"),
        Guid.Parse("22222222-2222-2222-2222-222222222222"));

    private static byte[] Key(byte fill = 0xA5) => Enumerable.Repeat(fill, 32).ToArray();

    private static byte[] Encrypt(byte[] plain, byte[]? key = null, FileBinding? binding = null, int chunk = SmallChunk)
    {
        using var input = new MemoryStream(plain);
        using var output = new MemoryStream();
        long n = ChunkedFileCipher.Encrypt(input, output, key ?? Key(), binding ?? Binding, chunk);
        Assert.Equal(plain.Length, n);
        return output.ToArray();
    }

    private static byte[] Decrypt(byte[] cipher, byte[]? key = null, FileBinding? binding = null)
    {
        using var input = new MemoryStream(cipher);
        using var output = new MemoryStream();
        ChunkedFileCipher.Decrypt(input, output, key ?? Key(), binding ?? Binding);
        return output.ToArray();
    }

    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(1023)]
    [InlineData(1024)]
    [InlineData(1025)]
    [InlineData(2048)]
    [InlineData(3000)]
    [InlineData(10_000)]
    public void RoundTrip_AcrossChunkBoundaries(int length)
    {
        byte[] plain = TestData.RandomData(length);
        byte[] cipher = Encrypt(plain);
        Assert.Equal(ChunkedFileCipher.CiphertextLength(length, SmallChunk), cipher.Length);
        Assert.Equal(plain, Decrypt(cipher));
    }

    [Fact]
    public void RoundTrip_WithDefaultChunkSize()
    {
        byte[] plain = TestData.RandomData(2_500_000);
        using var input = new MemoryStream(plain);
        using var output = new MemoryStream();
        ChunkedFileCipher.Encrypt(input, output, Key(), Binding);
        Assert.Equal(ChunkedFileCipher.CiphertextLength(plain.Length), output.Length);

        output.Position = 0;
        using var restored = new MemoryStream();
        ChunkedFileCipher.Decrypt(output, restored, Key(), Binding);
        Assert.Equal(plain, restored.ToArray());
    }

    [Fact]
    public void Ciphertext_DoesNotContainPlaintext()
    {
        byte[] marker = System.Text.Encoding.ASCII.GetBytes("TOP-SECRET-MARKER-0123456789");
        byte[] plain = new byte[5000];
        for (int i = 0; i + marker.Length <= plain.Length; i += marker.Length)
            marker.CopyTo(plain, i);

        byte[] cipher = Encrypt(plain);
        Assert.Equal(-1, cipher.AsSpan().IndexOf(marker));
    }

    [Fact]
    public void EncryptingTwice_ProducesDifferentCiphertext()
    {
        byte[] plain = TestData.RandomData(3000);
        Assert.NotEqual(Encrypt(plain), Encrypt(plain));
    }

    [Fact]
    public void WrongKey_Fails()
    {
        byte[] cipher = Encrypt(TestData.RandomData(3000));
        Assert.Throws<DataIntegrityException>(() => Decrypt(cipher, Key(0x11)));
    }

    [Fact]
    public void WrongFileId_Fails_PreventsSwappingBlobsBetweenFiles()
    {
        byte[] cipher = Encrypt(TestData.RandomData(3000));
        var other = new FileBinding(Binding.VaultId, Guid.NewGuid());
        Assert.Throws<DataIntegrityException>(() => Decrypt(cipher, binding: other));
    }

    [Fact]
    public void WrongVaultId_Fails_PreventsMovingBlobsBetweenVaults()
    {
        byte[] cipher = Encrypt(TestData.RandomData(3000));
        var other = new FileBinding(Guid.NewGuid(), Binding.FileId);
        Assert.Throws<DataIntegrityException>(() => Decrypt(cipher, binding: other));
    }

    [Fact]
    public void FlippingAnySingleByte_IsDetected()
    {
        byte[] cipher = Encrypt(TestData.RandomData(2500));   // 3 chunks incl. header, chunk sizes, tags
        for (int i = 0; i < cipher.Length; i++)
        {
            byte[] bad = (byte[])cipher.Clone();
            bad[i] ^= 0x01;
            Assert.Throws<DataIntegrityException>(() => Decrypt(bad));
        }
    }

    [Fact]
    public void TruncationAtAnyPoint_IsDetected()
    {
        byte[] cipher = Encrypt(TestData.RandomData(2500));
        for (int length = 0; length < cipher.Length; length++)
        {
            byte[] cut = cipher.AsSpan(0, length).ToArray();
            Assert.Throws<DataIntegrityException>(() => Decrypt(cut));
        }
    }

    [Fact]
    public void TruncationExactlyAtChunkBoundary_IsDetected()
    {
        byte[] cipher = Encrypt(TestData.RandomData(3 * SmallChunk));   // exactly 3 full chunks
        int oneChunk = SmallChunk + Tag;
        byte[] cut = cipher.AsSpan(0, StreamHeader + 2 * oneChunk).ToArray();
        Assert.Throws<DataIntegrityException>(() => Decrypt(cut));
    }

    [Theory]
    [InlineData(2500)]
    [InlineData(3 * SmallChunk)]
    public void AppendedData_IsDetected(int plainLength)
    {
        byte[] cipher = Encrypt(TestData.RandomData(plainLength));
        byte[] extended = cipher.Concat(new byte[] { 0x42 }).ToArray();
        Assert.Throws<DataIntegrityException>(() => Decrypt(extended));

        byte[] extendedByChunk = cipher.Concat(TestData.RandomData(SmallChunk + Tag, 99)).ToArray();
        Assert.Throws<DataIntegrityException>(() => Decrypt(extendedByChunk));
    }

    [Fact]
    public void ReorderedChunks_AreDetected()
    {
        byte[] cipher = Encrypt(TestData.RandomData(3 * SmallChunk));
        int oneChunk = SmallChunk + Tag;
        byte[] bad = (byte[])cipher.Clone();
        Array.Copy(cipher, StreamHeader + oneChunk, bad, StreamHeader, oneChunk);           // chunk1 -> slot0
        Array.Copy(cipher, StreamHeader, bad, StreamHeader + oneChunk, oneChunk);           // chunk0 -> slot1
        Assert.Throws<DataIntegrityException>(() => Decrypt(bad));
    }

    [Fact]
    public void DuplicatedChunk_IsDetected()
    {
        byte[] cipher = Encrypt(TestData.RandomData(3 * SmallChunk));
        int oneChunk = SmallChunk + Tag;
        byte[] bad = (byte[])cipher.Clone();
        Array.Copy(cipher, StreamHeader, bad, StreamHeader + oneChunk, oneChunk);           // chunk0 over chunk1
        Assert.Throws<DataIntegrityException>(() => Decrypt(bad));
    }

    [Fact]
    public void NotAnEncryptedFile_IsRejected()
    {
        Assert.Throws<DataIntegrityException>(() => Decrypt(TestData.RandomData(500)));
        Assert.Throws<DataIntegrityException>(() => Decrypt(Array.Empty<byte>()));
    }

    [Fact]
    public void Cancellation_IsHonored()
    {
        using var cts = new CancellationTokenSource();
        cts.Cancel();
        using var input = new MemoryStream(TestData.RandomData(5000));
        using var output = new MemoryStream();
        Assert.Throws<OperationCanceledException>(() =>
            ChunkedFileCipher.Encrypt(input, output, Key(), Binding, SmallChunk, cts.Token));
    }

    [Fact]
    public void InvalidArguments_AreRejected()
    {
        using var input = new MemoryStream(new byte[10]);
        using var output = new MemoryStream();
        Assert.Throws<ArgumentException>(() => ChunkedFileCipher.Encrypt(input, output, new byte[31], Binding));
        Assert.Throws<ArgumentOutOfRangeException>(() => ChunkedFileCipher.Encrypt(input, output, Key(), Binding, 100));
        Assert.Throws<ArgumentOutOfRangeException>(() => ChunkedFileCipher.CiphertextLength(10, 100));
    }

    /// <summary>Full key-hierarchy flow: password -> vault -> file key -> encrypt, lock, unlock, decrypt.</summary>
    [Fact]
    public void EndToEnd_PasswordToFile_SurvivesLockAndUnlock()
    {
        byte[] plain = TestData.RandomData(70_000);
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        byte[] headerOnDisk = nv.Header.ToBytes();

        Guid fileId = SecureRandom.NewGuid();
        var binding = new FileBinding(nv.Header.VaultId, fileId);
        byte[] wrappedFileKey;
        byte[] blob;
        using (VaultKeys keys = nv.Keys)
        using (SecureBytes fileKey = keys.GenerateFileKey())
        {
            wrappedFileKey = keys.WrapFileKey(fileKey.Span, fileId);
            using var input = new MemoryStream(plain);
            using var output = new MemoryStream();
            ChunkedFileCipher.Encrypt(input, output, fileKey.Span, binding);
            blob = output.ToArray();
        }   // vault "locked": all keys zeroed

        using VaultKeys reopened = VaultKeyManager.Unlock(TestData.Password, VaultHeader.Parse(headerOnDisk));
        using SecureBytes recoveredKey = reopened.UnwrapFileKey(wrappedFileKey, fileId);
        using var cipherIn = new MemoryStream(blob);
        using var restored = new MemoryStream();
        ChunkedFileCipher.Decrypt(cipherIn, restored, recoveredKey.Span, binding);

        Assert.Equal(plain, restored.ToArray());
    }
}
