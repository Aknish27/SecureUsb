using System.Security.Cryptography;

namespace SecureUSB.Cryptography.Tests;

public class VaultKeysTests
{
    private static VaultKeys NewKeys() => VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf).Keys;

    [Fact]
    public void SubkeysAreDeterministicAndDomainSeparated()
    {
        using var keys = NewKeys();
        using var i1 = keys.DeriveKey(KeyPurpose.Index);
        using var i2 = keys.DeriveKey(KeyPurpose.Index);
        using var log = keys.DeriveKey(KeyPurpose.ActivityLog);
        using var wrap = keys.DeriveKey(KeyPurpose.FileKeyWrapping);

        Assert.True(CryptographicOperations.FixedTimeEquals(i1.Span, i2.Span));
        Assert.False(CryptographicOperations.FixedTimeEquals(i1.Span, log.Span));
        Assert.False(CryptographicOperations.FixedTimeEquals(i1.Span, wrap.Span));
        Assert.False(CryptographicOperations.FixedTimeEquals(log.Span, wrap.Span));
    }

    [Fact]
    public void FileKeyWrap_RoundTrips()
    {
        using var keys = NewKeys();
        Guid fileId = SecureRandom.NewGuid();
        using var fileKey = keys.GenerateFileKey();
        byte[] wrapped = keys.WrapFileKey(fileKey.Span, fileId);
        using var unwrapped = keys.UnwrapFileKey(wrapped, fileId);
        Assert.True(CryptographicOperations.FixedTimeEquals(fileKey.Span, unwrapped.Span));
    }

    [Fact]
    public void FileKeysAreUniquePerFile()
    {
        using var keys = NewKeys();
        using var a = keys.GenerateFileKey();
        using var b = keys.GenerateFileKey();
        Assert.False(CryptographicOperations.FixedTimeEquals(a.Span, b.Span));
    }

    [Fact]
    public void UnwrapWithWrongFileId_Fails()
    {
        using var keys = NewKeys();
        using var fileKey = keys.GenerateFileKey();
        byte[] wrapped = keys.WrapFileKey(fileKey.Span, SecureRandom.NewGuid());
        Assert.ThrowsAny<CryptographicException>(() => keys.UnwrapFileKey(wrapped, SecureRandom.NewGuid()));
    }

    [Fact]
    public void UnwrapWithAnotherVaultsKeys_Fails()
    {
        using var vaultA = NewKeys();
        using var vaultB = NewKeys();
        Guid fileId = SecureRandom.NewGuid();
        using var fileKey = vaultA.GenerateFileKey();
        byte[] wrapped = vaultA.WrapFileKey(fileKey.Span, fileId);
        Assert.ThrowsAny<CryptographicException>(() => vaultB.UnwrapFileKey(wrapped, fileId));
    }

    [Fact]
    public void TamperedWrappedFileKey_Fails()
    {
        using var keys = NewKeys();
        Guid fileId = SecureRandom.NewGuid();
        using var fileKey = keys.GenerateFileKey();
        byte[] wrapped = keys.WrapFileKey(fileKey.Span, fileId);
        wrapped[20] ^= 0x01;
        Assert.ThrowsAny<CryptographicException>(() => keys.UnwrapFileKey(wrapped, fileId));
    }

    [Fact]
    public void Lock_ZeroesAndDisablesKeys()
    {
        var keys = NewKeys();
        keys.Dispose();
        Assert.True(keys.IsDisposed);
        Assert.Throws<ObjectDisposedException>(() => keys.DeriveKey(KeyPurpose.Index));
    }
}
