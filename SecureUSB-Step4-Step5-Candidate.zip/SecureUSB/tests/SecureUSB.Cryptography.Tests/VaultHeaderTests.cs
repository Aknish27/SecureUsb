using SecureUSB.Models;

namespace SecureUSB.Cryptography.Tests;

public class VaultHeaderTests
{
    private static VaultHeader NewHeader()
    {
        var nv = VaultKeyManager.CreateVault(TestData.Password, TestData.FastKdf);
        nv.Keys.Dispose();
        return nv.Header;
    }

    [Fact]
    public void LayoutConstants_AreConsistent()
    {
        Assert.Equal(71, VaultHeader.AuthenticatedPrefixLength);
        Assert.Equal(60, VaultHeader.WrappedKeyLength);
        Assert.Equal(131, VaultHeader.TotalLength);
        Assert.Equal(VaultHeader.TotalLength, NewHeader().ToBytes().Length);
    }

    [Fact]
    public void RoundTrip_PreservesAllFields()
    {
        VaultHeader h = NewHeader();
        VaultHeader parsed = VaultHeader.Parse(h.ToBytes());
        Assert.Equal(h.VaultId, parsed.VaultId);
        Assert.Equal(h.Kdf, parsed.Kdf);
        Assert.Equal(h.Salt.ToArray(), parsed.Salt.ToArray());
        Assert.Equal(h.WrappedMasterKey.ToArray(), parsed.WrappedMasterKey.ToArray());
        Assert.Equal(h.ToBytes(), parsed.ToBytes());
    }

    [Theory]
    [InlineData(130)]
    [InlineData(132)]
    [InlineData(0)]
    public void Parse_WrongLength_Throws(int length)
    {
        Assert.Throws<InvalidVaultFormatException>(() => VaultHeader.Parse(new byte[length]));
    }

    [Fact]
    public void Parse_BadMagic_Throws()
    {
        byte[] b = NewHeader().ToBytes();
        b[0] ^= 0xFF;
        Assert.Throws<InvalidVaultFormatException>(() => VaultHeader.Parse(b));
    }

    [Fact]
    public void Parse_UnsupportedVersion_Throws()
    {
        byte[] b = NewHeader().ToBytes();
        b[9] = 2; // version 2
        Assert.Throws<InvalidVaultFormatException>(() => VaultHeader.Parse(b));
    }

    [Fact]
    public void Parse_UnsupportedKdf_Throws()
    {
        byte[] b = NewHeader().ToBytes();
        b[VaultHeader.KdfIdOffset] = 9;
        Assert.Throws<InvalidVaultFormatException>(() => VaultHeader.Parse(b));
    }

    [Fact]
    public void Parse_AbsurdKdfMemory_IsRejectedBeforeAnyAllocation()
    {
        byte[] b = NewHeader().ToBytes();
        b[VaultHeader.KdfMemoryOffset] = 0x7F;   // ~2 TiB request
        Assert.Throws<InvalidVaultFormatException>(() => VaultHeader.Parse(b));
    }

    [Fact]
    public void Constructor_RejectsWrongFieldSizes()
    {
        Assert.Throws<ArgumentException>(() =>
            new VaultHeader(Guid.NewGuid(), TestData.FastKdf, new byte[16], new byte[VaultHeader.WrappedKeyLength]));
        Assert.Throws<ArgumentException>(() =>
            new VaultHeader(Guid.NewGuid(), TestData.FastKdf, new byte[32], new byte[10]));
    }

    [Fact]
    public void KdfParams_Validate_EnforcesBounds()
    {
        Assert.Throws<InvalidVaultFormatException>(() => new KdfParams(1024, 3, 4).Validate());
        Assert.Throws<InvalidVaultFormatException>(() => new KdfParams(65536, 0, 4).Validate());
        Assert.Throws<InvalidVaultFormatException>(() => new KdfParams(65536, 3, 0).Validate());
        KdfParams.Default.Validate();
        Assert.True(KdfParams.Default.MeetsProductionPolicy);
        Assert.False(TestData.FastKdf.MeetsProductionPolicy);
    }
}
