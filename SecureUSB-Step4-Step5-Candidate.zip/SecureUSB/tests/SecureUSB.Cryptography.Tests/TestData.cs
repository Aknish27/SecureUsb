using SecureUSB.Models;

namespace SecureUSB.Cryptography.Tests;

internal static class TestData
{
    /// <summary>Minimum-cost Argon2id parameters so the suite runs in seconds. Never use outside tests.</summary>
    public static readonly KdfParams FastKdf = new(MemoryKiB: KdfParams.MinMemoryKiB, Iterations: 1, Parallelism: 1);

    public const string Password = "correct horse battery staple";
    public const string OtherPassword = "a completely different passphrase";

    public static byte[] RandomData(int length, int seed = 1234)
    {
        var data = new byte[length];
        new Random(seed).NextBytes(data);
        return data;
    }
}
