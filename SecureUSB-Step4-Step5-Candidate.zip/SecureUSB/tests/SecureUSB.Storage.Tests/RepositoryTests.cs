using System.Text;
using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Storage.Tests;

public class RepositoryTests : IDisposable
{
    private readonly TempVault _t = new();
    private readonly List<IDisposable> _toDispose = new();

    public void Dispose()
    {
        for (int i = _toDispose.Count - 1; i >= 0; i--) _toDispose[i].Dispose();
        _t.Dispose();
    }

    private (VaultRepository Repo, VaultKeys Keys, VaultHeader Header) Create()
    {
        NewVault nv = Harness.NewVault();
        _toDispose.Add(nv.Keys);
        VaultRepository repo = VaultRepository.Initialize(_t.Paths, nv.Header, nv.Keys, _t.Drive, _t.Time);
        _toDispose.Add(repo);
        return (repo, nv.Keys, nv.Header);
    }

    private VaultRepository Reopen(VaultKeys keys)
    {
        VaultRepository repo = VaultRepository.Open(_t.Paths, keys, _t.Drive, _t.Time);
        _toDispose.Add(repo);
        return repo;
    }

    private static FileEntry Add(VaultRepository repo, string name, byte[] data, string folder = "", ConflictPolicy c = ConflictPolicy.Reject)
    {
        using var ms = new MemoryStream(data);
        return repo.AddFile(ms, name, folder, conflict: c);
    }

    private static byte[] Export(VaultRepository repo, Guid id)
    {
        using var ms = new MemoryStream();
        repo.ExportToStream(id, ms);
        return ms.ToArray();
    }

    private string[] BlobFiles() =>
        Directory.Exists(_t.Paths.BlobsDirectory) ? Directory.GetFiles(_t.Paths.BlobsDirectory) : Array.Empty<string>();

    // ------------------------------------------------------------------ create / persist

    [Fact]
    public void Initialize_CreatesVaultLayout()
    {
        var (repo, _, header) = Create();

        Assert.Equal(header.VaultId, repo.VaultId);
        Assert.Empty(repo.List());
        Assert.Equal(1, repo.Revision);
        Assert.True(File.Exists(_t.Paths.HeaderPath));
        Assert.True(File.Exists(_t.Paths.HeaderBackupPath));
        Assert.True(File.Exists(_t.Paths.IndexPath));
        Assert.True(Directory.Exists(_t.Paths.BlobsDirectory));
        Assert.True(File.Exists(_t.Paths.LockPath));
    }

    [Fact]
    public void Initialize_OnExistingVault_Refuses()
    {
        var (repo, _, _) = Create();
        repo.Dispose();
        NewVault other = Harness.NewVault();
        _toDispose.Add(other.Keys);

        Assert.Throws<InvalidOperationException>(() =>
            VaultRepository.Initialize(_t.Paths, other.Header, other.Keys, _t.Drive, _t.Time));
    }

    [Fact]
    public void Initialize_RejectsHeaderFromAnotherVault()
    {
        NewVault a = Harness.NewVault();
        NewVault b = Harness.NewVault();
        _toDispose.Add(a.Keys);
        _toDispose.Add(b.Keys);
        Assert.Throws<ArgumentException>(() => VaultRepository.Initialize(_t.Paths, a.Header, b.Keys, _t.Drive, _t.Time));
    }

    [Fact]
    public void AddedFile_SurvivesLockAndUnlockWithThePassword()
    {
        // The full user story at storage level: create -> add -> lock -> unlock with the ONE password -> read.
        var (repo, keys, header) = Create();
        byte[] content = Harness.Data(250_000);
        FileEntry added = Add(repo, "confidential.pdf", content, "HR");

        repo.Dispose();
        keys.Dispose();   // Lock USB

        var store = new VaultHeaderStore(_t.Paths);
        HeaderLoadResult loaded = store.Load();
        VaultKeys unlocked = VaultKeyManager.Unlock(Harness.Password, loaded.Header);
        _toDispose.Add(unlocked);
        store.Heal(loaded.Header);

        VaultRepository reopened = Reopen(unlocked);
        FileEntry found = Assert.Single(reopened.List());
        Assert.Equal(added.Id, found.Id);
        Assert.Equal("confidential.pdf", found.Name);
        Assert.Equal("HR", found.FolderPath);
        Assert.Equal(content.Length, found.SizeBytes);
        Assert.Equal(content, Export(reopened, found.Id));
        Assert.Equal(header.VaultId, reopened.VaultId);
    }

    [Fact]
    public void NothingReadableIsWrittenToTheUsb_NeitherContentNorNames()
    {
        var (repo, _, _) = Create();
        byte[] marker = Encoding.ASCII.GetBytes("PLAINTEXT-MARKER-FOR-TESTING-0123456789");
        byte[] data = new byte[300_000];
        for (int i = 0; i + marker.Length <= data.Length; i += marker.Length) marker.CopyTo(data, i);

        Add(repo, "TopSecretProject.docx", data, "Legal/Merger2026");
        Add(repo, "employee_photo.jpg", Harness.Data(5000));

        Assert.False(Harness.DiskContains(_t.Root, marker));
        foreach (string needle in new[] { "TopSecretProject", "Merger2026", "employee_photo" })
        {
            Assert.False(Harness.DiskContains(_t.Root, Encoding.ASCII.GetBytes(needle)), needle);
            Assert.False(Harness.DiskContains(_t.Root, Encoding.Unicode.GetBytes(needle)), needle + " (UTF-16)");
            Assert.DoesNotContain(Harness.AllFiles(_t.Root), f => f.Contains(needle, StringComparison.OrdinalIgnoreCase));
        }
    }

    // ------------------------------------------------------------------ names / conflicts

    [Fact]
    public void DuplicateNames_AreRejected_CaseInsensitively()
    {
        var (repo, _, _) = Create();
        Add(repo, "report.pdf", Harness.Data(10));

        Assert.Throws<DuplicateEntryException>(() => Add(repo, "REPORT.PDF", Harness.Data(10)));
        Assert.Single(repo.List());
        Assert.Single(BlobFiles());   // the rejected add left nothing behind
        Add(repo, "report.pdf", Harness.Data(10), folder: "Other");   // same name, different folder is fine
    }

    [Fact]
    public void AutoRename_AppendsCounter()
    {
        var (repo, _, _) = Create();
        Add(repo, "report.pdf", Harness.Data(10));
        FileEntry second = Add(repo, "report.pdf", Harness.Data(10), c: ConflictPolicy.AutoRename);
        FileEntry third = Add(repo, "report.pdf", Harness.Data(10), c: ConflictPolicy.AutoRename);

        Assert.Equal("report (2).pdf", second.Name);
        Assert.Equal("report (3).pdf", third.Name);
        Assert.Equal(3, repo.List().Count);
    }

    [Theory]
    [InlineData("a/b.txt")]
    [InlineData("..")]
    [InlineData("CON")]
    [InlineData("evil\u202Egpj.exe")]
    [InlineData("")]
    public void InvalidFileNames_AreRejected_BeforeAnythingIsWritten(string name)
    {
        var (repo, _, _) = Create();
        Assert.Throws<InvalidEntryNameException>(() => Add(repo, name, Harness.Data(10)));
        Assert.Empty(BlobFiles());
        Assert.Empty(repo.List());
    }

    [Fact]
    public void InvalidFolderPath_IsRejected()
    {
        var (repo, _, _) = Create();
        Assert.Throws<InvalidEntryNameException>(() => Add(repo, "ok.txt", Harness.Data(10), folder: "../outside"));
        Assert.Empty(BlobFiles());
    }

    [Fact]
    public void Rename_PersistsAndEnforcesRules()
    {
        var (repo, keys, _) = Create();
        FileEntry a = Add(repo, "a.txt", Harness.Data(10));
        Add(repo, "b.txt", Harness.Data(10));

        FileEntry renamed = repo.Rename(a.Id, "renamed.txt");
        Assert.Equal("renamed.txt", renamed.Name);
        Assert.Throws<DuplicateEntryException>(() => repo.Rename(a.Id, "B.TXT"));
        Assert.Throws<InvalidEntryNameException>(() => repo.Rename(a.Id, "bad/name"));
        Assert.Throws<EntryNotFoundException>(() => repo.Rename(Guid.NewGuid(), "x.txt"));

        repo.Dispose();
        VaultRepository again = Reopen(keys);
        Assert.Contains(again.List(), f => f.Name == "renamed.txt");
        Assert.DoesNotContain(again.List(), f => f.Name == "a.txt");
    }

    [Fact]
    public void Delete_RemovesEntryAndBlob_Persistently()
    {
        var (repo, keys, _) = Create();
        FileEntry a = Add(repo, "a.txt", Harness.Data(10));
        FileEntry b = Add(repo, "b.txt", Harness.Data(10));

        repo.Delete(a.Id);
        Assert.Null(repo.Find(a.Id));
        Assert.False(File.Exists(_t.Paths.BlobPath(a.Id)));
        Assert.True(File.Exists(_t.Paths.BlobPath(b.Id)));
        Assert.Throws<EntryNotFoundException>(() => repo.Delete(a.Id));

        repo.Dispose();
        Assert.Equal(new[] { "b.txt" }, Reopen(keys).List().Select(f => f.Name).ToArray());
    }

    [Fact]
    public void Search_IsCaseInsensitive_AndMatchesFolders()
    {
        var (repo, _, _) = Create();
        Add(repo, "Annual Report.pdf", Harness.Data(5), "Finance");
        Add(repo, "photo.jpg", Harness.Data(5), "HR/Staff");
        Add(repo, "notes.txt", Harness.Data(5));

        Assert.Equal(new[] { "Annual Report.pdf" }, repo.Search("report").Select(f => f.Name).ToArray());
        Assert.Equal(new[] { "photo.jpg" }, repo.Search("staff").Select(f => f.Name).ToArray());
        Assert.Equal(3, repo.Search("").Count);
        Assert.Equal(3, repo.Search("   ").Count);
        Assert.Empty(repo.Search("nomatch"));
    }

    // ------------------------------------------------------------------ export / read

    [Fact]
    public void ExportToFile_RoundTrips_AndRefusesToOverwriteByDefault()
    {
        var (repo, _, _) = Create();
        byte[] data = Harness.Data(70_000);
        FileEntry e = Add(repo, "doc.bin", data);
        string outDir = _t.NewSubfolder("exports");
        string dest = Path.Combine(outDir, "doc.bin");

        repo.ExportToFile(e.Id, dest);
        Assert.Equal(data, File.ReadAllBytes(dest));

        File.WriteAllBytes(dest, new byte[] { 1 });
        Assert.ThrowsAny<IOException>(() => repo.ExportToFile(e.Id, dest));
        Assert.Equal(new byte[] { 1 }, File.ReadAllBytes(dest));

        repo.ExportToFile(e.Id, dest, overwrite: true);
        Assert.Equal(data, File.ReadAllBytes(dest));
        Assert.Single(Directory.GetFiles(outDir));   // no .part leftovers
    }

    [Fact]
    public void ExportOfTamperedBlob_FailsAndLeavesNoPlaintextBehind()
    {
        var (repo, _, _) = Create();
        FileEntry e = Add(repo, "doc.bin", Harness.Data(5 * 1024 * 1024));   // several chunks
        Harness.FlipByte(_t.Paths.BlobPath(e.Id), (int)(new FileInfo(_t.Paths.BlobPath(e.Id)).Length - 100));   // damage the LAST chunk
        string outDir = _t.NewSubfolder("exports");

        Assert.Throws<DataIntegrityException>(() => repo.ExportToFile(e.Id, Path.Combine(outDir, "doc.bin")));

        // earlier chunks had already been decrypted when the last one failed: they must have been wiped and removed
        Assert.Empty(Directory.GetFiles(outDir));
    }

    [Fact]
    public void ExportOfMissingBlob_ReportsCorruption()
    {
        var (repo, _, _) = Create();
        FileEntry e = Add(repo, "doc.bin", Harness.Data(100));
        File.Delete(_t.Paths.BlobPath(e.Id));
        string outDir = _t.NewSubfolder("exports");

        Assert.Throws<VaultCorruptException>(() => repo.ExportToFile(e.Id, Path.Combine(outDir, "doc.bin")));
        Assert.Empty(Directory.GetFiles(outDir));
    }

    [Fact]
    public void ExportToMissingFolder_Fails()
    {
        var (repo, _, _) = Create();
        FileEntry e = Add(repo, "doc.bin", Harness.Data(100));
        Assert.Throws<DirectoryNotFoundException>(() => repo.ExportToFile(e.Id, Path.Combine(_t.Root, "nope", "doc.bin")));
    }

    [Fact]
    public void ReadAllBytes_DecryptsInMemory_AndEnforcesLimit()
    {
        var (repo, _, _) = Create();
        byte[] data = Harness.Data(5000);
        FileEntry e = Add(repo, "x.bin", data);

        Assert.Equal(data, repo.ReadAllBytes(e.Id, maxBytes: 10_000));
        Assert.Throws<InvalidOperationException>(() => repo.ReadAllBytes(e.Id, maxBytes: 4999));

        FileEntry empty = Add(repo, "empty.bin", Array.Empty<byte>());
        Assert.Empty(repo.ReadAllBytes(empty.Id, 10));
    }

    // ------------------------------------------------------------------ interruptions / failures

    [Fact]
    public void SourceFailureMidAdd_LeavesNoTraceAndVaultStaysUsable()
    {
        var (repo, keys, _) = Create();
        using (var failing = new FailingReadStream(3 * 1024 * 1024, 1_500_000))
            Assert.Throws<IOException>(() => repo.AddFile(failing, "big.bin"));

        Assert.Empty(repo.List());
        Assert.Empty(BlobFiles());
        Add(repo, "after.txt", Harness.Data(10));

        repo.Dispose();
        Assert.Single(Reopen(keys).List());
    }

    [Fact]
    public void IndexSaveFailure_RollsBack_AndRemovesTheNewBlob()
    {
        var (repo, keys, _) = Create();
        Add(repo, "first.txt", Harness.Data(10));
        long revisionBefore = repo.Revision;

        Directory.CreateDirectory(_t.Paths.IndexTempPath);   // simulated device failure while saving the index
        Assert.ThrowsAny<Exception>(() => Add(repo, "second.txt", Harness.Data(10)));

        Assert.Equal(revisionBefore, repo.Revision);
        Assert.Equal(new[] { "first.txt" }, repo.List().Select(f => f.Name).ToArray());
        Assert.Single(BlobFiles());

        Directory.Delete(_t.Paths.IndexTempPath);            // "drive recovered"
        Add(repo, "second.txt", Harness.Data(10));
        repo.Dispose();
        Assert.Equal(2, Reopen(keys).List().Count);
    }

    [Fact]
    public void Cancellation_LeavesNothingBehind()
    {
        var (repo, _, _) = Create();
        using var cts = new CancellationTokenSource();
        cts.Cancel();
        using var ms = new MemoryStream(Harness.Data(5000));

        Assert.Throws<OperationCanceledException>(() => repo.AddFile(ms, "x.bin", ct: cts.Token));
        Assert.Empty(repo.List());
        Assert.Empty(BlobFiles());
    }

    [Fact]
    public void FullDrive_IsReportedBeforeWriting()
    {
        var (repo, _, _) = Create();
        _t.Drive.Free = 2 * 1024 * 1024;

        Assert.Throws<InsufficientSpaceException>(() => Add(repo, "big.bin", Harness.Data(100_000)));
        Assert.Empty(repo.List());
        Assert.Empty(BlobFiles());
    }

    [Fact]
    public void Fat32_RefusesFilesOverFourGiB()
    {
        var (repo, _, _) = Create();
        _t.Drive.FileSystem = "FAT32";
        using var huge = new HugeStream(5L * 1024 * 1024 * 1024);

        Assert.Throws<FileTooLargeException>(() => repo.AddFile(huge, "huge.iso"));
        Assert.Empty(BlobFiles());
    }

    [Fact]
    public void LockedKeys_StopAllOperations()
    {
        var (repo, keys, _) = Create();
        FileEntry e = Add(repo, "x.bin", Harness.Data(100));

        keys.Dispose();   // lock (e.g. USB removed -> keys wiped)

        Assert.Throws<ObjectDisposedException>(() => Add(repo, "y.bin", Harness.Data(10)));
        Assert.Throws<ObjectDisposedException>(() => repo.ReadAllBytes(e.Id, 1000));
    }

    [Fact]
    public void DisposedRepository_ReleasesLock_AndRefusesWork()
    {
        var (repo, keys, _) = Create();
        repo.Dispose();

        Assert.False(File.Exists(_t.Paths.LockPath));
        Assert.Throws<ObjectDisposedException>(() => repo.List());
        Reopen(keys);   // can be reopened
    }

    [Fact]
    public void SecondInstance_CannotOpenTheSameVault()
    {
        var (repo, keys, _) = Create();
        Assert.ThrowsAny<IOException>(() => VaultRepository.Open(_t.Paths, keys, _t.Drive, _t.Time));

        repo.Dispose();
        Reopen(keys);
    }

    // ------------------------------------------------------------------ recovery on open

    [Fact]
    public void Open_RemovesUnfinishedBlobWrites()
    {
        var (repo, keys, _) = Create();
        repo.Dispose();
        string stale = _t.Paths.BlobTempPath(SecureRandom.NewGuid());
        File.WriteAllBytes(stale, Harness.Data(1000));

        Reopen(keys);
        Assert.False(File.Exists(stale));
    }

    [Fact]
    public void Open_CompletesInterruptedInitialisation()
    {
        var (repo, keys, _) = Create();
        repo.Dispose();
        File.Delete(_t.Paths.IndexPath);   // crash after the header but before the first index

        VaultRepository reopened = Reopen(keys);
        Assert.Empty(reopened.List());
        Assert.True(File.Exists(_t.Paths.IndexPath));
    }

    [Fact]
    public void Open_RecoversNewerIndexLeftInTempFile()
    {
        var (repo, keys, _) = Create();
        Add(repo, "one.txt", Harness.Data(10));
        Add(repo, "two.txt", Harness.Data(10));
        repo.Dispose();

        // crash window: the newest index is complete in .tmp, the primary has already been moved away
        File.Move(_t.Paths.IndexPath, _t.Paths.IndexTempPath, overwrite: true);
        Assert.False(File.Exists(_t.Paths.IndexPath));

        VaultRepository reopened = Reopen(keys);
        Assert.Equal(2, reopened.List().Count);
        Assert.True(File.Exists(_t.Paths.IndexPath));
        Assert.False(File.Exists(_t.Paths.IndexTempPath));
    }

    [Fact]
    public void CorruptPrimaryIndex_FallsBackToPrevious_ThenOrphanIsRecovered()
    {
        var (repo, keys, _) = Create();
        FileEntry one = Add(repo, "one.txt", Harness.Data(100, 1));
        FileEntry two = Add(repo, "two.txt", Harness.Data(100, 2));
        repo.Dispose();

        Harness.FlipByte(_t.Paths.IndexPath, 200);

        VaultRepository reopened = Reopen(keys);
        Assert.Equal(new[] { "one.txt" }, reopened.List().Select(f => f.Name).ToArray());   // 'two' was only in the damaged index

        IntegrityReport report = reopened.CheckIntegrity(deep: false);
        IntegrityIssue orphan = Assert.Single(report.OfKind(IssueKind.OrphanBlob));
        Assert.Equal(two.Id, orphan.FileId);

        RepairResult result = reopened.Repair(report, new RepairOptions { Orphans = OrphanAction.Recover });
        Assert.Equal(1, result.OrphansRecovered);

        FileEntry recovered = Assert.Single(reopened.List(), f => f.Id == two.Id);
        Assert.Equal("Recovered", recovered.FolderPath);
        Assert.Equal(Harness.Data(100, 2), Export(reopened, two.Id));
        Assert.Equal(Harness.Data(100, 1), Export(reopened, one.Id));
        Assert.True(reopened.CheckIntegrity(deep: true).IsClean);
    }

    [Fact]
    public void LostIndex_RequiresExplicitRecovery_AndDataComesBack()
    {
        var (repo, keys, _) = Create();
        byte[] d1 = Harness.Data(5000, 1);
        byte[] d2 = Harness.Data(1, 2);
        byte[] d3 = Array.Empty<byte>();
        Add(repo, "a.bin", d1);
        Add(repo, "b.bin", d2);
        Add(repo, "c.bin", d3);
        repo.Dispose();

        foreach (string p in new[] { _t.Paths.IndexPath, _t.Paths.IndexPrevPath, _t.Paths.IndexTempPath })
            if (File.Exists(p)) File.Delete(p);

        Assert.Throws<VaultCorruptException>(() => VaultRepository.Open(_t.Paths, keys, _t.Drive, _t.Time));

        VaultRepository rebuilt = VaultRepository.RebuildIndexFromBlobs(_t.Paths, keys, _t.Drive, _t.Time);
        _toDispose.Add(rebuilt);

        Assert.Equal(3, rebuilt.List().Count);
        Assert.All(rebuilt.List(), f => Assert.Equal("Recovered", f.FolderPath));
        var recoveredData = rebuilt.List().Select(f => Export(rebuilt, f.Id)).OrderBy(b => b.Length).ToList();
        Assert.Equal(new[] { 0, 1, 5000 }, recoveredData.Select(b => b.Length).ToArray());
        Assert.Equal(d1, recoveredData[2]);
    }

    [Fact]
    public void RebuildIgnoresBlobsFromAnotherVault()
    {
        var (repo, keys, _) = Create();
        Add(repo, "mine.bin", Harness.Data(100));
        repo.Dispose();

        // a foreign (other vault's) blob dropped into blobs/
        using VaultKeys foreignKeys = Harness.NewKeys();
        var foreignBlobs = new BlobStore(_t.Paths, _t.Drive);
        Guid foreignId = SecureRandom.NewGuid();
        using (var ms = new MemoryStream(Harness.Data(50)))
            foreignBlobs.WriteTemp(foreignId, ms, foreignKeys, ChunkedFileCipher.DefaultChunkSize);
        foreignBlobs.CommitTemp(foreignId);

        foreach (string p in new[] { _t.Paths.IndexPath, _t.Paths.IndexPrevPath })
            if (File.Exists(p)) File.Delete(p);

        VaultRepository rebuilt = VaultRepository.RebuildIndexFromBlobs(_t.Paths, keys, _t.Drive, _t.Time);
        _toDispose.Add(rebuilt);
        Assert.Single(rebuilt.List());
    }

    // ------------------------------------------------------------------ integrity scanner & repair

    [Fact]
    public void HealthyVault_IsCleanShallowAndDeep()
    {
        var (repo, _, _) = Create();
        Add(repo, "a.bin", Harness.Data(3_000_000));
        Add(repo, "b.bin", Harness.Data(10));

        IntegrityReport shallow = repo.CheckIntegrity(deep: false);
        IntegrityReport deep = repo.CheckIntegrity(deep: true);
        Assert.True(shallow.IsClean);
        Assert.False(shallow.DeepVerified);
        Assert.True(deep.IsClean);
        Assert.True(deep.DeepVerified);
        Assert.Equal(2, deep.FilesChecked);
    }

    [Fact]
    public void Scanner_FindsMissingBlob_AndRepairCanRemoveTheEntry()
    {
        var (repo, _, _) = Create();
        FileEntry a = Add(repo, "a.bin", Harness.Data(100));
        FileEntry b = Add(repo, "b.bin", Harness.Data(100));
        File.Delete(_t.Paths.BlobPath(a.Id));

        IntegrityReport report = repo.CheckIntegrity(false);
        IntegrityIssue issue = Assert.Single(report.Issues);
        Assert.Equal(IssueKind.BlobMissing, issue.Kind);
        Assert.Equal(IssueSeverity.Error, issue.Severity);
        Assert.True(report.HasErrors);

        Assert.Equal(0, repo.Repair(report, new RepairOptions()).EntriesRemoved);   // default: never delete entries silently
        Assert.Equal(2, repo.List().Count);

        RepairResult result = repo.Repair(report, new RepairOptions { RemoveEntriesWithMissingBlobs = true });
        Assert.Equal(1, result.EntriesRemoved);
        Assert.Equal(new[] { b.Id }, repo.List().Select(f => f.Id).ToArray());
        Assert.True(repo.CheckIntegrity(false).IsClean);
    }

    [Fact]
    public void Scanner_FindsTruncatedAndExtendedBlobs_ByExactSize()
    {
        var (repo, _, _) = Create();
        FileEntry a = Add(repo, "a.bin", Harness.Data(5000));
        FileEntry b = Add(repo, "b.bin", Harness.Data(5000));

        string pa = _t.Paths.BlobPath(a.Id);
        File.WriteAllBytes(pa, File.ReadAllBytes(pa).AsSpan(0, (int)new FileInfo(pa).Length - 1).ToArray());
        using (var fs = new FileStream(_t.Paths.BlobPath(b.Id), FileMode.Append)) fs.WriteByte(1);

        IntegrityReport report = repo.CheckIntegrity(false);
        Assert.Equal(2, report.OfKind(IssueKind.BlobSizeMismatch).Count());
    }

    [Fact]
    public void Scanner_DeepScanFindsSameSizeCorruption_ShallowDoesNot()
    {
        var (repo, _, _) = Create();
        FileEntry a = Add(repo, "a.bin", Harness.Data(100_000));
        Harness.FlipByte(_t.Paths.BlobPath(a.Id), 5000);

        Assert.True(repo.CheckIntegrity(deep: false).IsClean);
        IntegrityIssue issue = Assert.Single(repo.CheckIntegrity(deep: true).Issues);
        Assert.Equal(IssueKind.BlobAuthenticationFailed, issue.Kind);
        Assert.Equal(a.Id, issue.FileId);
    }

    [Fact]
    public void Scanner_FindsStrayFiles_AndRepairHonoursOptions()
    {
        var (repo, _, _) = Create();
        Guid orphanId = SecureRandom.NewGuid();
        using (var ms = new MemoryStream(Harness.Data(200)))
        {
            // an orphan: a complete, valid blob that no index lists
            var blobs = new BlobStore(_t.Paths, _t.Drive);
            using VaultKeys unused = Harness.NewKeys();
            blobs.WriteTemp(orphanId, ms, unused, ChunkedFileCipher.DefaultChunkSize);
            blobs.CommitTemp(orphanId);
        }
        string stale = _t.Paths.BlobTempPath(SecureRandom.NewGuid());
        File.WriteAllBytes(stale, new byte[10]);
        string stray = Path.Combine(_t.Paths.BlobsDirectory, "readme.txt");
        File.WriteAllText(stray, "hi");

        IntegrityReport report = repo.CheckIntegrity(false);
        Assert.Single(report.OfKind(IssueKind.OrphanBlob));
        Assert.Single(report.OfKind(IssueKind.StaleBlobTemp));
        Assert.Single(report.OfKind(IssueKind.UnexpectedFile));

        RepairResult keep = repo.Repair(report, new RepairOptions());   // defaults: delete temps, keep orphans
        Assert.Equal(1, keep.TempFilesDeleted);
        Assert.False(File.Exists(stale));
        Assert.True(File.Exists(_t.Paths.BlobPath(orphanId)));
        Assert.True(File.Exists(stray));   // unexpected files are never touched

        RepairResult del = repo.Repair(repo.CheckIntegrity(false), new RepairOptions { Orphans = OrphanAction.Delete });
        Assert.Equal(1, del.OrphansDeleted);
        Assert.False(File.Exists(_t.Paths.BlobPath(orphanId)));
    }

    [Fact]
    public void Recover_RefusesBlobsOfAnotherVault()
    {
        var (repo, _, _) = Create();
        Guid foreignId = SecureRandom.NewGuid();
        using (VaultKeys foreign = Harness.NewKeys())
        using (var ms = new MemoryStream(Harness.Data(200)))
        {
            var blobs = new BlobStore(_t.Paths, _t.Drive);
            blobs.WriteTemp(foreignId, ms, foreign, ChunkedFileCipher.DefaultChunkSize);
            blobs.CommitTemp(foreignId);
        }

        RepairResult r = repo.Repair(repo.CheckIntegrity(false), new RepairOptions { Orphans = OrphanAction.Recover });
        Assert.Equal(0, r.OrphansRecovered);
        Assert.Empty(repo.List());
    }

    [Fact]
    public void Repair_NeverDeletesFilesOutsideTheVault()
    {
        var (repo, _, _) = Create();
        string outside = Path.Combine(_t.Root, "precious.tmp");
        File.WriteAllText(outside, "do not delete");

        var forged = new IntegrityReport(
            new[] { new IntegrityIssue(IssueKind.StaleBlobTemp, IssueSeverity.Warning, "forged", null, outside) }, 0, false);
        RepairResult r = repo.Repair(forged, new RepairOptions());

        Assert.Equal(0, r.TempFilesDeleted);
        Assert.True(File.Exists(outside));
    }

    [Fact]
    public void Scanner_DetectsAndRepairsHeaderProblems()
    {
        var (repo, _, header) = Create();

        // backup missing
        File.Delete(_t.Paths.HeaderBackupPath);
        IntegrityReport r1 = repo.CheckIntegrity(false);
        Assert.Single(r1.OfKind(IssueKind.HeaderBackupMissing));
        Assert.True(repo.Repair(r1, new RepairOptions()).HeaderBackupSynced);
        Assert.Equal(header.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderBackupPath));

        // backup differs from primary
        NewVault other = Harness.NewVault();
        other.Keys.Dispose();
        File.WriteAllBytes(_t.Paths.HeaderBackupPath, other.Header.ToBytes());
        IntegrityReport r2 = repo.CheckIntegrity(false);
        Assert.Single(r2.OfKind(IssueKind.HeaderBackupOutOfSync));
        repo.Repair(r2, new RepairOptions());
        Assert.Equal(header.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderBackupPath));

        // primary damaged, backup good -> restored from backup
        Harness.FlipByte(_t.Paths.HeaderPath, 0);
        IntegrityReport r3 = repo.CheckIntegrity(false);
        Assert.Equal(IssueSeverity.Error, Assert.Single(r3.OfKind(IssueKind.HeaderPrimaryDamaged)).Severity);
        repo.Repair(r3, new RepairOptions());
        Assert.Equal(header.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderPath));
        Assert.True(repo.CheckIntegrity(false).IsClean);
    }

    // ------------------------------------------------------------------ folders / files from disk

    private string MakeTree()
    {
        string root = _t.NewSubfolder("Project X");
        File.WriteAllBytes(Path.Combine(root, "a.txt"), Harness.Data(100, 1));
        string sub = Path.Combine(root, "sub");
        Directory.CreateDirectory(sub);
        File.WriteAllBytes(Path.Combine(sub, "b.txt"), Harness.Data(200, 2));
        string deeper = Path.Combine(sub, "deeper");
        Directory.CreateDirectory(deeper);
        File.WriteAllBytes(Path.Combine(deeper, "c.txt"), Harness.Data(300, 3));
        Directory.CreateDirectory(Path.Combine(root, "empty"));
        return root;
    }

    [Fact]
    public void AddFolder_PreservesStructure_AndContent()
    {
        var (repo, keys, _) = Create();
        string tree = MakeTree();
        var seen = new List<string>();

        AddFolderResult result = repo.AddFolder(tree, progress: new SyncProgress<string>(seen.Add));

        Assert.Equal(3, result.Added);
        Assert.Empty(result.Failures);
        Assert.Equal(3, seen.Count);
        Assert.Equal(
            new[] { "Project X/a.txt", "Project X/sub/b.txt", "Project X/sub/deeper/c.txt" },
            repo.List().Select(f => f.FullPath).OrderBy(p => p, StringComparer.Ordinal).ToArray());

        FileEntry c = repo.List().Single(f => f.Name == "c.txt");
        Assert.Equal(Harness.Data(300, 3), Export(repo, c.Id));

        repo.Dispose();
        Assert.Equal(3, Reopen(keys).List().Count);   // committed durably
    }

    [Fact]
    public void AddFolder_Twice_RenamesOrReportsConflicts()
    {
        var (repo, _, _) = Create();
        string tree = MakeTree();
        repo.AddFolder(tree);

        AddFolderResult renamed = repo.AddFolder(tree, conflict: ConflictPolicy.AutoRename);
        Assert.Equal(3, renamed.Added);
        Assert.Equal(6, repo.List().Count);
        Assert.Contains(repo.List(), f => f.Name == "a (2).txt");

        AddFolderResult rejected = repo.AddFolder(tree, conflict: ConflictPolicy.Reject);
        Assert.Equal(0, rejected.Added);
        Assert.Equal(3, rejected.Failures.Count);
        Assert.Equal(6, repo.List().Count);
    }

    [Fact]
    public void AddFolder_ManyFiles_AreAllCommitted()
    {
        var (repo, keys, _) = Create();
        string root = _t.NewSubfolder("many");
        for (int i = 0; i < 60; i++) File.WriteAllBytes(Path.Combine(root, $"f{i:D2}.txt"), Harness.Data(50, i));

        AddFolderResult result = repo.AddFolder(root);
        Assert.Equal(60, result.Added);

        repo.Dispose();
        Assert.Equal(60, Reopen(keys).List().Count);
    }

    [Fact]
    public void AddFolder_Cancelled_KeepsWhatWasAlreadyAdded()
    {
        var (repo, keys, _) = Create();
        string root = _t.NewSubfolder("cancelme");
        for (int i = 0; i < 6; i++) File.WriteAllBytes(Path.Combine(root, $"f{i}.txt"), Harness.Data(50, i));

        using var cts = new CancellationTokenSource();
        int count = 0;
        var progress = new SyncProgress<string>(_ => { if (++count == 3) cts.Cancel(); });

        Assert.Throws<OperationCanceledException>(() => repo.AddFolder(root, progress: progress, ct: cts.Token));

        Assert.Equal(2, repo.List().Count);       // the third file was interrupted before it was added
        repo.Dispose();
        Assert.Equal(2, Reopen(keys).List().Count);   // and the two that finished were committed
        Assert.Empty(Directory.GetFiles(_t.Paths.BlobsDirectory, "*.tmp"));
    }

    [Fact]
    public void AddFileFromPath_UsesFileNameAndTimestamp_AndValidates()
    {
        var (repo, _, _) = Create();
        string folder = _t.NewSubfolder("src");
        string file = Path.Combine(folder, "memo.txt");
        File.WriteAllBytes(file, Harness.Data(500));
        var stamp = new DateTime(2020, 5, 17, 8, 30, 0, DateTimeKind.Utc);
        File.SetLastWriteTimeUtc(file, stamp);

        FileEntry e = repo.AddFileFromPath(file, "Inbox");
        Assert.Equal("memo.txt", e.Name);
        Assert.Equal("Inbox", e.FolderPath);
        Assert.Equal(stamp, e.ModifiedUtc.UtcDateTime);
        Assert.Equal(500, e.SizeBytes);

        FileEntry renamed = repo.AddFileFromPath(file, "Inbox", nameOverride: "memo-copy.txt");
        Assert.Equal("memo-copy.txt", renamed.Name);

        Assert.Throws<FileNotFoundException>(() => repo.AddFileFromPath(Path.Combine(folder, "missing.txt")));
        Assert.Throws<InvalidEntryNameException>(() => repo.AddFileFromPath(file, "Inbox", nameOverride: "../escape.txt"));
    }

    [Fact]
    public void AddFileFromPath_RefusesSymbolicLinks()
    {
        var (repo, _, _) = Create();
        string folder = _t.NewSubfolder("src");
        string target = Path.Combine(folder, "real.txt");
        string link = Path.Combine(folder, "link.txt");
        File.WriteAllBytes(target, Harness.Data(10));
        try
        {
            File.CreateSymbolicLink(link, target);
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            return;   // creating links needs privileges on some systems; nothing to test there
        }

        Assert.Throws<InvalidOperationException>(() => repo.AddFileFromPath(link));
        Assert.Empty(repo.List());
    }

    // ------------------------------------------------------------------ usage / concurrency

    [Fact]
    public void StorageUsage_ReflectsVaultSize_AndDriveFacts()
    {
        var (repo, _, _) = Create();
        _t.Drive.Total = 32L << 30;
        _t.Drive.Free = 20L << 30;
        Add(repo, "a.bin", Harness.Data(100_000));

        string appDir = _t.NewSubfolder("SecureUSB_App");
        File.WriteAllBytes(Path.Combine(appDir, "app.dll"), new byte[777]);

        StorageUsage usage = repo.GetStorageUsage(new[] { appDir });
        Assert.Equal(32L << 30, usage.TotalBytes);
        Assert.Equal(20L << 30, usage.FreeBytes);
        Assert.True(usage.VaultBytes > 100_000);
        Assert.Equal(777, usage.ApplicationBytes);
        Assert.Equal("exFAT", usage.Drive.FileSystem);
    }

    [Fact]
    public void ParallelAdds_AreSerialisedSafely()
    {
        var (repo, keys, _) = Create();
        Parallel.For(0, 24, new ParallelOptions { MaxDegreeOfParallelism = 8 }, i =>
        {
            Add(repo, $"file-{i:D2}.bin", Harness.Data(2000 + i, i));
        });

        Assert.Equal(24, repo.List().Count);
        Assert.Equal(24, repo.List().Select(f => f.Name).Distinct().Count());
        Assert.True(repo.CheckIntegrity(deep: true).IsClean);

        repo.Dispose();
        VaultRepository again = Reopen(keys);
        Assert.Equal(24, again.List().Count);
        foreach (FileEntry f in again.List())
        {
            int i = int.Parse(f.Name.Substring(5, 2));
            Assert.Equal(Harness.Data(2000 + i, i), Export(again, f.Id));
        }
    }
}
