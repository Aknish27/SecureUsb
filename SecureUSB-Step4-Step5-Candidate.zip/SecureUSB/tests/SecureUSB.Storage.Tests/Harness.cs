using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Storage.Tests;

/// <summary>A drive whose capacity, file system and presence the test controls.</summary>
internal sealed class FakeDrive : IDriveInfoService
{
    public long Total = 32L << 30;
    public long Free = 20L << 30;
    public string FileSystem = "exFAT";
    public DriveType Type = DriveType.Removable;
    public bool Available = true;

    public DriveCapacity GetCapacity(string path)
    {
        if (!Available) throw new IOException("Simulated: the USB drive was removed.");
        return new DriveCapacity("E:\\", "TESTUSB", FileSystem, Type, Total, Free);
    }

    public bool IsAvailable(string path) => Available;
}

internal sealed class FixedTime : TimeProvider
{
    public DateTimeOffset Now = new(2026, 1, 1, 12, 0, 0, TimeSpan.Zero);
    public override DateTimeOffset GetUtcNow() => Now;
    public void Advance(TimeSpan span) => Now += span;
}

/// <summary>A scratch "USB drive": a temp folder deleted on dispose.</summary>
internal sealed class TempVault : IDisposable
{
    public string Root { get; } = Path.Combine(Path.GetTempPath(), "secureusb-tests-" + Guid.NewGuid().ToString("N"));
    public VaultPaths Paths { get; }
    public FakeDrive Drive { get; } = new();
    public FixedTime Time { get; } = new();

    public TempVault()
    {
        Directory.CreateDirectory(Root);
        Paths = new VaultPaths(Path.Combine(Root, VaultPaths.DataFolderName));
    }

    public string NewSubfolder(string name)
    {
        string p = Path.Combine(Root, name);
        Directory.CreateDirectory(p);
        return p;
    }

    public void Dispose()
    {
        try { Directory.Delete(Root, recursive: true); } catch { /* best effort */ }
    }
}

internal static class Harness
{
    public const string Password = "correct horse battery staple";
    public const string OtherPassword = "another long passphrase here";

    /// <summary>Minimum-cost Argon2id so the suite is fast. Never use outside tests.</summary>
    public static readonly KdfParams FastKdf = new(KdfParams.MinMemoryKiB, 1, 1);

    public static byte[] Data(int length, int seed = 1)
    {
        var data = new byte[length];
        new Random(seed).NextBytes(data);
        return data;
    }

    public static NewVault NewVault(string password = Password) => VaultKeyManager.CreateVault(password, FastKdf);

    public static VaultKeys NewKeys() => NewVault().Keys;

    public static IEnumerable<string> AllFiles(string root) =>
        Directory.Exists(root) ? Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories) : Enumerable.Empty<string>();

    /// <summary>true if any readable file under root contains the byte sequence.</summary>
    public static bool DiskContains(string root, byte[] needle)
    {
        foreach (string file in AllFiles(root))
        {
            if (Path.GetFileName(file) == "vault.lock") continue;   // held open exclusively
            if (File.ReadAllBytes(file).AsSpan().IndexOf(needle) >= 0) return true;
        }
        return false;
    }

    public static void FlipByte(string path, int offset)
    {
        byte[] b = File.ReadAllBytes(path);
        b[offset] ^= 0x01;
        File.WriteAllBytes(path, b);
    }
}

/// <summary>Non-seekable source that fails mid-read, like a USB drive being pulled out.</summary>
internal sealed class FailingReadStream : Stream
{
    private readonly byte[] _data;
    private readonly int _failAt;
    private int _pos;

    public FailingReadStream(int length, int failAt)
    {
        _data = Harness.Data(length);
        _failAt = failAt;
    }

    public override bool CanRead => true;
    public override bool CanSeek => false;
    public override bool CanWrite => false;
    public override long Length => throw new NotSupportedException();
    public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
    public override void Flush() { }
    public override int Read(byte[] buffer, int offset, int count) => Read(buffer.AsSpan(offset, count));

    public override int Read(Span<byte> buffer)
    {
        if (_pos >= _failAt) throw new IOException("Simulated: the USB drive was removed during the operation.");
        int n = Math.Min(Math.Min(buffer.Length, _data.Length - _pos), _failAt - _pos);
        _data.AsSpan(_pos, n).CopyTo(buffer);
        _pos += n;
        return n;
    }

    public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
    public override void SetLength(long value) => throw new NotSupportedException();
    public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
}

/// <summary>Seekable stream that CLAIMS to be huge (zeros) so size preflight checks can be tested without GBs of data.</summary>
internal sealed class HugeStream : Stream
{
    private readonly long _length;
    private long _pos;

    public HugeStream(long length) => _length = length;

    public override bool CanRead => true;
    public override bool CanSeek => true;
    public override bool CanWrite => false;
    public override long Length => _length;
    public override long Position { get => _pos; set => _pos = value; }
    public override void Flush() { }
    public override int Read(byte[] buffer, int offset, int count) => Read(buffer.AsSpan(offset, count));

    public override int Read(Span<byte> buffer)
    {
        int n = (int)Math.Min(buffer.Length, _length - _pos);
        buffer.Slice(0, n).Clear();
        _pos += n;
        return n;
    }

    public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
    public override void SetLength(long value) => throw new NotSupportedException();
    public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
}

internal sealed class SyncProgress<T> : IProgress<T>
{
    private readonly Action<T> _action;
    public SyncProgress(Action<T> action) => _action = action;
    public void Report(T value) => _action(value);
}
