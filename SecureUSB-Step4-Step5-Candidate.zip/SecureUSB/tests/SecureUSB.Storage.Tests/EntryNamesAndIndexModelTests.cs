using SecureUSB.Models;

namespace SecureUSB.Storage.Tests;

public class EntryNamesAndIndexModelTests
{
    [Theory]
    [InlineData("report.pdf")]
    [InlineData("employee_photo.jpg")]
    [InlineData("project_report.docx")]
    [InlineData("\u65E5\u672C\u8A9E.pdf")]
    [InlineData("\u00FCn\u00EFc\u00F6d\u00E9 file.txt")]
    [InlineData(".hidden")]
    [InlineData("a b.txt")]
    public void ValidNames_AreAccepted(string name)
    {
        Assert.True(EntryNames.IsValidName(name, out _));
    }

    [Theory]
    [InlineData("")]
    [InlineData(" leading.txt")]
    [InlineData("trailing.txt ")]
    [InlineData("trailing.")]
    [InlineData("..")]
    [InlineData(".")]
    [InlineData("a/b")]
    [InlineData("a\\b")]
    [InlineData("..\\..\\windows\\system32")]
    [InlineData("a:b")]
    [InlineData("what?")]
    [InlineData("star*")]
    [InlineData("pipe|name")]
    [InlineData("quote\"name")]
    [InlineData("lt<name")]
    [InlineData("gt>name")]
    [InlineData("con")]
    [InlineData("CON.txt")]
    [InlineData("nul.tar.gz")]
    [InlineData("Com1")]
    [InlineData("lpt9.doc")]
    [InlineData("ctrl\u0001char")]
    [InlineData("nul\0byte")]
    [InlineData("rlo\u202Egpj.exe")]
    [InlineData("zero\u200Bwidth.txt")]
    public void DangerousNames_AreRejected(string name)
    {
        Assert.False(EntryNames.IsValidName(name, out string reason));
        Assert.NotEmpty(reason);
    }

    [Fact]
    public void NullAndTooLongNames_AreRejected()
    {
        Assert.False(EntryNames.IsValidName(null, out _));
        Assert.True(EntryNames.IsValidName(new string('a', EntryNames.MaxNameLength), out _));
        Assert.False(EntryNames.IsValidName(new string('a', EntryNames.MaxNameLength + 1), out _));
    }

    [Theory]
    [InlineData("")]
    [InlineData("Projects")]
    [InlineData("Projects/2026/Legal")]
    public void ValidFolderPaths_AreAccepted(string path)
    {
        Assert.True(EntryNames.IsValidFolderPath(path, out _));
    }

    [Theory]
    [InlineData("/absolute")]
    [InlineData("trailing/")]
    [InlineData("a//b")]
    [InlineData("a/../b")]
    [InlineData("..")]
    [InlineData("a\\b")]
    [InlineData("C:/Windows")]
    public void DangerousFolderPaths_AreRejected(string path)
    {
        Assert.False(EntryNames.IsValidFolderPath(path, out _));
    }

    [Fact]
    public void FolderDepth_IsLimited()
    {
        string ok = string.Join("/", Enumerable.Repeat("d", EntryNames.MaxFolderDepth));
        string tooDeep = string.Join("/", Enumerable.Repeat("d", EntryNames.MaxFolderDepth + 1));
        Assert.True(EntryNames.IsValidFolderPath(ok, out _));
        Assert.False(EntryNames.IsValidFolderPath(tooDeep, out _));
    }

    // ---------------------------------------------------------------- VaultIndex.Validate

    private static readonly Guid VaultId = Guid.Parse("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa");
    private static readonly DateTimeOffset Now = new(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);

    private static FileEntry Entry(string name = "a.txt", string folder = "", Guid? id = null) => new()
    {
        Id = id ?? Guid.NewGuid(),
        Name = name,
        FolderPath = folder,
        SizeBytes = 10,
        ChunkSize = 1 << 20,
        AddedUtc = Now,
        ModifiedUtc = Now
    };

    private static VaultIndex IndexWith(params FileEntry[] files) =>
        VaultIndex.CreateEmpty(VaultId, Now).WithFiles(files, Now);

    [Fact]
    public void ValidIndex_PassesValidation()
    {
        IndexWith(Entry("a.txt"), Entry("b.txt"), Entry("a.txt", "Sub")).Validate(VaultId);
        VaultIndex.CreateEmpty(VaultId, Now).Validate(VaultId);
    }

    [Fact]
    public void WithFiles_IncrementsRevision()
    {
        VaultIndex empty = VaultIndex.CreateEmpty(VaultId, Now);
        Assert.Equal(1, empty.Revision);
        Assert.Equal(2, empty.WithFiles(new[] { Entry() }, Now).Revision);
    }

    [Fact]
    public void Validation_RejectsMalformedIndexes()
    {
        Guid dup = Guid.NewGuid();
        Assert.Throws<InvalidVaultFormatException>(() => IndexWith(Entry(id: dup), Entry("b.txt", id: dup)).Validate(VaultId));
        Assert.Throws<InvalidVaultFormatException>(() => IndexWith(Entry("a.txt"), Entry("A.TXT")).Validate(VaultId));
        Assert.Throws<InvalidVaultFormatException>(() => IndexWith(Entry("../evil")).Validate(VaultId));
        Assert.Throws<InvalidVaultFormatException>(() => IndexWith(Entry("ok.txt", "../up")).Validate(VaultId));
        Assert.Throws<InvalidVaultFormatException>(() => IndexWith(Entry(id: Guid.Empty)).Validate(VaultId));
        Assert.Throws<InvalidVaultFormatException>(() => IndexWith(Entry() with { ChunkSize = 10 }).Validate(VaultId));
        Assert.Throws<InvalidVaultFormatException>(() => IndexWith(Entry() with { SizeBytes = -1 }).Validate(VaultId));
        Assert.Throws<InvalidVaultFormatException>(() => IndexWith(Entry()).Validate(Guid.NewGuid()));
        Assert.Throws<InvalidVaultFormatException>(() => (IndexWith(Entry()) with { FormatVersion = 99 }).Validate(VaultId));
    }
}
