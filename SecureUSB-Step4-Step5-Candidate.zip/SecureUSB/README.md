# SecureUSB — Portable Confidential Data Protection System

**Status: Step 4 test-fix + Step 5 release packaging candidate. Windows verification is still required.**
V1 is deliberately simple for the user: **USB → open SecureUSB → enter ONE password → unlock.**
There is no key file and no second factor in V1 (see "Future enterprise features").

> Steps 1-3 were built and verified on a real machine (427/427 tests passed).
> Step 4 has now been built on the user machine, but the latest run reported two failing WPF smoke tests. The targeted test fix in this package has not been run yet.
> Step 5 release scripts and documentation are included as a candidate; do not distribute until Windows verification passes.
> The verified Step 1-3 source and tests must remain unchanged.

## Requirements
* .NET 8 SDK (or newer) on the *development* machine. Target PCs need nothing: the final app is published self-contained.
* Windows is the product target. These Step 1 libraries and tests are cross-platform (Windows/Linux/macOS);
  on Linux, AES-GCM needs OpenSSL and string normalization needs ICU installed.

## Build and test
```
build-and-test.cmd          (Windows: builds, runs each test project, VERIFIES test counts and named tests)
./build-and-test.sh         (Linux/macOS)
```
`dotnet test` prints ONE summary PER test project. Expected: **Cryptography.Tests = 71**, **Security.Tests = 105**, **Storage.Tests = 176**, **Core.Tests = 75**,
**ViewModels.Tests = 188**, **UI.Tests = 33** (648 total). UI.Tests are Windows-only (they load real WPF). Seeing only one number means you saw one project's line; scroll up for the others.
To list discovered tests without running them:
`dotnet test tests/SecureUSB.Cryptography.Tests -c Release --no-build --list-tests`

Or manually: `dotnet restore` → `dotnet build -c Release` → `dotnet test -c Release`.
The suite uses minimum-cost Argon2id parameters, so it finishes in seconds. Production uses 128 MiB / 3 passes / 4 lanes.

## NuGet packages
| Package | Used by | Why |
|---|---|---|
| Konscious.Security.Cryptography.Argon2 1.3.0 | Cryptography | Argon2id (managed, no native DLLs, portable) |
| xunit 2.9.2, xunit.runner.visualstudio 2.8.2, Microsoft.NET.Test.Sdk 17.11.1 | tests | test framework |

AES-256-GCM, HKDF-SHA256 and the CSPRNG come from .NET's own `System.Security.Cryptography` (OS-backed). No custom primitives.

## Layout
```
SecureUSB.sln
Directory.Build.props
src/
  SecureUSB.Models/          KdfParams, VaultHeader (131-byte binary header), InvalidVaultFormatException
  SecureUSB.Cryptography/    SecureBytes, SecureRandom, Argon2idKeyDeriver, Aead, VaultKeys,
                             VaultKeyManager, ChunkedFileCipher, exceptions
  SecureUSB.Security/        PasswordPolicy, AttemptGuard, FilenameSanitizer, TempFileManager
  SecureUSB.Storage/         VaultPaths, AtomicFile, FileWiper, VaultHeaderStore, EncryptedIndexStore,
                             BlobStore/BlobFormat, IntegrityScanner, DriveInfoService, StorageUsage, VaultRepository
  SecureUSB.Core/            VaultService, ActivityLog, UsbMonitor
  SecureUSB.ViewModels/      MVVM: Shell, pages, dialogs, dashboard, error mapping (plain net8.0, no WPF)
  SecureUSB.UI/              WPF: views, themes, styles, Windows adapters (net8.0-windows)
tests/
  SecureUSB.Cryptography.Tests/   71 cases, incl. exhaustive tamper and truncation tests
  SecureUSB.Security.Tests/       105 cases (password policy, attempt delays, sanitizer, temp files)
  SecureUSB.Storage.Tests/        176 cases (crash windows, tampering, USB-removal simulation, recovery, concurrency)
  SecureUSB.Core.Tests/           75 cases (VaultService end to end, activity log, USB monitor)
  SecureUSB.ViewModels.Tests/     188 cases (every screen against the real VaultService with fake dialogs)
  SecureUSB.UI.Tests/             33 cases (Windows: resources, every view loads, themes, controls, window)
docs/
  Step1-CryptoDesign.md
  Step2-StorageDesign.md
  Step3-CoreDesign.md
  Step4-UiDesign.md
```

## How it works (Step 1 pieces)
1. **Create vault**: random 256-bit Master Key (MK) + random 256-bit salt + random vault ID.
   `password → Argon2id(salt) → KEK`; KEK wraps MK with AES-256-GCM, authenticating the header prefix as AAD.
   Only the *wrapped* MK is stored (`vault.hdr`). The password and MK are never written anywhere.
2. **Unlock**: re-derive KEK, try to open the wrapped MK. Success = the GCM tag verifies. There is no password comparison.
3. **Per-file encryption**: each file gets its own random file key, wrapped by a subkey derived from MK (HKDF).
   File bodies are AES-256-GCM in 1 MiB chunks; each chunk is bound to vault ID, file ID, position and a final-chunk flag.
4. **Change password**: verify old password, then re-wrap the *same* MK under the new password with a fresh salt and nonce.
   No file is re-encrypted. (Persisting this atomically is Step 2.)
5. **Lock**: dispose `VaultKeys` → master key memory is zeroed.

See `docs/Step1-CryptoDesign.md` for formats and the security reasoning.

## Roadmap
2. Storage (done): atomic header/index/blob writes, encrypted index, backup header, integrity scan, drive capacity info
3. Security + Core (done): attempt guard, filename sanitizer, temp-file manager, activity log, vault service, USB removal monitor
4. WPF UI (this ZIP)
5. Launcher, self-contained publish script, user manual, final threat model


## Step 5: verify and package a Windows release candidate
On Windows with the .NET 8 SDK installed, run:

```bat
build-and-test.cmd
publish-and-package.cmd
```

`publish-and-package.cmd` stops if the build/test verification fails. On success it publishes a self-contained `win-x64` build, creates `release\SecureUSB-v1.0.0-win-x64\SecureUSB.exe`, includes the user manual/threat model/test plan, and creates a ZIP under `release`. This package has not been verified in this environment.

Read `docs/USER-MANUAL.md`, `docs/THREAT-MODEL.md`, and `docs/FINAL-TEST-PLAN.md` before testing or distributing.
