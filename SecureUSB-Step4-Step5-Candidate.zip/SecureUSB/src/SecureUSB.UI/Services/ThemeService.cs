using System.Windows;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.UI.Services;

/// <summary>Swaps the theme dictionary (brush and colour keys); all styles use DynamicResource so the UI updates live.</summary>
public sealed class ThemeService : IThemeService
{
    public void Apply(ThemeKind theme)
    {
        Application? app = Application.Current;
        if (app is null) return;

        var dictionary = new ResourceDictionary
        {
            Source = new Uri($"pack://application:,,,/SecureUSB.UI;component/Themes/{theme}.xaml", UriKind.Absolute)
        };

        var merged = app.Resources.MergedDictionaries;
        for (int i = merged.Count - 1; i >= 0; i--)
        {
            string? source = merged[i].Source?.OriginalString;
            if (source is not null && source.Contains("Themes/", StringComparison.OrdinalIgnoreCase)) merged.RemoveAt(i);
        }
        merged.Insert(0, dictionary);
    }
}
