using System.Diagnostics;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.UI.Services;

public sealed class ShellLauncher : IShellLauncher
{
    /// <summary>Hands the file to the program Windows associates with it. The path is never displayed or logged.</summary>
    public void OpenFile(string path)
    {
        Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
    }
}
