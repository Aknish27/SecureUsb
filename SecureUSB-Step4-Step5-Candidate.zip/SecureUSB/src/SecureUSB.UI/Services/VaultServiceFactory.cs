using System.IO;
using SecureUSB.Core;
using SecureUSB.Storage;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.UI.Services;

/// <summary>Builds the real VaultService (production Argon2id cost, real drive information).</summary>
public sealed class VaultServiceFactory : IVaultServiceFactory
{
    public VaultService Create(VaultLocation location)
    {
        // decrypted temporary copies (only if the user allows opening files in other programs) go to the PC's temp folder,
        // never to the USB stick
        string tempRoot = Path.Combine(Path.GetTempPath(), "SecureUSB");

        var application = new[]
        {
            Path.Combine(location.Root, "SecureUSB.exe"),
            Path.Combine(location.Root, "SecureUSB_App")
        };

        return new VaultService(new VaultServiceOptions
        {
            Paths = VaultPaths.ForUsbRoot(location.Root),
            Drive = new SystemDriveInfoService(),
            TempRoot = tempRoot,
            ApplicationPaths = application
        });
    }
}
