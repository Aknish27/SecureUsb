using Microsoft.Win32;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.UI.Services;

public sealed class WpfFileDialogService : IFileDialogService
{
    public IReadOnlyList<string> PickFiles(string title)
    {
        var dialog = new OpenFileDialog
        {
            Title = title,
            Multiselect = true,
            CheckFileExists = true,
            CheckPathExists = true
        };
        return dialog.ShowDialog() == true ? dialog.FileNames : Array.Empty<string>();
    }

    public string? PickFolder(string title)
    {
        var dialog = new OpenFolderDialog { Title = title, Multiselect = false };
        return dialog.ShowDialog() == true ? dialog.FolderName : null;
    }
}
