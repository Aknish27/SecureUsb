using System.IO;
using SecureUSB.Storage;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.UI.Services;

/// <summary>
/// Finds removable drives (and the folder SecureUSB itself runs from). Layout on the USB stick:
/// E:\SecureUSB.exe, E:\SecureUSB_App\ (the program), E:\SecureUSB_Data\ (the encrypted vault).
/// </summary>
public sealed class DriveLocationProvider : ILocationProvider
{
    public IReadOnlyList<VaultLocation> Discover()
    {
        string? appRoot = FindAppRoot();
        var result = new List<VaultLocation>();
        bool appRootListed = false;

        foreach (DriveInfo drive in DriveInfo.GetDrives())
        {
            try
            {
                if (!drive.IsReady) continue;
                string root = drive.RootDirectory.FullName;
                bool isApp = appRoot is not null && SameDirectory(root, appRoot);
                bool removable = drive.DriveType == DriveType.Removable;
                if (!removable && !isApp) continue;

                string label = string.IsNullOrWhiteSpace(drive.VolumeLabel) ? "Drive" : drive.VolumeLabel;
                string details = $"{drive.DriveFormat} \u00B7 {ByteSize.Format(drive.TotalSize)} \u00B7 {ByteSize.Format(drive.AvailableFreeSpace)} free";
                result.Add(new VaultLocation(root, $"{label} ({root.TrimEnd('\\')})", details, VaultExists(root), removable, isApp));
                appRootListed |= isApp;
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException)
            {
                // skip drives that cannot be queried
            }
        }

        // running from a folder that is not a drive root (for example a copy on the PC)
        if (appRoot is not null && !appRootListed)
            result.Insert(0, new VaultLocation(appRoot, Path.GetFileName(appRoot.TrimEnd('\\')), "Folder next to this program",
                VaultExists(appRoot), false, true));

        return result;
    }

    public VaultLocation FromFolder(string root)
    {
        string full = Path.GetFullPath(root);
        string name = Path.GetFileName(full.TrimEnd('\\', '/'));
        if (string.IsNullOrEmpty(name)) name = full;
        return new VaultLocation(full, name, "Selected folder or drive", VaultExists(full), false, false);
    }

    private static bool VaultExists(string root)
    {
        try
        {
            return new VaultHeaderStore(VaultPaths.ForUsbRoot(root)).Exists;
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException)
        {
            return false;
        }
    }

    /// <summary>The USB root the running program belongs to, or null when it is not inside the expected layout.</summary>
    internal static string? FindAppRoot()
    {
        string baseDir = Path.TrimEndingDirectorySeparator(AppContext.BaseDirectory);
        string? parent = Path.GetDirectoryName(baseDir);
        if (string.Equals(Path.GetFileName(baseDir), "SecureUSB_App", StringComparison.OrdinalIgnoreCase) && parent is not null)
            return parent;
        if (Directory.Exists(Path.Combine(baseDir, VaultPaths.DataFolderName)))
            return baseDir;
        return null;
    }

    private static bool SameDirectory(string a, string b) =>
        string.Equals(Path.TrimEndingDirectorySeparator(a), Path.TrimEndingDirectorySeparator(b), StringComparison.OrdinalIgnoreCase);
}
