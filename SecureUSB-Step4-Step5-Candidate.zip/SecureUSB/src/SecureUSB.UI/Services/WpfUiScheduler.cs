using System.Windows.Threading;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.UI.Services;

/// <summary>Runs view-model work on the WPF UI thread and provides dispatcher timers.</summary>
public sealed class WpfUiScheduler : IUiScheduler
{
    private readonly Dispatcher _dispatcher;

    public WpfUiScheduler(Dispatcher dispatcher)
    {
        _dispatcher = dispatcher;
    }

    public void Post(Action action) => _dispatcher.BeginInvoke(DispatcherPriority.Normal, action);

    public IDisposable Every(TimeSpan interval, Action tick)
    {
        var timer = new DispatcherTimer(DispatcherPriority.Background, _dispatcher) { Interval = interval };
        timer.Tick += (_, _) => tick();
        timer.Start();
        return new TimerHandle(timer);
    }

    private sealed class TimerHandle : IDisposable
    {
        private readonly DispatcherTimer _timer;
        public TimerHandle(DispatcherTimer timer) => _timer = timer;
        public void Dispose() => _timer.Stop();
    }
}
