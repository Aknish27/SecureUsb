using System.Windows;
using System.Windows.Controls;

namespace SecureUSB.UI.Controls;

/// <summary>
/// A password field with a Show/Hide toggle. The text is bound to a plain string property of the view-model;
/// it is hidden (PasswordBox) unless the user turns "Show" on, and the visible copy is never used otherwise.
/// </summary>
public partial class PasswordInput : UserControl
{
    public static readonly DependencyProperty PasswordProperty = DependencyProperty.Register(
        nameof(Password), typeof(string), typeof(PasswordInput),
        new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnPasswordChanged));

    public static readonly DependencyProperty IsPasswordVisibleProperty = DependencyProperty.Register(
        nameof(IsPasswordVisible), typeof(bool), typeof(PasswordInput),
        new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnVisibleChanged));

    public static readonly DependencyProperty LabelProperty = DependencyProperty.Register(
        nameof(Label), typeof(string), typeof(PasswordInput), new PropertyMetadata("Password"));

    private bool _syncing;

    public PasswordInput()
    {
        InitializeComponent();
    }

    public string Password
    {
        get => (string)GetValue(PasswordProperty);
        set => SetValue(PasswordProperty, value);
    }

    public bool IsPasswordVisible
    {
        get => (bool)GetValue(IsPasswordVisibleProperty);
        set => SetValue(IsPasswordVisibleProperty, value);
    }

    /// <summary>Accessible name read by screen readers.</summary>
    public string Label
    {
        get => (string)GetValue(LabelProperty);
        set => SetValue(LabelProperty, value);
    }

    public new bool Focus()
    {
        return IsPasswordVisible ? VisibleBox.Focus() : HiddenBox.Focus();
    }

    private static void OnPasswordChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) =>
        ((PasswordInput)d).PushToBoxes((string?)e.NewValue ?? "");

    private static void OnVisibleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) =>
        ((PasswordInput)d).ApplyVisibility((bool)e.NewValue);

    private void PushToBoxes(string text)
    {
        if (_syncing) return;
        _syncing = true;
        try
        {
            if (HiddenBox.Password != text) HiddenBox.Password = text;
            if (VisibleBox.Text != text) VisibleBox.Text = text;
        }
        finally
        {
            _syncing = false;
        }
    }

    private void ApplyVisibility(bool visible)
    {
        bool hadFocus = HiddenBox.IsKeyboardFocusWithin || VisibleBox.IsKeyboardFocusWithin;
        HiddenBox.Visibility = visible ? Visibility.Collapsed : Visibility.Visible;
        VisibleBox.Visibility = visible ? Visibility.Visible : Visibility.Collapsed;
        if (!hadFocus) return;

        if (visible)
        {
            VisibleBox.Focus();
            VisibleBox.CaretIndex = VisibleBox.Text.Length;
        }
        else
        {
            HiddenBox.Focus();
        }
    }

    private void OnHiddenPasswordChanged(object sender, RoutedEventArgs e)
    {
        if (_syncing) return;
        _syncing = true;
        try
        {
            Password = HiddenBox.Password;
            VisibleBox.Text = HiddenBox.Password;
        }
        finally
        {
            _syncing = false;
        }
    }

    private void OnVisibleTextChanged(object sender, TextChangedEventArgs e)
    {
        if (_syncing) return;
        _syncing = true;
        try
        {
            Password = VisibleBox.Text;
            HiddenBox.Password = VisibleBox.Text;
        }
        finally
        {
            _syncing = false;
        }
    }
}
