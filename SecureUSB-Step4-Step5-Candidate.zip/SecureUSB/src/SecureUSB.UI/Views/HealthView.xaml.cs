using System.Windows.Controls;

namespace SecureUSB.UI.Views;

public partial class HealthView : UserControl
{
    public HealthView()
    {
        InitializeComponent();
    }
}
