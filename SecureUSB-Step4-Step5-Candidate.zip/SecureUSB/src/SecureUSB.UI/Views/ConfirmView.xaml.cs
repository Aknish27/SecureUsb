using System.Windows;
using System.Windows.Controls;
using SecureUSB.ViewModels;

namespace SecureUSB.UI.Views;

public partial class ConfirmView : UserControl
{
    public ConfirmView()
    {
        InitializeComponent();
        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        if (DataContext is ConfirmViewModel { IsDestructive: true }) CancelButton.Focus();
        else PrimaryConfirm.Focus();
    }
}
