using System.Windows;
using System.Windows.Controls;

namespace SecureUSB.UI.Views;

public partial class CreateVaultView : UserControl
{
    public CreateVaultView()
    {
        InitializeComponent();
        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e) => PasswordField.Focus();
}
