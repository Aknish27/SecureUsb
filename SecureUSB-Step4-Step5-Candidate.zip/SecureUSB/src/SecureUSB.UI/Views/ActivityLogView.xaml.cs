using System.Windows.Controls;

namespace SecureUSB.UI.Views;

public partial class ActivityLogView : UserControl
{
    public ActivityLogView()
    {
        InitializeComponent();
    }
}
