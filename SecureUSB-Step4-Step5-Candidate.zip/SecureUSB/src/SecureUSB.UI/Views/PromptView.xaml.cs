using System.Windows;
using System.Windows.Controls;

namespace SecureUSB.UI.Views;

public partial class PromptView : UserControl
{
    public PromptView()
    {
        InitializeComponent();
        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        Input.Focus();
        // select the name without its extension, like Windows Explorer does
        string text = Input.Text;
        int dot = text.LastIndexOf('.');
        if (dot > 0) Input.Select(0, dot);
        else Input.SelectAll();
    }
}
