using System.Windows;
using System.Windows.Controls;

namespace SecureUSB.UI.Views;

public partial class ChangePasswordView : UserControl
{
    public ChangePasswordView()
    {
        InitializeComponent();
        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e) => CurrentField.Focus();
}
