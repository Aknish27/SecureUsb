using System.Windows.Controls;

namespace SecureUSB.UI.Views;

public partial class WelcomeView : UserControl
{
    public WelcomeView()
    {
        InitializeComponent();
    }
}
