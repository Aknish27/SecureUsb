using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text.Json;
using SecureUSB.Cryptography;
using SecureUSB.Models;
using SecureUSB.Storage;

namespace SecureUSB.Core;

public sealed record ActivityLogReadResult(IReadOnlyList<ActivityEvent> Events, bool TornTail, bool TamperDetected);

/// <summary>
/// Encrypted, append-only security/activity log (SecureUSB_Data/log.sdb). Readable only after unlocking.
///
/// File: "SUSBLOG1"(8) then records:  length u32 BE | AES-256-GCM sealed JSON (nonce | ciphertext | tag)
///   key = HKDF subkey "SecureUSB/v1/activity-log";  AAD = "SUSBLOG1" | vaultId | record number u64 | length u32
/// Because the record number and length are authenticated, a record that is modified, moved, duplicated or
/// removed from the middle makes verification fail from that point on. Appending needs no rewrite of the file, so an
/// interruption can at worst leave a half-written LAST record, which is detected and trimmed on the next start.
///
/// LIMITS: someone with write access can delete the whole file or cut records off its END without detection
/// (there is no key to protect "how long the log should be" while the vault is locked). The log is evidence
/// for the owner, not a tamper-proof audit trail. Failed unlock attempts cannot be written while locked (no key);
/// they are recorded by the attempt counter and reported here at the next successful unlock.
/// </summary>
public sealed class ActivityLog
{
    public const long DefaultMaxFileBytes = 1024 * 1024;
    public const int DefaultKeepAfterCompaction = 500;
    public const int MaxMessageLength = 1000;
    private const int MaxRecordBytes = 64 * 1024;

    private static ReadOnlySpan<byte> Magic => "SUSBLOG1"u8;
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = false };

    private readonly string _path;
    private readonly VaultKeys _keys;
    private readonly TimeProvider _time;
    private readonly long _maxFileBytes;
    private readonly int _keepAfterCompaction;
    private readonly object _gate = new();
    private bool _loaded;
    private long _nextSequence;

    public ActivityLog(VaultPaths paths, VaultKeys keys, TimeProvider? time = null,
        long maxFileBytes = DefaultMaxFileBytes, int keepAfterCompaction = DefaultKeepAfterCompaction)
    {
        ArgumentNullException.ThrowIfNull(paths);
        _path = paths.LogPath;
        _keys = keys ?? throw new ArgumentNullException(nameof(keys));
        _time = time ?? TimeProvider.System;
        _maxFileBytes = maxFileBytes;
        _keepAfterCompaction = keepAfterCompaction;
    }

    public void Append(ActivityKind kind, string message)
    {
        string text = message.Length > MaxMessageLength ? message[..MaxMessageLength] : message;
        var ev = new ActivityEvent { TimestampUtc = _time.GetUtcNow(), Kind = kind, Message = text };

        lock (_gate)
        {
            EnsureLoaded();
            AppendCore(ev);
            if (new FileInfo(_path).Length > _maxFileBytes) Compact();
        }
    }

    public ActivityLogReadResult Read()
    {
        lock (_gate)
        {
            if (!File.Exists(_path)) return new ActivityLogReadResult(Array.Empty<ActivityEvent>(), false, false);
            ParseResult r = Parse(File.ReadAllBytes(_path));
            return new ActivityLogReadResult(r.Events, r.TornTail, r.Tampered);
        }
    }

    // ------------------------------------------------------------------ internals

    private void EnsureLoaded()
    {
        if (_loaded) return;

        if (!File.Exists(_path) || new FileInfo(_path).Length == 0)
        {
            _nextSequence = 0;
            _loaded = true;
            return;
        }

        ParseResult r = Parse(File.ReadAllBytes(_path));
        if (r.Tampered)
        {
            // keep the damaged file as evidence and start a new log
            File.Move(_path, _path + ".damaged", overwrite: true);
            _nextSequence = 0;
            _loaded = true;
            AppendCore(new ActivityEvent
            {
                TimestampUtc = _time.GetUtcNow(),
                Kind = ActivityKind.Warning,
                Message = "The previous activity log failed verification and was set aside as log.sdb.damaged."
            });
            return;
        }

        if (r.TornTail)
        {
            using var fs = new FileStream(_path, FileMode.Open, FileAccess.Write, FileShare.None);
            fs.SetLength(r.GoodLength);   // trim a half-written last record
            fs.Flush(true);
        }

        _nextSequence = r.Events.Count;
        _loaded = true;
    }

    private void AppendCore(ActivityEvent ev)
    {
        bool isNew = !File.Exists(_path) || new FileInfo(_path).Length == 0;
        byte[] record = EncodeRecord(ev, _nextSequence);

        using var fs = new FileStream(_path, FileMode.Append, FileAccess.Write, FileShare.None);
        if (isNew) fs.Write(Magic);
        fs.Write(record);
        fs.Flush(flushToDisk: true);
        _nextSequence++;
    }

    private void Compact()
    {
        ParseResult r = Parse(File.ReadAllBytes(_path));
        List<ActivityEvent> keep = r.Events.Skip(Math.Max(0, r.Events.Count - _keepAfterCompaction)).ToList();
        int removed = r.Events.Count - keep.Count;
        keep.Add(new ActivityEvent
        {
            TimestampUtc = _time.GetUtcNow(),
            Kind = ActivityKind.Warning,
            Message = $"Activity log compacted: {removed} older event(s) removed."
        });

        using var stream = new MemoryStream();
        stream.Write(Magic);
        long seq = 0;
        foreach (ActivityEvent e in keep) stream.Write(EncodeRecord(e, seq++));

        AtomicFile.WriteAllBytes(_path, stream.ToArray());
        _nextSequence = seq;
    }

    private byte[] EncodeRecord(ActivityEvent ev, long sequence)
    {
        byte[] json = JsonSerializer.SerializeToUtf8Bytes(ev, JsonOptions);
        using SecureBytes key = _keys.DeriveKey(KeyPurpose.ActivityLog);
        try
        {
            int sealedLength = json.Length + Aead.Overhead;
            byte[] sealedData = Aead.Seal(key.Span, json, BuildAad(sequence, (uint)sealedLength));
            var record = new byte[4 + sealedData.Length];
            BinaryPrimitives.WriteUInt32BigEndian(record, (uint)sealedData.Length);
            sealedData.CopyTo(record, 4);
            return record;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(json);
        }
    }

    private ParseResult Parse(byte[] file)
    {
        var events = new List<ActivityEvent>();
        if (file.Length == 0) return new ParseResult(events, 0, false, false);
        if (file.Length < Magic.Length || !file.AsSpan(0, Magic.Length).SequenceEqual(Magic))
            return new ParseResult(events, 0, false, true);

        using SecureBytes key = _keys.DeriveKey(KeyPurpose.ActivityLog);
        int pos = Magic.Length;
        long good = pos;
        long seq = 0;
        bool torn = false, tampered = false;

        while (pos < file.Length)
        {
            if (file.Length - pos < 4) { torn = true; break; }
            uint length = BinaryPrimitives.ReadUInt32BigEndian(file.AsSpan(pos, 4));
            if (length < Aead.Overhead || length > MaxRecordBytes) { tampered = true; break; }
            if (file.Length - pos - 4 < length) { torn = true; break; }

            byte[]? plain = null;
            try
            {
                plain = Aead.Open(key.Span, file.AsSpan(pos + 4, (int)length), BuildAad(seq, length));
                ActivityEvent? ev = JsonSerializer.Deserialize<ActivityEvent>(plain, JsonOptions);
                if (ev is null) { tampered = true; break; }
                events.Add(ev);
            }
            catch (Exception e) when (e is CryptographicException or JsonException)
            {
                tampered = true;
                break;
            }
            finally
            {
                if (plain is not null) CryptographicOperations.ZeroMemory(plain);
            }

            pos += 4 + (int)length;
            good = pos;
            seq++;
        }
        return new ParseResult(events, good, torn, tampered);
    }

    private byte[] BuildAad(long sequence, uint length)
    {
        var aad = new byte[8 + 16 + 8 + 4];
        Magic.CopyTo(aad);
        _keys.VaultId.TryWriteBytes(aad.AsSpan(8, 16));
        BinaryPrimitives.WriteUInt64BigEndian(aad.AsSpan(24, 8), (ulong)sequence);
        BinaryPrimitives.WriteUInt32BigEndian(aad.AsSpan(32, 4), length);
        return aad;
    }

    private sealed record ParseResult(List<ActivityEvent> Events, long GoodLength, bool TornTail, bool Tampered);
}
