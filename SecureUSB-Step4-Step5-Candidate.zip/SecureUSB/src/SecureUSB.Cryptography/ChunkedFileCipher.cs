using System.Buffers.Binary;
using System.Security.Cryptography;

namespace SecureUSB.Cryptography;

/// <summary>Binds a file's ciphertext to its vault and file ID (via AES-GCM associated data).</summary>
public readonly record struct FileBinding(Guid VaultId, Guid FileId);

/// <summary>
/// Streaming file encryption: AES-256-GCM over fixed-size chunks (STREAM-style construction).
///
/// Stream layout:
///   magic "SUSBFIL1" (8) | chunk size, uint32 BE (4) | random nonce prefix (8)     = 20-byte stream header
///   then for each chunk:  ciphertext (<= chunk size) | GCM tag (16)
///
/// Per-chunk nonce  = noncePrefix(8) | chunkIndex uint32 BE (4)   (never repeats under one file key)
/// Per-chunk AAD    = streamHeader(20) | vaultId(16) | fileId(16) | chunkIndex(4) | isFinal(1)
///
/// This detects: modified bytes anywhere, reordered/duplicated/removed chunks, truncation
/// (the last chunk is authenticated as "final"), appended data, and ciphertext moved to another
/// file or vault. A zero-length file still produces one (empty) final chunk.
///
/// IMPORTANT: Decrypt writes each chunk to the output only after that chunk authenticates, but
/// later chunks may fail. On any exception the caller MUST discard the partial output
/// (delete the temp file). Never show or open a file whose Decrypt call did not return normally.
/// </summary>
public static class ChunkedFileCipher
{
    public const int DefaultChunkSize = 1 << 20;   // 1 MiB
    public const int MinChunkSize = 1024;
    public const int MaxChunkSize = 16 << 20;      // 16 MiB

    private const int NoncePrefixLength = 8;
    private const int StreamHeaderLength = 8 + 4 + NoncePrefixLength;    // 20
    private const int TagSize = 16;
    private const int NonceSize = 12;
    private const int AadLength = StreamHeaderLength + 16 + 16 + 4 + 1;  // 57

    private static ReadOnlySpan<byte> Magic => "SUSBFIL1"u8;

    /// <summary>Exact size of the encrypted stream for a given plaintext length.</summary>
    public static long CiphertextLength(long plaintextLength, int chunkSize = DefaultChunkSize)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(plaintextLength);
        ValidateChunkSize(chunkSize);
        long chunks = plaintextLength == 0 ? 1 : (plaintextLength + chunkSize - 1) / chunkSize;
        return StreamHeaderLength + plaintextLength + chunks * TagSize;
    }

    /// <returns>The number of plaintext bytes encrypted.</returns>
    public static long Encrypt(
        Stream input, Stream output, ReadOnlySpan<byte> fileKey, FileBinding binding,
        int chunkSize = DefaultChunkSize, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(input);
        ArgumentNullException.ThrowIfNull(output);
        RequireKey(fileKey);
        ValidateChunkSize(chunkSize);

        Span<byte> header = stackalloc byte[StreamHeaderLength];
        Magic.CopyTo(header);
        BinaryPrimitives.WriteUInt32BigEndian(header.Slice(8, 4), (uint)chunkSize);
        RandomNumberGenerator.Fill(header.Slice(12, NoncePrefixLength));
        output.Write(header);

        Span<byte> nonce = stackalloc byte[NonceSize];
        Span<byte> aad = stackalloc byte[AadLength];
        Span<byte> tag = stackalloc byte[TagSize];

        byte[] current = new byte[chunkSize];
        byte[] next = new byte[chunkSize];
        byte[] cipherBuffer = new byte[chunkSize];
        try
        {
            using var aes = new AesGcm(fileKey, TagSize);
            int currentLength = input.ReadAtLeast(current, chunkSize, throwOnEndOfStream: false);
            uint index = 0;
            long total = 0;

            while (true)
            {
                cancellationToken.ThrowIfCancellationRequested();

                // Look ahead one chunk so we know whether the current one is the last.
                int nextLength = currentLength == chunkSize
                    ? input.ReadAtLeast(next, chunkSize, throwOnEndOfStream: false)
                    : 0;
                bool isFinal = nextLength == 0;

                BuildNonce(header.Slice(12, NoncePrefixLength), index, nonce);
                BuildAad(header, binding, index, isFinal, aad);

                aes.Encrypt(nonce, current.AsSpan(0, currentLength), cipherBuffer.AsSpan(0, currentLength), tag, aad);
                output.Write(cipherBuffer.AsSpan(0, currentLength));
                output.Write(tag);
                total += currentLength;

                if (isFinal) break;
                if (index == uint.MaxValue)
                    throw new InvalidOperationException("File too large for this chunk size.");
                index++;
                (current, next) = (next, current);
                currentLength = nextLength;
            }

            output.Flush();
            return total;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(current);
            CryptographicOperations.ZeroMemory(next);
            CryptographicOperations.ZeroMemory(cipherBuffer);
        }
    }

    /// <returns>The number of plaintext bytes written.</returns>
    /// <exception cref="DataIntegrityException">Tampered, truncated, malformed, wrong key, or wrong file/vault binding.</exception>
    public static long Decrypt(
        Stream input, Stream output, ReadOnlySpan<byte> fileKey, FileBinding binding,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(input);
        ArgumentNullException.ThrowIfNull(output);
        RequireKey(fileKey);

        Span<byte> header = stackalloc byte[StreamHeaderLength];
        if (input.ReadAtLeast(header, StreamHeaderLength, throwOnEndOfStream: false) != StreamHeaderLength)
            throw new DataIntegrityException("Encrypted file is truncated (header).");
        if (!header.Slice(0, 8).SequenceEqual(Magic))
            throw new DataIntegrityException("Not a SecureUSB encrypted file.");

        uint declaredChunkSize = BinaryPrimitives.ReadUInt32BigEndian(header.Slice(8, 4));
        if (declaredChunkSize < MinChunkSize || declaredChunkSize > MaxChunkSize)
            throw new DataIntegrityException("Invalid chunk size in encrypted file.");

        int chunkSize = (int)declaredChunkSize;
        int fullChunk = chunkSize + TagSize;

        Span<byte> nonce = stackalloc byte[NonceSize];
        Span<byte> aad = stackalloc byte[AadLength];

        byte[] current = new byte[fullChunk];
        byte[] next = new byte[fullChunk];
        byte[] plain = new byte[chunkSize];
        try
        {
            using var aes = new AesGcm(fileKey, TagSize);
            int currentLength = input.ReadAtLeast(current, fullChunk, throwOnEndOfStream: false);
            uint index = 0;
            long total = 0;

            while (true)
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (currentLength < TagSize)
                    throw new DataIntegrityException("Encrypted file is truncated.");

                int nextLength = currentLength == fullChunk
                    ? input.ReadAtLeast(next, fullChunk, throwOnEndOfStream: false)
                    : 0;
                bool isFinal = nextLength == 0;

                int plainLength = currentLength - TagSize;
                BuildNonce(header.Slice(12, NoncePrefixLength), index, nonce);
                BuildAad(header, binding, index, isFinal, aad);

                try
                {
                    aes.Decrypt(
                        nonce,
                        current.AsSpan(0, plainLength),
                        current.AsSpan(plainLength, TagSize),
                        plain.AsSpan(0, plainLength),
                        aad);
                }
                catch (CryptographicException ex)
                {
                    throw new DataIntegrityException(
                        $"Integrity check failed at chunk {index}: the file is corrupted, tampered with, or the key does not match.", ex);
                }

                output.Write(plain.AsSpan(0, plainLength));
                total += plainLength;

                if (isFinal) break;
                if (index == uint.MaxValue)
                    throw new DataIntegrityException("Encrypted file has too many chunks.");
                index++;
                (current, next) = (next, current);
                currentLength = nextLength;
            }

            output.Flush();
            return total;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(current);
            CryptographicOperations.ZeroMemory(next);
            CryptographicOperations.ZeroMemory(plain);
        }
    }

    private static void BuildNonce(ReadOnlySpan<byte> prefix, uint index, Span<byte> nonce)
    {
        prefix.CopyTo(nonce);
        BinaryPrimitives.WriteUInt32BigEndian(nonce.Slice(NoncePrefixLength, 4), index);
    }

    private static void BuildAad(ReadOnlySpan<byte> streamHeader, FileBinding binding, uint index, bool isFinal, Span<byte> aad)
    {
        streamHeader.CopyTo(aad);
        binding.VaultId.TryWriteBytes(aad.Slice(StreamHeaderLength, 16));
        binding.FileId.TryWriteBytes(aad.Slice(StreamHeaderLength + 16, 16));
        BinaryPrimitives.WriteUInt32BigEndian(aad.Slice(StreamHeaderLength + 32, 4), index);
        aad[StreamHeaderLength + 36] = isFinal ? (byte)1 : (byte)0;
    }

    private static void RequireKey(ReadOnlySpan<byte> key)
    {
        if (key.Length != Aead.KeySize)
            throw new ArgumentException($"File key must be {Aead.KeySize} bytes.", nameof(key));
    }

    private static void ValidateChunkSize(int chunkSize)
    {
        if (chunkSize < MinChunkSize || chunkSize > MaxChunkSize)
            throw new ArgumentOutOfRangeException(nameof(chunkSize), $"Chunk size must be {MinChunkSize}-{MaxChunkSize} bytes.");
    }
}
