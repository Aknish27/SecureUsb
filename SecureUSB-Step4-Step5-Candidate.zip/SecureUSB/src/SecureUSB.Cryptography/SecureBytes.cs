using System.Security.Cryptography;

namespace SecureUSB.Cryptography;

/// <summary>
/// Holds key material in a pinned array (so the GC never copies it around the heap) and
/// zeroes it on Dispose. This reduces, but cannot eliminate, exposure: while the vault is
/// unlocked, malware with access to process memory can still read keys.
/// </summary>
public sealed class SecureBytes : IDisposable
{
    private byte[]? _buffer;

    public SecureBytes(int length)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(length);
        Length = length;
        _buffer = GC.AllocateArray<byte>(length, pinned: true);
    }

    public int Length { get; }
    public bool IsDisposed => _buffer is null;

    public Span<byte> Span
    {
        get
        {
            byte[]? b = _buffer;
            if (b is null) throw new ObjectDisposedException(nameof(SecureBytes));
            return b.AsSpan();
        }
    }

    public static SecureBytes CopyFrom(ReadOnlySpan<byte> source)
    {
        var sb = new SecureBytes(source.Length);
        source.CopyTo(sb.Span);
        return sb;
    }

    public void Dispose()
    {
        byte[]? b = _buffer;
        if (b is null) return;
        CryptographicOperations.ZeroMemory(b);
        _buffer = null;
    }
}
