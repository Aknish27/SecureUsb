using System.Security.Cryptography;

namespace SecureUSB.Cryptography;

/// <summary>
/// AES-256-GCM sealing for small blobs (wrapped keys, encrypted index, log records).
/// Output layout: nonce(12) | ciphertext(n) | tag(16).
/// Nonces are random 96-bit values; this is safe for the small number of seals per key that
/// SecureUSB performs (index rewrites), far below the 2^32 limit. Large files use
/// <see cref="ChunkedFileCipher"/>, which uses a counter-based nonce instead.
/// </summary>
public static class Aead
{
    public const int KeySize = 32;
    public const int NonceSize = 12;
    public const int TagSize = 16;
    public const int Overhead = NonceSize + TagSize;

    public static byte[] Seal(ReadOnlySpan<byte> key, ReadOnlySpan<byte> plaintext, ReadOnlySpan<byte> associatedData)
    {
        RequireKey(key);
        var result = new byte[NonceSize + plaintext.Length + TagSize];
        Span<byte> nonce = result.AsSpan(0, NonceSize);
        Span<byte> ciphertext = result.AsSpan(NonceSize, plaintext.Length);
        Span<byte> tag = result.AsSpan(NonceSize + plaintext.Length, TagSize);

        RandomNumberGenerator.Fill(nonce);
        using var aes = new AesGcm(key, TagSize);
        aes.Encrypt(nonce, plaintext, ciphertext, tag, associatedData);
        return result;
    }

    /// <summary>Authenticates then decrypts. Throws <see cref="CryptographicException"/> on any failure.</summary>
    public static byte[] Open(ReadOnlySpan<byte> key, ReadOnlySpan<byte> sealedData, ReadOnlySpan<byte> associatedData)
    {
        RequireKey(key);
        if (sealedData.Length < Overhead)
            throw new CryptographicException("Sealed data is too short.");

        int length = sealedData.Length - Overhead;
        var plaintext = new byte[length];
        try
        {
            using var aes = new AesGcm(key, TagSize);
            aes.Decrypt(
                sealedData.Slice(0, NonceSize),
                sealedData.Slice(NonceSize, length),
                sealedData.Slice(NonceSize + length, TagSize),
                plaintext,
                associatedData);
            return plaintext;
        }
        catch
        {
            CryptographicOperations.ZeroMemory(plaintext);
            throw;
        }
    }

    /// <summary>Same as <see cref="Open"/> but the plaintext lands in zeroable pinned memory (for keys).</summary>
    public static SecureBytes OpenSecure(ReadOnlySpan<byte> key, ReadOnlySpan<byte> sealedData, ReadOnlySpan<byte> associatedData)
    {
        RequireKey(key);
        if (sealedData.Length < Overhead)
            throw new CryptographicException("Sealed data is too short.");

        int length = sealedData.Length - Overhead;
        var result = new SecureBytes(length);
        try
        {
            using var aes = new AesGcm(key, TagSize);
            aes.Decrypt(
                sealedData.Slice(0, NonceSize),
                sealedData.Slice(NonceSize, length),
                sealedData.Slice(NonceSize + length, TagSize),
                result.Span,
                associatedData);
            return result;
        }
        catch
        {
            result.Dispose();
            throw;
        }
    }

    private static void RequireKey(ReadOnlySpan<byte> key)
    {
        if (key.Length != KeySize)
            throw new ArgumentException($"Key must be {KeySize} bytes.", nameof(key));
    }
}
