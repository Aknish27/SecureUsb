using System.Security.Cryptography;
using Konscious.Security.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Cryptography;

/// <summary>
/// Password -> 256-bit Key-Encryption Key using Argon2id (memory-hard), via the
/// Konscious.Security.Cryptography.Argon2 library. We implement no primitives ourselves.
/// </summary>
public static class Argon2idKeyDeriver
{
    public static SecureBytes DeriveKey(ReadOnlySpan<char> password, ReadOnlySpan<byte> salt, KdfParams kdf)
    {
        if (password.IsEmpty) throw new ArgumentException("Password must not be empty.", nameof(password));
        if (salt.Length != KdfParams.SaltLength)
            throw new ArgumentException($"Salt must be {KdfParams.SaltLength} bytes.", nameof(salt));
        ArgumentNullException.ThrowIfNull(kdf);
        kdf.Validate();

        byte[] pwd = PasswordEncoding.ToUtf8(password);
        try
        {
            using var argon2 = new Argon2id(pwd)
            {
                Salt = salt.ToArray(),
                DegreeOfParallelism = kdf.Parallelism,
                Iterations = kdf.Iterations,
                MemorySize = kdf.MemoryKiB   // Konscious expects KiB
            };
            byte[] raw = argon2.GetBytes(KdfParams.DerivedKeyLength);
            try { return SecureBytes.CopyFrom(raw); }
            finally { CryptographicOperations.ZeroMemory(raw); }
        }
        finally
        {
            CryptographicOperations.ZeroMemory(pwd);
        }
    }
}
