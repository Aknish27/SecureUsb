using System.Security.Cryptography;

namespace SecureUSB.Cryptography;

/// <summary>The only source of randomness in SecureUSB: the operating system CSPRNG.</summary>
public static class SecureRandom
{
    public static void Fill(Span<byte> destination) => RandomNumberGenerator.Fill(destination);

    public static byte[] GetBytes(int count) => RandomNumberGenerator.GetBytes(count);

    public static Guid NewGuid()
    {
        Span<byte> b = stackalloc byte[16];
        RandomNumberGenerator.Fill(b);
        return new Guid(b);
    }
}
