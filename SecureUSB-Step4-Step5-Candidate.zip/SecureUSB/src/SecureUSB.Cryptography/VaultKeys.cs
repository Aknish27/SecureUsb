using System.Security.Cryptography;
using System.Text;

namespace SecureUSB.Cryptography;

/// <summary>Independent subkeys derived from the master key (domain separation).</summary>
public enum KeyPurpose
{
    Index = 1,
    ActivityLog = 2,
    FileKeyWrapping = 3
}

/// <summary>
/// The unlocked state of a vault: owns the random 256-bit Master Key and derives purpose-specific
/// subkeys from it with HKDF-SHA256 (salt = vault ID, info = purpose label). Dispose = lock:
/// the master key is zeroed. Callers must dispose every <see cref="SecureBytes"/> they receive.
/// </summary>
public sealed class VaultKeys : IDisposable
{
    public const int KeyLength = 32;
    private readonly SecureBytes _masterKey;

    /// <summary>Takes ownership of <paramref name="masterKey"/>.</summary>
    public VaultKeys(Guid vaultId, SecureBytes masterKey)
    {
        ArgumentNullException.ThrowIfNull(masterKey);
        if (masterKey.Length != KeyLength)
            throw new ArgumentException($"Master key must be {KeyLength} bytes.", nameof(masterKey));
        VaultId = vaultId;
        _masterKey = masterKey;
    }

    public Guid VaultId { get; }
    public bool IsDisposed => _masterKey.IsDisposed;

    internal ReadOnlySpan<byte> MasterKey => _masterKey.Span;

    public SecureBytes DeriveKey(KeyPurpose purpose)
    {
        Span<byte> salt = stackalloc byte[16];
        VaultId.TryWriteBytes(salt);
        byte[] info = Encoding.ASCII.GetBytes(Label(purpose));

        var derived = new SecureBytes(KeyLength);
        try
        {
            HKDF.DeriveKey(HashAlgorithmName.SHA256, _masterKey.Span, derived.Span, salt, info);
            return derived;
        }
        catch
        {
            derived.Dispose();
            throw;
        }
    }

    /// <summary>A fresh random per-file key. Every file gets its own.</summary>
    public SecureBytes GenerateFileKey()
    {
        var key = new SecureBytes(KeyLength);
        SecureRandom.Fill(key.Span);
        return key;
    }

    /// <summary>Wraps a file key (AES-256-GCM) bound to this vault and file ID. Store the result in the encrypted index.</summary>
    public byte[] WrapFileKey(ReadOnlySpan<byte> fileKey, Guid fileId)
    {
        if (fileKey.Length != KeyLength) throw new ArgumentException("File key must be 32 bytes.", nameof(fileKey));
        using var wrapKey = DeriveKey(KeyPurpose.FileKeyWrapping);
        return Aead.Seal(wrapKey.Span, fileKey, FileKeyAad(fileId));
    }

    /// <summary>Throws <see cref="CryptographicException"/> if the wrapped key was altered or belongs to another file/vault.</summary>
    public SecureBytes UnwrapFileKey(ReadOnlySpan<byte> wrappedFileKey, Guid fileId)
    {
        using var wrapKey = DeriveKey(KeyPurpose.FileKeyWrapping);
        return Aead.OpenSecure(wrapKey.Span, wrappedFileKey, FileKeyAad(fileId));
    }

    public void Dispose() => _masterKey.Dispose();

    private byte[] FileKeyAad(Guid fileId)
    {
        var aad = new byte[32];
        VaultId.TryWriteBytes(aad.AsSpan(0, 16));
        fileId.TryWriteBytes(aad.AsSpan(16, 16));
        return aad;
    }

    private static string Label(KeyPurpose purpose) => purpose switch
    {
        KeyPurpose.Index => "SecureUSB/v1/index",
        KeyPurpose.ActivityLog => "SecureUSB/v1/activity-log",
        KeyPurpose.FileKeyWrapping => "SecureUSB/v1/file-key-wrap",
        _ => throw new ArgumentOutOfRangeException(nameof(purpose))
    };
}
