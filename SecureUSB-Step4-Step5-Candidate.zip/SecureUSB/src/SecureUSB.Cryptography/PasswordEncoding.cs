using System.Text;

namespace SecureUSB.Cryptography;

internal static class PasswordEncoding
{
    /// <summary>
    /// Normalizes to Unicode NFKC then encodes as UTF-8, so the same visible password typed on
    /// different keyboards/systems yields the same key. Limitation: string normalization creates a
    /// managed string that cannot be zeroed; only the resulting byte[] is wiped by callers.
    /// </summary>
    public static byte[] ToUtf8(ReadOnlySpan<char> password)
    {
        string normalized = new string(password).Normalize(NormalizationForm.FormKC);
        return Encoding.UTF8.GetBytes(normalized);
    }
}
