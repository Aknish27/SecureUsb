using System.Globalization;
using SecureUSB.Models;
using SecureUSB.Storage;
using SecureUSB.ViewModels.Mvvm;

namespace SecureUSB.ViewModels;

public enum ItemStatus { Encrypted, Damaged, Folder, FolderNeedsAttention }

/// <summary>One row of the file table: a file or a (virtual) folder.</summary>
public sealed class VaultItemViewModel : ObservableObject
{
    private ItemStatus _status;

    private VaultItemViewModel(bool isFolder, string name, string type, long sizeBytes, string sizeText,
        DateTimeOffset modified, string location, FileEntry? entry, string folderFullPath, ItemStatus status)
    {
        IsFolder = isFolder;
        Name = name;
        Type = type;
        SizeBytes = sizeBytes;
        SizeText = sizeText;
        Modified = modified;
        DateText = modified.ToLocalTime().ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
        Location = location;
        Entry = entry;
        FolderFullPath = folderFullPath;
        _status = status;
    }

    public static VaultItemViewModel ForFile(FileEntry entry, ItemStatus status = ItemStatus.Encrypted) =>
        new(false, entry.Name, FileTypeDescriber.Describe(entry.Extension), entry.SizeBytes, ByteSize.Format(entry.SizeBytes),
            entry.ModifiedUtc, entry.FolderPath, entry, "", status);

    public static VaultItemViewModel ForFolder(string fullPath, string name, int fileCount, long bytes, DateTimeOffset latest, bool needsAttention) =>
        new(true, name, "Folder", bytes,
            $"{fileCount} file{(fileCount == 1 ? "" : "s")} \u00B7 {ByteSize.Format(bytes)}",
            latest, fullPath.Contains('/') ? fullPath[..fullPath.LastIndexOf('/')] : "", null, fullPath,
            needsAttention ? ItemStatus.FolderNeedsAttention : ItemStatus.Folder);

    public bool IsFolder { get; }
    public string Name { get; }
    public string Type { get; }
    public long SizeBytes { get; }
    public string SizeText { get; }
    public DateTimeOffset Modified { get; }
    public string DateText { get; }
    /// <summary>The virtual folder that contains the item ("" = top level). Shown as a tooltip.</summary>
    public string Location { get; }
    public FileEntry? Entry { get; }
    public string FolderFullPath { get; }
    public string Glyph => IsFolder ? "\uE8B7" : "\uE8A5";

    public ItemStatus Status
    {
        get => _status;
        set
        {
            if (!SetProperty(ref _status, value)) return;
            OnPropertyChanged(nameof(StatusText));
            OnPropertyChanged(nameof(IsDamaged));
        }
    }

    public string StatusText => Status switch
    {
        ItemStatus.Encrypted => "Encrypted",
        ItemStatus.Damaged => "Damaged",
        ItemStatus.FolderNeedsAttention => "Needs attention",
        _ => "\u2014"
    };

    public bool IsDamaged => Status is ItemStatus.Damaged or ItemStatus.FolderNeedsAttention;
}

public static class VaultItemBuilder
{
    /// <summary>
    /// Builds the rows for the current view. With a search query: a flat list of matching files from every folder.
    /// Without: the sub-folders and files directly inside <paramref name="folder"/> (folders first, then by name).
    /// </summary>
    public static IReadOnlyList<VaultItemViewModel> Build(
        IReadOnlyList<FileEntry> all, string folder, string? query, IReadOnlyDictionary<Guid, ItemStatus>? statuses = null)
    {
        ItemStatus StatusOf(FileEntry e) =>
            statuses is not null && statuses.TryGetValue(e.Id, out ItemStatus s) ? s : ItemStatus.Encrypted;

        string q = (query ?? "").Trim();
        if (q.Length > 0)
        {
            return all
                .Where(e => e.Name.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                            e.FolderPath.Contains(q, StringComparison.OrdinalIgnoreCase))
                .OrderBy(e => e.Name, StringComparer.OrdinalIgnoreCase)
                .Select(e => VaultItemViewModel.ForFile(e, StatusOf(e)))
                .ToList();
        }

        string prefix = folder.Length == 0 ? "" : folder + "/";
        var files = new List<VaultItemViewModel>();
        var folders = new Dictionary<string, List<FileEntry>>(StringComparer.OrdinalIgnoreCase);

        foreach (FileEntry e in all)
        {
            if (string.Equals(e.FolderPath, folder, StringComparison.OrdinalIgnoreCase))
            {
                files.Add(VaultItemViewModel.ForFile(e, StatusOf(e)));
            }
            else if (e.FolderPath.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) && e.FolderPath.Length > prefix.Length)
            {
                string rest = e.FolderPath[prefix.Length..];
                int slash = rest.IndexOf('/');
                string segment = slash < 0 ? rest : rest[..slash];
                if (!folders.TryGetValue(segment, out List<FileEntry>? list))
                    folders[segment] = list = new List<FileEntry>();
                list.Add(e);
            }
        }

        var result = new List<VaultItemViewModel>();
        foreach (var kv in folders.OrderBy(k => k.Key, StringComparer.OrdinalIgnoreCase))
        {
            List<FileEntry> inside = kv.Value;
            result.Add(VaultItemViewModel.ForFolder(
                prefix + kv.Key, kv.Key, inside.Count, inside.Sum(f => f.SizeBytes),
                inside.Max(f => f.ModifiedUtc), inside.Any(f => StatusOf(f) == ItemStatus.Damaged)));
        }
        result.AddRange(files.OrderBy(f => f.Name, StringComparer.OrdinalIgnoreCase));
        return result;
    }

    /// <summary>All files at or below a folder path.</summary>
    public static IEnumerable<FileEntry> FilesUnder(IReadOnlyList<FileEntry> all, string folderFullPath) =>
        all.Where(e => string.Equals(e.FolderPath, folderFullPath, StringComparison.OrdinalIgnoreCase) ||
                       e.FolderPath.StartsWith(folderFullPath + "/", StringComparison.OrdinalIgnoreCase));
}

public enum PreviewKind { None, Loading, Text, Image, Unsupported, TooLarge, Error }

public static class PreviewClassifier
{
    public const long MaxImageBytes = 8L * 1024 * 1024;
    public const long MaxTextBytes = 1L * 1024 * 1024;

    private static readonly HashSet<string> ImageTypes = new(StringComparer.OrdinalIgnoreCase) { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };
    private static readonly HashSet<string> TextTypes = new(StringComparer.OrdinalIgnoreCase)
        { ".txt", ".md", ".csv", ".log", ".json", ".xml", ".ini", ".yml", ".yaml" };

    /// <returns>Image/Text if previewable in memory, TooLarge if previewable but over the limit, otherwise Unsupported.</returns>
    public static PreviewKind Classify(string extension, long sizeBytes)
    {
        if (ImageTypes.Contains(extension)) return sizeBytes <= MaxImageBytes ? PreviewKind.Image : PreviewKind.TooLarge;
        if (TextTypes.Contains(extension)) return sizeBytes <= MaxTextBytes ? PreviewKind.Text : PreviewKind.TooLarge;
        return PreviewKind.Unsupported;
    }

    public static long LimitFor(PreviewKind kind) => kind == PreviewKind.Image ? MaxImageBytes : MaxTextBytes;
}

public sealed record BreadcrumbItem(string Name, string Path);

public enum HealthLevel { Unknown, Healthy, Warning, Error }

/// <summary>Result of the latest integrity check, shared by the dashboard badge and the health window.</summary>
public sealed class HealthStatus : ObservableObject
{
    private HealthLevel _level;
    private string _text = "Not checked yet";
    private string _lastChecked = "";
    private IntegrityReport? _report;

    public HealthLevel Level { get => _level; private set => SetProperty(ref _level, value); }
    public string Text { get => _text; private set => SetProperty(ref _text, value); }
    public string LastChecked { get => _lastChecked; private set => SetProperty(ref _lastChecked, value); }
    public IntegrityReport? Report { get => _report; private set => SetProperty(ref _report, value); }

    public void Update(IntegrityReport report, DateTimeOffset when)
    {
        int errors = report.Issues.Count(i => i.Severity == IssueSeverity.Error);
        int warnings = report.Issues.Count(i => i.Severity == IssueSeverity.Warning);

        Report = report;
        if (errors > 0)
        {
            Level = HealthLevel.Error;
            Text = $"{errors} problem{(errors == 1 ? "" : "s")} found";
        }
        else if (warnings > 0)
        {
            Level = HealthLevel.Warning;
            Text = $"{warnings} item{(warnings == 1 ? "" : "s")} need{(warnings == 1 ? "s" : "")} attention";
        }
        else
        {
            Level = HealthLevel.Healthy;
            Text = report.DeepVerified ? "All files verified" : "No problems found";
        }
        LastChecked = "Last checked " + when.ToLocalTime().ToString("HH:mm", CultureInfo.InvariantCulture)
                      + (report.DeepVerified ? " (full check)" : " (quick check)");
    }

    public void SetUnavailable()
    {
        Level = HealthLevel.Unknown;
        Text = "Health check unavailable";
    }
}

/// <summary>The three separate storage numbers the product promises: physical drive, vault, application files.</summary>
public sealed class StorageViewModel : ObservableObject
{
    private string _totalText = "\u2014", _freeText = "\u2014", _vaultText = "\u2014", _appText = "\u2014", _otherText = "\u2014";
    private string _driveText = "";
    private double _usedFraction;
    private bool _lowSpace;
    private bool _available;

    public string TotalText { get => _totalText; private set => SetProperty(ref _totalText, value); }
    public string FreeText { get => _freeText; private set => SetProperty(ref _freeText, value); }
    public string VaultText { get => _vaultText; private set => SetProperty(ref _vaultText, value); }
    public string ApplicationText { get => _appText; private set => SetProperty(ref _appText, value); }
    public string OtherText { get => _otherText; private set => SetProperty(ref _otherText, value); }
    public string DriveText { get => _driveText; private set => SetProperty(ref _driveText, value); }
    public double UsedFraction { get => _usedFraction; private set => SetProperty(ref _usedFraction, value); }
    public bool LowSpace { get => _lowSpace; private set => SetProperty(ref _lowSpace, value); }
    public bool IsAvailable { get => _available; private set => SetProperty(ref _available, value); }

    public void Update(StorageUsage u)
    {
        TotalText = ByteSize.Format(u.TotalBytes);
        FreeText = ByteSize.Format(u.FreeBytes);
        VaultText = ByteSize.Format(u.VaultBytes);
        ApplicationText = ByteSize.Format(u.ApplicationBytes);
        OtherText = ByteSize.Format(u.OtherBytes);
        string label = string.IsNullOrWhiteSpace(u.Drive.VolumeLabel) ? "" : u.Drive.VolumeLabel + " \u00B7 ";
        DriveText = $"{label}{u.Drive.FileSystem} \u00B7 {(u.Drive.IsRemovable ? "Removable drive" : "Fixed drive")}";
        UsedFraction = u.TotalBytes > 0 ? Math.Clamp((double)u.UsedBytes / u.TotalBytes, 0, 1) : 0;
        LowSpace = u.TotalBytes > 0 && (u.FreeBytes < u.TotalBytes / 20 || u.FreeBytes < 100L * 1024 * 1024);
        IsAvailable = true;
    }

    public void SetUnavailable()
    {
        IsAvailable = false;
        DriveText = "Drive information unavailable";
    }
}
