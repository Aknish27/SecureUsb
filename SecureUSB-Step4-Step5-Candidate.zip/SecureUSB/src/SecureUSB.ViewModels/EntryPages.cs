using System.Collections.ObjectModel;
using SecureUSB.Core;
using SecureUSB.Security;
using SecureUSB.ViewModels.Mvvm;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels;

public interface IShellNavigation
{
    void ShowWelcome();
    void OpenLocation(VaultLocation location);
    void ShowDashboard();
    /// <summary>The user did something: restarts the auto-lock countdown.</summary>
    void NotifyActivity();
}

/// <summary>Vault selection: which drive holds (or will hold) the vault.</summary>
public sealed class WelcomeViewModel : PageViewModel
{
    private readonly IShellNavigation _nav;
    private readonly ILocationProvider _locations;
    private readonly IFileDialogService _files;
    private string _message = "";

    public WelcomeViewModel(IShellNavigation nav, ILocationProvider locations, IFileDialogService files)
    {
        _nav = nav;
        _locations = locations;
        _files = files;
        SelectCommand = new RelayCommand<VaultLocation>(l => { if (l is not null) _nav.OpenLocation(l); });
        BrowseCommand = new RelayCommand(Browse);
        RefreshCommand = new RelayCommand(Refresh);
        Refresh();
    }

    public ObservableCollection<VaultLocation> Locations { get; } = new();
    public bool HasLocations => Locations.Count > 0;
    public string Message { get => _message; private set => SetProperty(ref _message, value); }
    public RelayCommand<VaultLocation> SelectCommand { get; }
    public RelayCommand BrowseCommand { get; }
    public RelayCommand RefreshCommand { get; }

    private void Refresh()
    {
        Locations.Clear();
        try
        {
            foreach (VaultLocation l in _locations.Discover()) Locations.Add(l);
        }
        catch (Exception)
        {
            // drive enumeration failed: the user can still browse manually
        }

        OnPropertyChanged(nameof(HasLocations));
        Message = HasLocations
            ? "Choose the drive that holds your vault, or the drive where you want to create one."
            : "No removable drive was found. Insert your SecureUSB drive and choose Refresh, or pick a folder manually.";
    }

    private void Browse()
    {
        string? folder = _files.PickFolder("Choose the drive or folder for the vault");
        if (!string.IsNullOrWhiteSpace(folder)) _nav.OpenLocation(_locations.FromFolder(folder));
    }
}

/// <summary>First-time setup: choose ONE password. Nothing else is asked.</summary>
public sealed class CreateVaultViewModel : PageViewModel
{
    public const string WarningText =
        "If you forget this password, your files cannot be recovered. There is no reset and no backdoor: " +
        "not even the organisation or the software maker can open the vault without it.";

    private static readonly string[] StrengthNames = { "Very weak", "Weak", "Fair", "Strong", "Very strong" };

    private readonly VaultService _service;
    private readonly IShellNavigation _nav;
    private string _password = "", _confirmation = "", _error = "";
    private bool _showPassword, _understood, _busy;
    private PasswordAssessment _assessment = PasswordPolicy.Evaluate("");

    public CreateVaultViewModel(VaultService service, VaultLocation location, IShellNavigation nav)
    {
        _service = service;
        _nav = nav;
        Location = location;
        CreateCommand = AsyncCommand(CreateAsync, () => CanCreate);
        BackCommand = new RelayCommand(_nav.ShowWelcome, () => !IsBusy);
        ToggleShowPasswordCommand = new RelayCommand(() => ShowPassword = !ShowPassword);
    }

    public VaultLocation Location { get; }
    public string LocationText => $"{Location.DisplayName} \u2014 {Location.Details}";
    public AsyncRelayCommand CreateCommand { get; }
    public RelayCommand BackCommand { get; }
    public RelayCommand ToggleShowPasswordCommand { get; }

    public string Password
    {
        get => _password;
        set
        {
            if (!SetProperty(ref _password, value)) return;
            _assessment = PasswordPolicy.Evaluate(value);
            ErrorMessage = "";
            OnPropertyChanged(nameof(StrengthLevel));
            OnPropertyChanged(nameof(StrengthText));
            OnPropertyChanged(nameof(StrengthFraction));
            OnPropertyChanged(nameof(PolicyMessages));
            Changed();
        }
    }

    public string Confirmation
    {
        get => _confirmation;
        set
        {
            if (!SetProperty(ref _confirmation, value)) return;
            ErrorMessage = "";
            OnPropertyChanged(nameof(MismatchText));
            Changed();
        }
    }

    public bool ShowPassword { get => _showPassword; set => SetProperty(ref _showPassword, value); }

    public bool Understood
    {
        get => _understood;
        set
        {
            if (SetProperty(ref _understood, value)) Changed();
        }
    }

    public bool IsBusy
    {
        get => _busy;
        private set
        {
            if (SetProperty(ref _busy, value)) Changed();
        }
    }

    public string ErrorMessage { get => _error; private set => SetProperty(ref _error, value); }

    /// <summary>-1 = nothing typed yet, otherwise 0 (very weak) to 4 (very strong).</summary>
    public int StrengthLevel => Password.Length == 0 ? -1 : (int)_assessment.Strength;
    public string StrengthText => Password.Length == 0 ? "" : StrengthNames[(int)_assessment.Strength];
    public double StrengthFraction => Password.Length == 0 ? 0 : ((int)_assessment.Strength + 1) / 5.0;

    public IReadOnlyList<string> PolicyMessages =>
        Password.Length == 0 ? Array.Empty<string>() : _assessment.Issues.Concat(_assessment.Suggestions).ToList();

    public string MismatchText =>
        Confirmation.Length > 0 && !string.Equals(Password, Confirmation, StringComparison.Ordinal) ? "The passwords do not match." : "";

    public bool CanCreate =>
        !IsBusy && Understood && _assessment.MeetsPolicy && string.Equals(Password, Confirmation, StringComparison.Ordinal);

    private void Changed()
    {
        OnPropertyChanged(nameof(CanCreate));
        CreateCommand.RaiseCanExecuteChanged();
        BackCommand.RaiseCanExecuteChanged();
    }

    private async Task CreateAsync()
    {
        ErrorMessage = "";
        IsBusy = true;
        bool created = false;
        try
        {
            string password = Password, confirmation = Confirmation;
            await Task.Run(() => _service.CreateVault(password, confirmation));
            created = true;
        }
        catch (Exception ex)
        {
            ErrorMessage = ErrorMessages.Describe(ex);
        }
        finally
        {
            IsBusy = false;
        }

        if (!created) return;
        Password = "";
        Confirmation = "";
        _nav.ShowDashboard();
    }

    protected override Task OnCommandErrorAsync(Exception ex)
    {
        ErrorMessage = ErrorMessages.Describe(ex);
        return Task.CompletedTask;
    }

    public override void Dispose()
    {
        Password = "";
        Confirmation = "";
    }
}

/// <summary>Login: ONE password. Shows failed attempts and the cooldown, and the recovery options when they apply.</summary>
public sealed class UnlockViewModel : PageViewModel
{
    private readonly VaultService _service;
    private readonly IShellNavigation _nav;
    private readonly IDialogService _dialogs;
    private readonly IDisposable _timer;
    private string _password = "", _message = "", _cooldownText = "";
    private BannerKind _messageKind = BannerKind.Info;
    private bool _show, _busy, _cooling, _backupAvailable, _indexDamaged;
    private int _failed;

    public UnlockViewModel(VaultService service, VaultLocation location, IShellNavigation nav, IUiScheduler ui, IDialogService dialogs)
    {
        _service = service;
        _nav = nav;
        _dialogs = dialogs;
        Location = location;

        UnlockCommand = AsyncCommand(() => AttemptAsync(() => _service.Unlock(Password)), () => CanUnlock);
        UnlockWithBackupCommand = AsyncCommand(() => AttemptAsync(() => _service.UnlockUsingBackupHeader(Password)), () => CanUnlock && BackupHeaderAvailable);
        RebuildIndexCommand = AsyncCommand(RebuildAsync, () => CanUnlock && IndexDamaged);
        ChangeLocationCommand = new RelayCommand(_nav.ShowWelcome, () => !IsBusy);
        ToggleShowPasswordCommand = new RelayCommand(() => ShowPassword = !ShowPassword);

        RefreshCooldown();
        _timer = ui.Every(TimeSpan.FromSeconds(1), RefreshCooldown);
    }

    public VaultLocation Location { get; }
    public string LocationText => $"{Location.DisplayName} \u2014 {Location.Details}";
    public AsyncRelayCommand UnlockCommand { get; }
    public AsyncRelayCommand UnlockWithBackupCommand { get; }
    public AsyncRelayCommand RebuildIndexCommand { get; }
    public RelayCommand ChangeLocationCommand { get; }
    public RelayCommand ToggleShowPasswordCommand { get; }

    public string Password
    {
        get => _password;
        set
        {
            if (SetProperty(ref _password, value)) RefreshCommands();
        }
    }

    public bool ShowPassword { get => _show; set => SetProperty(ref _show, value); }

    public bool IsBusy
    {
        get => _busy;
        private set
        {
            if (!SetProperty(ref _busy, value)) return;
            OnPropertyChanged(nameof(CanUnlock));
            RefreshCommands();
        }
    }

    public string Message { get => _message; private set { if (SetProperty(ref _message, value)) OnPropertyChanged(nameof(HasMessage)); } }
    public bool HasMessage => Message.Length > 0;
    public BannerKind MessageKind { get => _messageKind; private set => SetProperty(ref _messageKind, value); }
    public int FailedAttempts { get => _failed; private set { if (SetProperty(ref _failed, value)) OnPropertyChanged(nameof(AttemptsText)); } }
    public string AttemptsText => FailedAttempts > 0 ? $"Failed attempts since the last successful unlock: {FailedAttempts}" : "";

    public bool IsCoolingDown
    {
        get => _cooling;
        private set
        {
            if (!SetProperty(ref _cooling, value)) return;
            OnPropertyChanged(nameof(CanUnlock));
            RefreshCommands();
        }
    }

    public string CooldownText { get => _cooldownText; private set => SetProperty(ref _cooldownText, value); }

    public bool BackupHeaderAvailable
    {
        get => _backupAvailable;
        private set
        {
            if (SetProperty(ref _backupAvailable, value)) RefreshCommands();
        }
    }

    public bool IndexDamaged
    {
        get => _indexDamaged;
        private set
        {
            if (SetProperty(ref _indexDamaged, value)) RefreshCommands();
        }
    }

    public bool CanUnlock => !IsBusy && !IsCoolingDown && Password.Length > 0;

    /// <summary>Queries the attempt counter (the single source of truth is the Core service). Called once a second.</summary>
    public void RefreshCooldown()
    {
        try
        {
            AttemptStatus status = _service.GetLoginStatus();
            FailedAttempts = status.ConsecutiveFailures;
            if (status.IsLockedOut)
            {
                CooldownText = $"Too many failed attempts. You can try again in {FormatDelay(status.RemainingDelay)}.";
                IsCoolingDown = true;
            }
            else
            {
                CooldownText = "";
                IsCoolingDown = false;
            }
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            CooldownText = "";   // the drive is not readable right now; the unlock attempt will explain
        }
    }

    private async Task AttemptAsync(Func<UnlockResult> attempt)
    {
        Message = "";
        BackupHeaderAvailable = false;
        IndexDamaged = false;
        IsBusy = true;

        UnlockResult? result = null;
        try
        {
            result = await Task.Run(attempt);
        }
        catch (Exception ex)
        {
            Show(BannerKind.Error, ErrorMessages.Describe(ex));
        }
        finally
        {
            IsBusy = false;
        }

        if (result is not null) Apply(result);
        RefreshCooldown();
    }

    private void Apply(UnlockResult r)
    {
        switch (r.Status)
        {
            case UnlockStatus.Success:
                Password = "";
                _nav.ShowDashboard();
                break;
            case UnlockStatus.WrongPasswordOrDamagedVault:
                Show(BannerKind.Error, r.Message);
                BackupHeaderAvailable = r.BackupHeaderAvailable;
                break;
            case UnlockStatus.LockedOut:
            case UnlockStatus.VaultInUse:
                Show(BannerKind.Warning, r.Message);
                break;
            case UnlockStatus.PasswordRequired:
                Show(BannerKind.Info, "Enter your password.");
                break;
            case UnlockStatus.VaultNotInitialized:
                Show(BannerKind.Warning, "No vault was found on this drive. Choose another drive or create a new vault.");
                break;
            case UnlockStatus.HeaderUnreadable:
                Show(BannerKind.Error, "The vault header could not be read. The drive may be damaged.");
                break;
            case UnlockStatus.IndexDamaged:
                IndexDamaged = true;
                Show(BannerKind.Warning,
                    "Your password is correct, but the file index is damaged. You can rebuild it from the encrypted files; " +
                    "the original file names and folders cannot be recovered.");
                break;
            case UnlockStatus.UsbUnavailable:
                Show(BannerKind.Error, "The SecureUSB drive is not available. Reconnect it and try again.");
                break;
            default:
                Show(BannerKind.Error, "The USB drive could not be read. Check the connection and try again.");
                break;
        }
    }

    private async Task RebuildAsync()
    {
        bool ok = await _dialogs.ConfirmAsync(new ConfirmRequest(
            "Rebuild the file index?",
            "The encrypted files will be listed again with generic names (Recovered-xxxx.bin) in a folder called \"Recovered\". " +
            "Original names, folders and dates are lost. Your files themselves are not changed.",
            "Rebuild index", "Cancel"));
        if (ok) await AttemptAsync(() => _service.RebuildIndexAndUnlock(Password));
    }

    private void Show(BannerKind kind, string message)
    {
        MessageKind = kind;
        Message = message;
    }

    private void RefreshCommands()
    {
        UnlockCommand.RaiseCanExecuteChanged();
        UnlockWithBackupCommand.RaiseCanExecuteChanged();
        RebuildIndexCommand.RaiseCanExecuteChanged();
        ChangeLocationCommand.RaiseCanExecuteChanged();
    }

    private static string FormatDelay(TimeSpan t)
    {
        if (t.TotalMinutes >= 1)
        {
            int m = (int)Math.Ceiling(t.TotalMinutes);
            return $"{m} minute{(m == 1 ? "" : "s")}";
        }
        int s = Math.Max(1, (int)Math.Ceiling(t.TotalSeconds));
        return $"{s} second{(s == 1 ? "" : "s")}";
    }

    protected override Task OnCommandErrorAsync(Exception ex)
    {
        Show(BannerKind.Error, ErrorMessages.Describe(ex));
        return Task.CompletedTask;
    }

    public override void Dispose()
    {
        _timer.Dispose();
        Password = "";
    }
}
