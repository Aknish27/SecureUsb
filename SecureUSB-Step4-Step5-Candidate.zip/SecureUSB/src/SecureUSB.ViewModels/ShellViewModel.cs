using SecureUSB.Core;
using SecureUSB.ViewModels.Mvvm;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels;

/// <summary>Everything the shell needs from the outside world (all replaceable in tests).</summary>
public sealed class ShellServices
{
    public required IVaultServiceFactory Factory { get; init; }
    public required ILocationProvider Locations { get; init; }
    public required ModalHost Modals { get; init; }
    public required IFileDialogService Files { get; init; }
    public required IShellLauncher Launcher { get; init; }
    public required IUiScheduler Ui { get; init; }
    public required IThemeService Theme { get; init; }
    public required AppInfo App { get; init; }
    public TimeProvider Time { get; init; } = TimeProvider.System;
}

/// <summary>
/// The window's view-model: which page is showing, which vault service is active, and the single place that reacts to
/// the vault locking. Whatever the reason (Lock button, auto-lock, USB removed, exit) the service raises one
/// Locked event; this class then clears the unlocked screens and shows the unlock page with an explanation.
/// </summary>
public sealed class ShellViewModel : ObservableObject, IShellNavigation, IDisposable
{
    private readonly ShellServices _s;
    private VaultService? _service;
    private VaultLocation? _location;
    private PageViewModel? _page;
    private IDisposable? _idleTimer;
    private DateTimeOffset _lastActivity;
    private string? _pendingLockNotice;
    private bool _disposed;

    public ShellViewModel(ShellServices services)
    {
        _s = services;
        _lastActivity = _s.Time.GetUtcNow();
        Settings.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(SessionSettings.Theme)) _s.Theme.Apply(Settings.Theme);
        };
    }

    public SessionSettings Settings { get; } = new();
    public BannerViewModel Banner { get; } = new();
    public ModalHost Modals => _s.Modals;
    public VaultService? Service => _service;

    public PageViewModel? CurrentPage
    {
        get => _page;
        private set
        {
            if (ReferenceEquals(_page, value)) return;
            PageViewModel? old = _page;
            _page = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(WindowTitle));
            OnPropertyChanged(nameof(IsVaultUnlocked));
            old?.Dispose();
        }
    }

    public bool IsVaultUnlocked => _page is DashboardViewModel;

    public string WindowTitle => _page switch
    {
        DashboardViewModel => $"{_s.App.Name} \u2014 Unlocked",
        UnlockViewModel => $"{_s.App.Name} \u2014 Locked",
        _ => _s.App.Name
    };

    /// <summary>Called once at startup. If the drive this app runs from already holds a vault, go straight to its unlock screen.</summary>
    public void Initialize()
    {
        _idleTimer ??= _s.Ui.Every(TimeSpan.FromSeconds(15), () => _ = CheckIdleAsync());

        IReadOnlyList<VaultLocation> found;
        try { found = _s.Locations.Discover(); }
        catch (Exception) { found = Array.Empty<VaultLocation>(); }

        VaultLocation? own = found.FirstOrDefault(l => l.IsAppDrive && l.HasVault);
        if (own is not null) OpenLocation(own);
        else ShowWelcome();
    }

    // ------------------------------------------------------------------ navigation

    public void ShowWelcome()
    {
        DisposeService();
        CurrentPage = new WelcomeViewModel(this, _s.Locations, _s.Files);
    }

    public void OpenLocation(VaultLocation location)
    {
        DisposeService();
        VaultService service;
        try
        {
            service = _s.Factory.Create(location);
        }
        catch (Exception ex)
        {
            CurrentPage = new WelcomeViewModel(this, _s.Locations, _s.Files);
            Banner.Show(BannerKind.Error, ErrorMessages.Describe(ex));
            return;
        }

        _service = service;
        _location = location;
        service.Locked += OnServiceLocked;
        Banner.Hide();

        CurrentPage = service.State == VaultState.NotInitialized
            ? new CreateVaultViewModel(service, location, this)
            : new UnlockViewModel(service, location, this, _s.Ui, _s.Modals);
    }

    public void ShowDashboard()
    {
        if (_service is null || _location is null || !_service.IsUnlocked) return;
        Banner.Hide();
        NotifyActivity();
        var dashboard = new DashboardViewModel(_service, _location, this, _s.Modals, _s.Files, _s.Launcher, Settings, _s.App, _s.Time);
        CurrentPage = dashboard;
        _ = dashboard.InitializeAsync();
    }

    public void NotifyActivity() => _lastActivity = _s.Time.GetUtcNow();

    // ------------------------------------------------------------------ locking

    private void OnServiceLocked(object? sender, VaultLockedEventArgs e) =>
        _s.Ui.Post(() => HandleLocked(sender, e));

    private void HandleLocked(object? sender, VaultLockedEventArgs e)
    {
        if (_disposed || !ReferenceEquals(sender, _service) || _service is null || _location is null) return;

        // everything that shows vault data goes away first
        Modals.CloseVaultModals();
        CurrentPage = new UnlockViewModel(_service, _location, this, _s.Ui, _s.Modals);

        switch (e.Reason)
        {
            case LockReason.UsbRemoved:
                string text = "The SecureUSB drive was removed, so the vault was locked automatically and all decrypted data was cleared.";
                if (!e.TempCleanup.IsComplete)
                    text += " Some temporary decrypted files could not be removed because another program is using them. " +
                            "Close that program, unlock the vault and use Settings > Remove temporary files.";
                Banner.Show(BannerKind.Warning, text);
                break;
            case LockReason.User:
                if (_pendingLockNotice is not null) Banner.Show(BannerKind.Info, _pendingLockNotice);
                else Banner.Show(BannerKind.Info, "The vault is locked.");
                if (!e.TempCleanup.IsComplete)
                    Banner.Show(BannerKind.Warning, "The vault is locked, but some temporary decrypted files are still open in another program. Close that program and remove them from Settings after unlocking.");
                break;
            default:
                Banner.Hide();
                break;
        }
        _pendingLockNotice = null;
    }

    /// <summary>Called by the idle timer; also callable from tests.</summary>
    public async Task CheckIdleAsync()
    {
        VaultService? service = _service;
        if (service is null || !service.IsUnlocked) return;
        int minutes = Settings.AutoLockMinutes;
        if (minutes <= 0) return;
        if (_page is DashboardViewModel { IsBusy: true }) return;   // never lock in the middle of an import/export
        if (_s.Time.GetUtcNow() - _lastActivity < TimeSpan.FromMinutes(minutes)) return;

        _pendingLockNotice = $"The vault was locked after {minutes} minute{(minutes == 1 ? "" : "s")} of inactivity.";
        await Task.Run(() => service.Lock());
    }

    private void DisposeService()
    {
        VaultService? service = _service;
        _service = null;
        _location = null;
        if (service is null) return;
        service.Locked -= OnServiceLocked;
        Modals.CloseVaultModals();
        if (_page is DashboardViewModel) CurrentPage = null;
        service.Dispose();   // locks (if needed), wipes temporary files and keys
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _idleTimer?.Dispose();
        DisposeService();
        CurrentPage = null;
    }
}
