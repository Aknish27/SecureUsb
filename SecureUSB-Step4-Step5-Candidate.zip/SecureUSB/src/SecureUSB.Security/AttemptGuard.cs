using System.Buffers.Binary;
using System.Security.Cryptography;
using SecureUSB.Storage;

namespace SecureUSB.Security;

/// <summary>Progressive delay schedule for failed unlock attempts.</summary>
public sealed record AttemptPolicy
{
    /// <summary>Failures up to this number carry no delay (typing mistakes).</summary>
    public int FreeFailures { get; init; } = 2;

    /// <summary>Delay after failure FreeFailures+1, +2, ...; the last value repeats. Default: 5s, 15s, 30s, 1m, 5m, 15m, 30m.</summary>
    public IReadOnlyList<TimeSpan> Delays { get; init; } = new[]
    {
        TimeSpan.FromSeconds(5), TimeSpan.FromSeconds(15), TimeSpan.FromSeconds(30),
        TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(5), TimeSpan.FromMinutes(15), TimeSpan.FromMinutes(30)
    };

    /// <summary>A damaged/edited counter file is treated as this many consecutive failures (never as "zero").</summary>
    public int CorruptFileFailureCount { get; init; } = 5;

    public TimeSpan DelayFor(int consecutiveFailures)
    {
        if (consecutiveFailures <= FreeFailures || Delays.Count == 0) return TimeSpan.Zero;
        int index = consecutiveFailures - FreeFailures - 1;
        return Delays[Math.Min(index, Delays.Count - 1)];
    }
}

public readonly record struct AttemptStatus(int ConsecutiveFailures, TimeSpan RemainingDelay)
{
    public bool IsLockedOut => RemainingDelay > TimeSpan.Zero;
}

/// <summary>
/// Failed-attempt counter with progressive delays, persisted in guard.dat so that closing and reopening
/// the application does not reset it.
///
/// HONEST LIMITS: this file must be readable BEFORE any key exists, so it cannot be a secret or truly
/// tamper-proof. It slows down someone typing passwords into the application. It does NOT stop an attacker
/// who copies the vault and attacks it offline (they never run this code), and anyone with write access to the
/// USB can delete guard.dat to reset it or set the PC clock forward to skip a delay. The real protection against
/// offline guessing is Argon2id plus password strength. A checksum detects accidental damage and naive edits;
/// a damaged file is penalised rather than forgiven. There is deliberately NO "wipe after N failures" feature:
/// it would let anyone destroy your data by typing wrong passwords.
/// File: "SUSBGRD1"(8) | failures u32 | last failure (Unix ms) i64 | SHA-256 of the previous 20 bytes (32)
/// </summary>
public sealed class AttemptGuard
{
    private const int ContentLength = 8 + 4 + 8;
    private const int FileLength = ContentLength + 32;
    private const int MaxFailuresStored = 1000;
    private static ReadOnlySpan<byte> Magic => "SUSBGRD1"u8;

    private readonly string _path;
    private readonly TimeProvider _time;
    private readonly AttemptPolicy _policy;
    private readonly object _gate = new();

    public AttemptGuard(string path, TimeProvider? time = null, AttemptPolicy? policy = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        _path = Path.GetFullPath(path);
        _time = time ?? TimeProvider.System;
        _policy = policy ?? new AttemptPolicy();
    }

    public AttemptStatus GetStatus()
    {
        lock (_gate) return Compute(Load());
    }

    public AttemptStatus RecordFailure()
    {
        lock (_gate)
        {
            State current = Load();
            var next = new State(Math.Min(current.Failures + 1, MaxFailuresStored), _time.GetUtcNow().ToUnixTimeMilliseconds());
            Save(next);
            return Compute(next);
        }
    }

    /// <returns>The number of consecutive failures that were cleared.</returns>
    public int RecordSuccess()
    {
        lock (_gate)
        {
            int previous = Load().Failures;
            if (File.Exists(_path) && !AtomicFile.TryDelete(_path))
                Save(new State(0, 0));   // could not delete: at least zero it
            return previous;
        }
    }

    private AttemptStatus Compute(State s)
    {
        TimeSpan delay = _policy.DelayFor(s.Failures);
        if (delay <= TimeSpan.Zero) return new AttemptStatus(s.Failures, TimeSpan.Zero);

        TimeSpan elapsed = _time.GetUtcNow() - DateTimeOffset.FromUnixTimeMilliseconds(s.LastFailureUnixMs);
        if (elapsed < TimeSpan.Zero) elapsed = TimeSpan.Zero;   // clock moved backwards: the full delay applies
        TimeSpan remaining = delay - elapsed;
        return new AttemptStatus(s.Failures, remaining > TimeSpan.Zero ? remaining : TimeSpan.Zero);
    }

    private State Load()
    {
        FileInfo info = new(_path);
        if (!info.Exists) return new State(0, 0);

        byte[]? data = null;
        try
        {
            if (info.Length == FileLength) data = File.ReadAllBytes(_path);
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            throw;   // the drive is unreadable: surface it, do not pretend the counter is zero
        }

        if (data is not null && IsValid(data))
        {
            return new State(
                (int)Math.Min(BinaryPrimitives.ReadUInt32BigEndian(data.AsSpan(8, 4)), (uint)MaxFailuresStored),
                BinaryPrimitives.ReadInt64BigEndian(data.AsSpan(12, 8)));
        }

        // Damaged or edited: penalise and rewrite a valid file so the penalty is applied consistently.
        var penalty = new State(_policy.CorruptFileFailureCount, _time.GetUtcNow().ToUnixTimeMilliseconds());
        Save(penalty);
        return penalty;
    }

    private static bool IsValid(byte[] data)
    {
        if (data.Length != FileLength || !data.AsSpan(0, 8).SequenceEqual(Magic)) return false;
        byte[] hash = SHA256.HashData(data.AsSpan(0, ContentLength));
        return CryptographicOperations.FixedTimeEquals(hash, data.AsSpan(ContentLength, 32));
    }

    private void Save(State s)
    {
        var data = new byte[FileLength];
        Magic.CopyTo(data);
        BinaryPrimitives.WriteUInt32BigEndian(data.AsSpan(8, 4), (uint)s.Failures);
        BinaryPrimitives.WriteInt64BigEndian(data.AsSpan(12, 8), s.LastFailureUnixMs);
        SHA256.HashData(data.AsSpan(0, ContentLength)).CopyTo(data.AsSpan(ContentLength));

        string? dir = Path.GetDirectoryName(_path);
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
        AtomicFile.WriteAllBytes(_path, data);
    }

    private readonly record struct State(int Failures, long LastFailureUnixMs);
}
