using System.Globalization;
using System.Text;
using SecureUSB.Models;

namespace SecureUSB.Security;

/// <summary>
/// Turns arbitrary, possibly hostile names and paths into names that satisfy <see cref="EntryNames"/>.
/// Guarantee (property-tested): the result of <see cref="SanitizeFileName"/> ALWAYS passes
/// <c>EntryNames.IsValidName</c> and contains no path separator; <see cref="SanitizeFolderPath"/> ALWAYS passes
/// <c>EntryNames.IsValidFolderPath</c>. Directory components are dropped ("..\..\x.txt" becomes "x.txt").
/// Use this for names that come from the file system or other programs. For names the USER types
/// (rename) the vault rejects invalid names with a message instead of silently changing them.
/// </summary>
public static class FilenameSanitizer
{
    public const string DefaultFileName = "file";
    public const string DefaultFolderName = "folder";
    private const string Forbidden = "<>:\"/\\|?*";

    public static string SanitizeFileName(string? input, string fallback = DefaultFileName)
    {
        string safeFallback = EntryNames.IsValidName(fallback, out _) ? fallback : DefaultFileName;
        if (string.IsNullOrWhiteSpace(input)) return safeFallback;

        // keep only the last path component
        int cut = input.LastIndexOfAny(new[] { '/', '\\' });
        string s = cut >= 0 ? input[(cut + 1)..] : input;

        var sb = new StringBuilder(s.Length);
        for (int i = 0; i < s.Length; i++)
        {
            char c = s[i];
            if (char.IsHighSurrogate(c) && i + 1 < s.Length && char.IsLowSurrogate(s[i + 1]))
            {
                sb.Append(c).Append(s[++i]);               // valid surrogate pair (e.g. emoji)
                continue;
            }
            if (char.IsSurrogate(c)) { sb.Append('_'); continue; }          // lone surrogate
            if (c < 0x20 || c == 0x7F) { sb.Append('_'); continue; }        // control characters
            if (Forbidden.Contains(c)) { sb.Append('_'); continue; }
            if (char.GetUnicodeCategory(c) == UnicodeCategory.Format) continue;   // invisible / bidi override: remove
            sb.Append(c);
        }

        string name = sb.ToString();
        try { name = name.Normalize(NormalizationForm.FormC); }
        catch (ArgumentException) { /* leave as is */ }

        name = name.TrimStart(' ').TrimEnd(' ', '.');
        name = Truncate(name, EntryNames.MaxNameLength);
        name = name.TrimEnd(' ', '.');

        if (name.Length == 0) return safeFallback;
        if (EntryNames.IsValidName(name, out _)) return name;

        // reserved device names such as "con.txt": prefix an underscore
        string prefixed = Truncate("_" + name, EntryNames.MaxNameLength).TrimEnd(' ', '.');
        return EntryNames.IsValidName(prefixed, out _) ? prefixed : safeFallback;
    }

    /// <summary>"A\B/../C" becomes "A/B/C": separators unified, empty/"."/".." segments dropped, every segment sanitized.</summary>
    public static string SanitizeFolderPath(string? input)
    {
        if (string.IsNullOrWhiteSpace(input)) return "";

        var segments = new List<string>();
        foreach (string raw in input.Split('/', '\\'))
        {
            string trimmed = raw.Trim();
            if (trimmed.Length == 0 || trimmed == "." || trimmed == "..") continue;
            segments.Add(SanitizeFileName(trimmed, DefaultFolderName));
            if (segments.Count == EntryNames.MaxFolderDepth) break;
        }

        while (segments.Count > 0 && string.Join("/", segments).Length > EntryNames.MaxFolderPathLength)
            segments.RemoveAt(segments.Count - 1);

        string path = string.Join("/", segments);
        return EntryNames.IsValidFolderPath(path, out _) ? path : "";
    }

    /// <summary>
    /// Sanitizes <paramref name="fileName"/> and combines it with <paramref name="directory"/>, then proves the result
    /// is a direct child of that directory. Use for every file the application writes to disk.
    /// </summary>
    public static string CombineInsideDirectory(string directory, string? fileName)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(directory);
        string dir = Path.TrimEndingDirectorySeparator(Path.GetFullPath(directory));
        string full = Path.GetFullPath(Path.Combine(dir, SanitizeFileName(fileName)));

        string? parent = Path.GetDirectoryName(full);
        if (parent is null ||
            !string.Equals(Path.TrimEndingDirectorySeparator(parent), dir, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("The file name would leave the target directory.");
        return full;
    }

    private static string Truncate(string name, int maxLength)
    {
        if (name.Length <= maxLength) return name;

        string ext = "";
        int dot = name.LastIndexOf('.');
        if (dot > 0 && name.Length - dot <= 32) ext = name[dot..];

        int keep = maxLength - ext.Length;
        if (keep > 0 && char.IsHighSurrogate(name[keep - 1])) keep--;   // never split a surrogate pair
        return name[..keep] + ext;
    }
}
