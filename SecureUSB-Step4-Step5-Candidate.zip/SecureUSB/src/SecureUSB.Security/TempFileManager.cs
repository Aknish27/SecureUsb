using SecureUSB.Storage;

namespace SecureUSB.Security;

public sealed record CleanupReport(int Deleted, IReadOnlyList<string> Failed)
{
    public static CleanupReport Empty { get; } = new(0, Array.Empty<string>());
    public bool IsComplete => Failed.Count == 0;
}

/// <summary>
/// Owns every decrypted ("plaintext") temporary file the application creates, so nothing is left behind.
///
/// Layout:  {root}\SecureUSB-{random}\            one session directory per running application
///            .secureusb-session                   held open exclusively while the session is alive
///            {random}\original-name.ext           one folder per file keeps the real name for the external program
///
/// * Every file is zero-overwritten and deleted on <see cref="CleanupAll"/> (called on lock, USB removal, exit).
///   CleanupAll wipes EVERYTHING under the session directory, including files other programs created next to the
///   copy (editor backups, autosaves).
/// * A crash or power loss cannot leave files forever: <see cref="SweepStale"/> (run at startup) removes sessions
///   whose owner is gone. A live session is recognised by its held-open marker file, so a second running
///   instance never deletes the first one's files.
/// * Edits made to a temporary copy are NOT saved back into the vault (V1). Export or re-add instead.
///
/// LIMITATIONS: wiping is best-effort. Flash/SSD wear levelling, file-system journals, search indexers, antivirus
/// and backup software may keep copies; a program that still has the file open blocks deletion on Windows (it is
/// reported in <see cref="CleanupReport.Failed"/> and retried by the next sweep). Prefer in-memory preview.
/// Put the root on the host PC's temp folder, not on the USB drive, to avoid extra writes to the flash.
/// </summary>
public sealed class TempFileManager : IDisposable
{
    public const string SessionPrefix = "SecureUSB-";
    public const string MarkerFileName = ".secureusb-session";

    private readonly object _gate = new();
    private readonly string _root;
    private readonly string _sessionDir;
    private readonly HashSet<string> _files = new(StringComparer.OrdinalIgnoreCase);
    private FileStream? _marker;
    private bool _disposed;

    public TempFileManager(string rootDirectory)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(rootDirectory);
        _root = Path.GetFullPath(rootDirectory);
        Directory.CreateDirectory(_root);
        _sessionDir = Path.Combine(_root, SessionPrefix + Guid.NewGuid().ToString("N"));
        EnsureSession();
    }

    public string SessionDirectory => _sessionDir;

    public int ActiveCount
    {
        get { lock (_gate) return _files.Count; }
    }

    /// <summary>
    /// Creates a temporary plaintext file named <paramref name="fileName"/> (sanitized) and fills it using
    /// <paramref name="writePlaintext"/>. If the writer throws, the partial file is wiped and removed.
    /// </summary>
    public string CreateTempFile(string fileName, Action<Stream> writePlaintext)
    {
        ArgumentNullException.ThrowIfNull(writePlaintext);

        string path;
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            EnsureSession();
            string dir = Path.Combine(_sessionDir, Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            path = FilenameSanitizer.CombineInsideDirectory(dir, fileName);
            _files.Add(path);   // registered BEFORE writing: a failure can never lose track of plaintext
        }

        try
        {
            using (var fs = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, FileOptions.SequentialScan))
            {
                writePlaintext(fs);
                fs.Flush();
            }
            try { File.SetAttributes(path, FileAttributes.ReadOnly); } catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }
            return path;
        }
        catch
        {
            RemoveOne(path);
            throw;
        }
    }

    /// <summary>Wipes and deletes every temporary file of this session. Never throws.</summary>
    public CleanupReport CleanupAll()
    {
        lock (_gate)
        {
            CleanupReport report = WipeDirectoryContents(_sessionDir, keepMarker: true);
            if (report.IsComplete) _files.Clear();
            else _files.RemoveWhere(f => !File.Exists(f));
            return report;
        }
    }

    public void Dispose()
    {
        lock (_gate)
        {
            if (_disposed) return;
            _disposed = true;
            WipeDirectoryContents(_sessionDir, keepMarker: true);
            try { _marker?.Dispose(); } catch (IOException) { }
            _marker = null;
            try { Directory.Delete(_sessionDir, recursive: true); } catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }
            _files.Clear();
        }
    }

    /// <summary>
    /// Startup housekeeping: removes session directories left behind by crashed/killed runs.
    /// Only directories named "SecureUSB-{32 hex}" that contain the marker file are touched, never anything else,
    /// and sessions that are still alive (marker held open by another process) are skipped.
    /// </summary>
    public static CleanupReport SweepStale(string rootDirectory)
    {
        int deleted = 0;
        var failed = new List<string>();
        string root = Path.GetFullPath(rootDirectory);
        if (!Directory.Exists(root)) return CleanupReport.Empty;

        foreach (string dir in Directory.EnumerateDirectories(root, SessionPrefix + "*"))
        {
            try
            {
                string name = Path.GetFileName(dir);
                if (name.Length != SessionPrefix.Length + 32 ||
                    !Guid.TryParseExact(name[SessionPrefix.Length..], "N", out _)) continue;
                if ((File.GetAttributes(dir) & FileAttributes.ReparsePoint) != 0) continue;

                string marker = Path.Combine(dir, MarkerFileName);
                if (!File.Exists(marker)) continue;   // not ours

                FileStream probe;
                try
                {
                    probe = new FileStream(marker, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
                }
                catch (IOException)
                {
                    continue;   // held open: a live session of another running instance
                }

                probe.Dispose();
                CleanupReport r = WipeDirectoryContents(dir, keepMarker: false);
                deleted += r.Deleted;
                failed.AddRange(r.Failed);
                try { Directory.Delete(dir, recursive: true); } catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException)
            {
                failed.Add(dir);
            }
        }
        return new CleanupReport(deleted, failed);
    }

    // ------------------------------------------------------------------ internals

    private void EnsureSession()
    {
        Directory.CreateDirectory(_sessionDir);
        if (_marker is null)
        {
            _marker = new FileStream(Path.Combine(_sessionDir, MarkerFileName), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            if (_marker.Length == 0)
            {
                byte[] note = System.Text.Encoding.UTF8.GetBytes("SecureUSB temporary session. Safe to delete when SecureUSB is closed.");
                _marker.Write(note);
                _marker.Flush();
            }
        }
    }

    private void RemoveOne(string path)
    {
        lock (_gate)
        {
            FileWiper.TryWipeAndDelete(path);
            if (!File.Exists(path)) _files.Remove(path);
            string? dir = Path.GetDirectoryName(path);
            if (dir is not null && !string.Equals(dir, _sessionDir, StringComparison.OrdinalIgnoreCase))
            {
                try { Directory.Delete(dir); } catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }
            }
        }
    }

    private static CleanupReport WipeDirectoryContents(string directory, bool keepMarker)
    {
        if (!Directory.Exists(directory)) return CleanupReport.Empty;

        int deleted = 0;
        var failed = new List<string>();
        var options = new EnumerationOptions
        {
            RecurseSubdirectories = true,
            IgnoreInaccessible = true,
            AttributesToSkip = FileAttributes.ReparsePoint   // never follow links out of the session directory
        };

        foreach (string file in Directory.EnumerateFiles(directory, "*", options).ToList())
        {
            if (keepMarker && string.Equals(Path.GetFileName(file), MarkerFileName, StringComparison.OrdinalIgnoreCase)
                && string.Equals(Path.GetDirectoryName(file), directory, StringComparison.OrdinalIgnoreCase))
                continue;

            if (FileWiper.TryWipeAndDelete(file)) deleted++;
            else failed.Add(file);
        }

        // remove the now-empty per-file folders (children first)
        foreach (string sub in Directory.EnumerateDirectories(directory, "*", options).OrderByDescending(d => d.Length).ToList())
        {
            try { Directory.Delete(sub); } catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }
        }
        return new CleanupReport(deleted, failed);
    }
}
