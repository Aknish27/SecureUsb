using System.Globalization;

namespace SecureUSB.Storage;

/// <summary>Human-readable sizes using Windows Explorer's convention (1 KB = 1024 bytes).</summary>
public static class ByteSize
{
    public static string Format(long bytes)
    {
        if (bytes < 0) bytes = 0;
        if (bytes < 1024) return bytes.ToString(CultureInfo.InvariantCulture) + " B";
        string[] units = { "KB", "MB", "GB", "TB", "PB" };
        double value = bytes;
        int unit = -1;
        do
        {
            value /= 1024;
            unit++;
        } while (value >= 1024 && unit < units.Length - 1);
        return value.ToString("0.0", CultureInfo.InvariantCulture) + " " + units[unit];
    }
}

/// <summary>Physical volume facts reported by the operating system (never hard-coded).</summary>
public sealed record DriveCapacity(
    string RootPath,
    string? VolumeLabel,
    string FileSystem,
    DriveType DriveType,
    long TotalBytes,
    long FreeBytes)
{
    public long UsedBytes => Math.Max(0, TotalBytes - FreeBytes);
    public bool IsRemovable => DriveType == DriveType.Removable;

    /// <summary>
    /// FAT/FAT32 cannot hold a single file of 4 GiB or more; many consumer USB sticks ship formatted FAT32.
    /// null = no practical per-file limit.
    /// </summary>
    public long? MaxFileSizeBytes =>
        FileSystem.Equals("FAT32", StringComparison.OrdinalIgnoreCase) ||
        FileSystem.Equals("FAT", StringComparison.OrdinalIgnoreCase) ||
        FileSystem.Equals("vfat", StringComparison.OrdinalIgnoreCase) ||
        FileSystem.Equals("msdos", StringComparison.OrdinalIgnoreCase)
            ? uint.MaxValue
            : null;
}

public interface IDriveInfoService
{
    /// <exception cref="IOException">The drive is missing, not ready, or cannot be queried.</exception>
    DriveCapacity GetCapacity(string path);

    bool IsAvailable(string path);
}

public sealed class SystemDriveInfoService : IDriveInfoService
{
    public DriveCapacity GetCapacity(string path)
    {
        string root;
        DriveInfo drive;
        try
        {
            string full = Path.GetFullPath(path);
            root = Path.GetPathRoot(full) ?? throw new IOException("The path has no drive root.");
            drive = new DriveInfo(root);
            if (!drive.IsReady) throw new IOException($"Drive {root} is not ready (was the USB drive removed?).");
        }
        catch (ArgumentException ex)
        {
            throw new IOException("The path is not on a local drive.", ex);
        }

        string? label = null;
        try { label = drive.VolumeLabel; } catch (Exception e) when (e is IOException or UnauthorizedAccessException or PlatformNotSupportedException) { }

        try
        {
            return new DriveCapacity(root, label, drive.DriveFormat, drive.DriveType, drive.TotalSize, drive.AvailableFreeSpace);
        }
        catch (UnauthorizedAccessException ex)
        {
            throw new IOException("Cannot read drive capacity.", ex);
        }
    }

    public bool IsAvailable(string path)
    {
        try
        {
            GetCapacity(path);
            return true;
        }
        catch (IOException)
        {
            return false;
        }
    }
}
