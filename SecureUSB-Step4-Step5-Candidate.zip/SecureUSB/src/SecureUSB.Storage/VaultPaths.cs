namespace SecureUSB.Storage;

/// <summary>
/// All on-disk locations of one vault:
/// <code>
/// SecureUSB_Data/
///   vault.hdr  vault.hdr.bak  vault.hdr.tmp     header, backup copy, in-flight replacement
///   index.sdb  index.sdb.prev index.sdb.tmp     encrypted index, previous revision, in-flight replacement
///   vault.lock                                  held open while the vault is in use (one process at a time)
///   guard.dat  log.sdb                          reserved for Step 3
///   blobs/ {32 hex}.blob  {32 hex}.blob.tmp     encrypted files (random names), in-flight writes
/// </code>
/// </summary>
public sealed class VaultPaths
{
    public const string DataFolderName = "SecureUSB_Data";
    public const string BlobExtension = ".blob";

    public VaultPaths(string dataDirectory)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(dataDirectory);
        DataDirectory = Path.GetFullPath(dataDirectory);
    }

    public static VaultPaths ForUsbRoot(string usbRoot) => new(Path.Combine(usbRoot, DataFolderName));

    public string DataDirectory { get; }

    public string HeaderPath => Path.Combine(DataDirectory, "vault.hdr");
    public string HeaderBackupPath => HeaderPath + ".bak";
    public string HeaderTempPath => AtomicFile.TempPath(HeaderPath);

    public string IndexPath => Path.Combine(DataDirectory, "index.sdb");
    public string IndexPrevPath => IndexPath + ".prev";
    public string IndexTempPath => AtomicFile.TempPath(IndexPath);

    public string LockPath => Path.Combine(DataDirectory, "vault.lock");
    public string GuardPath => Path.Combine(DataDirectory, "guard.dat");
    public string LogPath => Path.Combine(DataDirectory, "log.sdb");

    public string BlobsDirectory => Path.Combine(DataDirectory, "blobs");
    public string BlobPath(Guid fileId) => Path.Combine(BlobsDirectory, fileId.ToString("N") + BlobExtension);
    public string BlobTempPath(Guid fileId) => BlobPath(fileId) + AtomicFile.TempSuffix;

    public void EnsureDirectories() => Directory.CreateDirectory(BlobsDirectory);

    public bool IsInsideDataDirectory(string path)
    {
        string full = Path.GetFullPath(path);
        string prefix = DataDirectory.EndsWith(Path.DirectorySeparatorChar) ? DataDirectory : DataDirectory + Path.DirectorySeparatorChar;
        return full.StartsWith(prefix, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>Parses "{32 hex}.blob" or "{32 hex}.blob.tmp".</summary>
    public static bool TryParseBlobFileName(string fileName, out Guid fileId, out bool isTemp)
    {
        fileId = default;
        isTemp = false;
        string name = fileName;
        if (name.EndsWith(BlobExtension + AtomicFile.TempSuffix, StringComparison.OrdinalIgnoreCase))
        {
            isTemp = true;
            name = name[..^AtomicFile.TempSuffix.Length];
        }
        if (!name.EndsWith(BlobExtension, StringComparison.OrdinalIgnoreCase)) return false;
        string stem = name[..^BlobExtension.Length];
        return stem.Length == 32 && Guid.TryParseExact(stem, "N", out fileId);
    }
}
