using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text.Json;
using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Storage;

public enum IndexSource { Primary = 0, PendingTemp = 1, Previous = 2 }

public sealed record IndexLoadResult(VaultIndex Index, IndexSource Source, byte[] RawBytes);

/// <summary>
/// The encrypted file index (file names, sizes, dates, folders).
///
/// File layout:  "SUSBIDX1"(8) | revision u64 BE (8) | AES-256-GCM sealed payload (nonce12 | ciphertext | tag16)
///   payload plaintext = length u32 BE | UTF-8 JSON | zero padding up to a multiple of 4096 bytes
///   AAD = "SUSBIDX1" | vaultId(16) | revision(8)
/// Key = HKDF subkey "SecureUSB/v1/index" of the master key. Padding hides the exact number of files
/// (but not the rough size). Explorer shows only this opaque blob.
///
/// Save protocol:  1. write index.sdb.tmp (flushed)   2. move index.sdb -> index.sdb.prev   3. move tmp -> index.sdb
/// Load: decrypt every candidate (primary, tmp, prev) and take the highest authenticated revision, so a crash
/// between any two steps is recoverable. LIMITATION: whole-vault rollback to an older but internally
/// consistent copy cannot be detected.
/// </summary>
public sealed class EncryptedIndexStore
{
    public const int BucketSize = 4096;
    public const long MaxFileBytes = 64L * 1024 * 1024;
    private const int PreambleLength = 16;

    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = false, MaxDepth = 16 };
    private static ReadOnlySpan<byte> Magic => "SUSBIDX1"u8;

    private readonly VaultPaths _paths;

    public EncryptedIndexStore(VaultPaths paths)
    {
        _paths = paths ?? throw new ArgumentNullException(nameof(paths));
    }

    public bool AnyCandidateExists =>
        File.Exists(_paths.IndexPath) || File.Exists(_paths.IndexTempPath) || File.Exists(_paths.IndexPrevPath);

    public void Save(VaultIndex index, VaultKeys keys)
    {
        byte[] file = Encode(index, keys);

        try
        {
            AtomicFile.WriteDurable(_paths.IndexTempPath, file);
        }
        catch
        {
            AtomicFile.TryDelete(_paths.IndexTempPath);   // nothing else has been touched yet
            throw;
        }

        if (File.Exists(_paths.IndexPath))
            AtomicFile.Replace(_paths.IndexPath, _paths.IndexPrevPath);
        AtomicFile.Replace(_paths.IndexTempPath, _paths.IndexPath);
    }

    /// <returns>null if no index file exists at all.</returns>
    /// <exception cref="VaultCorruptException">Index files exist but none authenticates (damaged, or wrong key).</exception>
    public IndexLoadResult? Load(VaultKeys keys)
    {
        var candidates = new (string Path, IndexSource Source)[]
        {
            (_paths.IndexPath, IndexSource.Primary),
            (_paths.IndexTempPath, IndexSource.PendingTemp),
            (_paths.IndexPrevPath, IndexSource.Previous)
        };

        IndexLoadResult? best = null;
        bool anyFile = false;
        foreach (var (path, source) in candidates)
        {
            byte[]? raw = TryReadBounded(path, ref anyFile);
            if (raw is null) continue;
            try
            {
                VaultIndex index = Decode(raw, keys);
                if (best is null || index.Revision > best.Index.Revision)
                    best = new IndexLoadResult(index, source, raw);
            }
            catch (Exception e) when (e is CryptographicException or InvalidVaultFormatException)
            {
                // damaged or foreign candidate: ignore, try the others
            }
        }

        if (best is not null) return best;
        if (!anyFile) return null;
        throw new VaultCorruptException("The encrypted file index is damaged (all copies failed verification), or the key is wrong.");
    }

    /// <summary>Restores the canonical on-disk state after loading from a non-primary copy.</summary>
    public void Heal(IndexLoadResult loaded)
    {
        switch (loaded.Source)
        {
            case IndexSource.Primary:
                AtomicFile.TryDelete(_paths.IndexTempPath);
                break;
            case IndexSource.PendingTemp:
                AtomicFile.Replace(_paths.IndexTempPath, _paths.IndexPath);   // finish the interrupted commit
                break;
            case IndexSource.Previous:
                AtomicFile.WriteAllBytes(_paths.IndexPath, loaded.RawBytes);  // consumes the temp path
                break;
        }
    }

    public byte[] Encode(VaultIndex index, VaultKeys keys)
    {
        ArgumentNullException.ThrowIfNull(index);
        ArgumentNullException.ThrowIfNull(keys);
        if (index.VaultId != keys.VaultId) throw new ArgumentException("Index and keys belong to different vaults.");

        byte[] json = JsonSerializer.SerializeToUtf8Bytes(index, JsonOptions);
        int content = 4 + json.Length;
        int padded = (content + BucketSize - 1) / BucketSize * BucketSize;
        byte[] plain = new byte[padded];
        BinaryPrimitives.WriteUInt32BigEndian(plain, (uint)json.Length);
        json.CopyTo(plain, 4);

        using SecureBytes key = keys.DeriveKey(KeyPurpose.Index);
        byte[] sealedData;
        try
        {
            sealedData = Aead.Seal(key.Span, plain, BuildAad(index.VaultId, index.Revision));
        }
        finally
        {
            CryptographicOperations.ZeroMemory(plain);
            CryptographicOperations.ZeroMemory(json);
        }

        var file = new byte[PreambleLength + sealedData.Length];
        Magic.CopyTo(file);
        BinaryPrimitives.WriteUInt64BigEndian(file.AsSpan(8, 8), (ulong)index.Revision);
        sealedData.CopyTo(file, PreambleLength);
        return file;
    }

    /// <exception cref="CryptographicException">Authentication failed.</exception>
    /// <exception cref="InvalidVaultFormatException">Structurally invalid.</exception>
    public VaultIndex Decode(byte[] file, VaultKeys keys)
    {
        if (file.Length < PreambleLength + Aead.Overhead || !file.AsSpan(0, 8).SequenceEqual(Magic))
            throw new InvalidVaultFormatException("Not a SecureUSB index file.");

        ulong revision = BinaryPrimitives.ReadUInt64BigEndian(file.AsSpan(8, 8));
        if (revision > long.MaxValue) throw new InvalidVaultFormatException("Invalid index revision.");

        using SecureBytes key = keys.DeriveKey(KeyPurpose.Index);
        byte[] plain = Aead.Open(key.Span, file.AsSpan(PreambleLength), BuildAad(keys.VaultId, (long)revision));
        try
        {
            uint length = BinaryPrimitives.ReadUInt32BigEndian(plain);
            if (length > plain.Length - 4) throw new InvalidVaultFormatException("Corrupt index length.");

            VaultIndex? index;
            try
            {
                index = JsonSerializer.Deserialize<VaultIndex>(plain.AsSpan(4, (int)length), JsonOptions);
            }
            catch (JsonException ex)
            {
                throw new InvalidVaultFormatException("Index content is not valid: " + ex.Message);
            }
            if (index is null) throw new InvalidVaultFormatException("Index is empty.");

            index.Validate(keys.VaultId);
            if (index.Revision != (long)revision) throw new InvalidVaultFormatException("Index revision mismatch.");
            return index;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(plain);
        }
    }

    private static byte[] BuildAad(Guid vaultId, long revision)
    {
        var aad = new byte[32];
        Magic.CopyTo(aad);
        vaultId.TryWriteBytes(aad.AsSpan(8, 16));
        BinaryPrimitives.WriteUInt64BigEndian(aad.AsSpan(24, 8), (ulong)revision);
        return aad;
    }

    private static byte[]? TryReadBounded(string path, ref bool anyFile)
    {
        try
        {
            var info = new FileInfo(path);
            if (!info.Exists) return null;
            anyFile = true;
            if (info.Length > MaxFileBytes) return null;
            return File.ReadAllBytes(path);
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            return null;
        }
    }
}
