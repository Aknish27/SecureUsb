namespace SecureUSB.Storage;

/// <summary>
/// Three clearly separated numbers, as required:
/// 1. physical USB capacity (<see cref="Drive"/>), 2. SecureUSB encrypted vault usage, 3. application files.
/// Anything else on the stick (other people's files) is "other". Sizes are logical file bytes;
/// the file system's cluster rounding makes real on-disk use slightly higher.
/// </summary>
public sealed record StorageUsage(DriveCapacity Drive, long VaultBytes, long ApplicationBytes)
{
    public long TotalBytes => Drive.TotalBytes;
    public long FreeBytes => Drive.FreeBytes;
    public long UsedBytes => Drive.UsedBytes;
    public long OtherBytes => Math.Max(0, UsedBytes - VaultBytes - ApplicationBytes);
}

public static class StorageUsageCalculator
{
    /// <param name="applicationPaths">Files/folders that belong to the application (e.g. SecureUSB.exe, SecureUSB_App\).</param>
    public static StorageUsage Calculate(VaultPaths paths, IEnumerable<string> applicationPaths, IDriveInfoService drive)
    {
        DriveCapacity capacity = drive.GetCapacity(paths.DataDirectory);
        long vault = DirectorySize(paths.DataDirectory);

        long app = 0;
        foreach (string p in applicationPaths)
        {
            if (paths.IsInsideDataDirectory(p)) continue;   // never count vault files twice
            if (File.Exists(p)) app += SafeLength(p);
            else if (Directory.Exists(p)) app += DirectorySize(p);
        }
        return new StorageUsage(capacity, vault, app);
    }

    public static long DirectorySize(string directory)
    {
        if (!Directory.Exists(directory)) return 0;
        var options = new EnumerationOptions
        {
            RecurseSubdirectories = true,
            IgnoreInaccessible = true,
            AttributesToSkip = FileAttributes.ReparsePoint
        };
        long total = 0;
        foreach (string file in Directory.EnumerateFiles(directory, "*", options))
            total += SafeLength(file);
        return total;
    }

    private static long SafeLength(string file)
    {
        try { return new FileInfo(file).Length; }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException) { return 0; }
    }
}
