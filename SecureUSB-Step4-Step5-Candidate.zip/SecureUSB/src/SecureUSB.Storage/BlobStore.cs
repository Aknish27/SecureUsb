using System.Buffers.Binary;
using System.Security.Cryptography;
using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Storage;

/// <summary>
/// On-disk container of one encrypted file (blobs/{random id}.blob):
/// <code>
/// "SUSBBLB1"(8) | fileId(16) | wrappedKeyLength u16 BE (2) = 60 | wrapped file key (60) | ChunkedFileCipher stream
/// </code>
/// The wrapped file key (AES-256-GCM under the vault's key-wrapping subkey, bound to vault ID + file ID)
/// lives IN the blob, so every blob is self-describing: if the index is lost, the data can be recovered
/// (without names) by anyone who can unlock the vault.
/// </summary>
public static class BlobFormat
{
    public const int WrappedKeyLength = Aead.Overhead + 32;                   // 60
    public const int HeaderLength = 8 + 16 + 2 + WrappedKeyLength;            // 86
    private const int StreamHeaderLength = 20;                                // see ChunkedFileCipher

    private static ReadOnlySpan<byte> Magic => "SUSBBLB1"u8;
    private static ReadOnlySpan<byte> StreamMagic => "SUSBFIL1"u8;

    public static void WriteHeader(Stream output, Guid fileId, ReadOnlySpan<byte> wrappedKey)
    {
        if (wrappedKey.Length != WrappedKeyLength)
            throw new ArgumentException($"Wrapped key must be {WrappedKeyLength} bytes.", nameof(wrappedKey));

        Span<byte> h = stackalloc byte[HeaderLength];
        Magic.CopyTo(h);
        fileId.TryWriteBytes(h.Slice(8, 16));
        BinaryPrimitives.WriteUInt16BigEndian(h.Slice(24, 2), (ushort)WrappedKeyLength);
        wrappedKey.CopyTo(h.Slice(26, WrappedKeyLength));
        output.Write(h);
    }

    /// <exception cref="DataIntegrityException">Truncated or not a SecureUSB blob.</exception>
    public static byte[] ReadHeader(Stream input, out Guid fileId)
    {
        Span<byte> h = stackalloc byte[HeaderLength];
        if (input.ReadAtLeast(h, HeaderLength, throwOnEndOfStream: false) != HeaderLength)
            throw new DataIntegrityException("Encrypted blob is truncated (header).");
        if (!h.Slice(0, 8).SequenceEqual(Magic))
            throw new DataIntegrityException("Not a SecureUSB encrypted blob.");
        if (BinaryPrimitives.ReadUInt16BigEndian(h.Slice(24, 2)) != WrappedKeyLength)
            throw new DataIntegrityException("Unexpected key length in encrypted blob.");

        fileId = new Guid(h.Slice(8, 16));
        return h.Slice(26, WrappedKeyLength).ToArray();
    }

    /// <summary>
    /// With <paramref name="blob"/> positioned right after the blob header, derives chunk size and plaintext
    /// length from the stream header and the total file length (used when rebuilding a lost index).
    /// </summary>
    public static bool TryGetStreamInfo(Stream blob, long blobLength, out int chunkSize, out long plaintextLength)
    {
        chunkSize = 0;
        plaintextLength = 0;
        long streamLength = blobLength - HeaderLength;
        if (streamLength < StreamHeaderLength + 16) return false;

        Span<byte> sh = stackalloc byte[StreamHeaderLength];
        if (blob.ReadAtLeast(sh, StreamHeaderLength, throwOnEndOfStream: false) != StreamHeaderLength) return false;
        if (!sh.Slice(0, 8).SequenceEqual(StreamMagic)) return false;

        uint cs = BinaryPrimitives.ReadUInt32BigEndian(sh.Slice(8, 4));
        if (cs < VaultIndex.MinChunkSize || cs > VaultIndex.MaxChunkSize) return false;

        long body = streamLength - StreamHeaderLength;
        long perChunk = cs + 16L;
        long chunks = (body + perChunk - 1) / perChunk;
        long plain = body - 16 * chunks;
        if (plain < 0) return false;
        long expectedChunks = plain == 0 ? 1 : (plain + cs - 1) / cs;
        if (expectedChunks != chunks) return false;

        chunkSize = (int)cs;
        plaintextLength = plain;
        return true;
    }

    public static long BlobLength(long plaintextLength, int chunkSize) =>
        HeaderLength + ChunkedFileCipher.CiphertextLength(plaintextLength, chunkSize);
}

public sealed record BlobWriteResult(long PlaintextBytes, long BlobBytes);

public sealed record BlobInfo(Guid FileId, byte[] WrappedKey, int ChunkSize, long PlaintextBytes, long BlobBytes);

/// <summary>
/// Reads and writes encrypted blobs. Write protocol: encrypt to blobs/{id}.blob.tmp -> flush to device ->
/// (caller) <see cref="CommitTemp"/> renames it to blobs/{id}.blob -> only then does the index list it.
/// A crash or USB removal at any point leaves at worst an unreferenced blob/tmp that the integrity scanner finds.
/// </summary>
public sealed class BlobStore
{
    /// <summary>Space kept free for index/header rewrites on top of the blob itself.</summary>
    public const long ReserveBytes = 8L * 1024 * 1024;

    private readonly VaultPaths _paths;
    private readonly IDriveInfoService? _drive;

    public BlobStore(VaultPaths paths, IDriveInfoService? drive = null)
    {
        _paths = paths ?? throw new ArgumentNullException(nameof(paths));
        _drive = drive;
    }

    /// <summary>Encrypts <paramref name="plaintext"/> into the temp blob. On any failure the temp file is removed.</summary>
    public BlobWriteResult WriteTemp(Guid fileId, Stream plaintext, VaultKeys keys, int chunkSize, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(plaintext);
        ArgumentNullException.ThrowIfNull(keys);
        Preflight(plaintext, chunkSize);
        _paths.EnsureDirectories();

        string tmp = _paths.BlobTempPath(fileId);
        using SecureBytes fileKey = keys.GenerateFileKey();
        byte[] wrapped = keys.WrapFileKey(fileKey.Span, fileId);
        try
        {
            using var fs = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, FileOptions.SequentialScan);
            BlobFormat.WriteHeader(fs, fileId, wrapped);
            long written = ChunkedFileCipher.Encrypt(plaintext, fs, fileKey.Span, new FileBinding(keys.VaultId, fileId), chunkSize, ct);
            fs.Flush(flushToDisk: true);
            return new BlobWriteResult(written, fs.Length);
        }
        catch
        {
            AtomicFile.TryDelete(tmp);
            throw;
        }
    }

    public void CommitTemp(Guid fileId) => File.Move(_paths.BlobTempPath(fileId), _paths.BlobPath(fileId));

    public bool DiscardTemp(Guid fileId) => AtomicFile.TryDelete(_paths.BlobTempPath(fileId));

    /// <returns>true if the blob no longer exists.</returns>
    public bool TryDelete(Guid fileId) => AtomicFile.TryDelete(_paths.BlobPath(fileId));

    public bool Exists(Guid fileId) => File.Exists(_paths.BlobPath(fileId));

    public long? GetLength(Guid fileId)
    {
        var info = new FileInfo(_paths.BlobPath(fileId));
        return info.Exists ? info.Length : null;
    }

    /// <summary>
    /// Authenticates and decrypts into <paramref name="output"/>. On ANY exception the caller must discard
    /// whatever was already written (earlier chunks may have been emitted before a later chunk failed).
    /// </summary>
    /// <exception cref="DataIntegrityException">Tampered, truncated, wrong key/vault, or swapped blob.</exception>
    public long Read(FileEntry entry, VaultKeys keys, Stream output, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entry);
        ArgumentNullException.ThrowIfNull(keys);
        ArgumentNullException.ThrowIfNull(output);

        using var fs = new FileStream(_paths.BlobPath(entry.Id), FileMode.Open, FileAccess.Read, FileShare.Read, 81920, FileOptions.SequentialScan);
        byte[] wrapped = BlobFormat.ReadHeader(fs, out Guid idInBlob);
        if (idInBlob != entry.Id)
            throw new DataIntegrityException("This blob belongs to a different file entry.");

        SecureBytes fileKey;
        try
        {
            fileKey = keys.UnwrapFileKey(wrapped, entry.Id);
        }
        catch (CryptographicException ex)
        {
            throw new DataIntegrityException("The file key failed verification (damaged blob or wrong vault).", ex);
        }

        using (fileKey)
        {
            long n = ChunkedFileCipher.Decrypt(fs, output, fileKey.Span, new FileBinding(keys.VaultId, entry.Id), ct);
            if (n != entry.SizeBytes)
                throw new DataIntegrityException("Decrypted size does not match the index.");
            return n;
        }
    }

    /// <summary>Full authentication of every chunk without keeping any plaintext.</summary>
    public void Verify(FileEntry entry, VaultKeys keys, CancellationToken ct = default) =>
        Read(entry, keys, Stream.Null, ct);

    /// <returns>null if the blob is missing or structurally invalid.</returns>
    public BlobInfo? ReadInfo(Guid fileId)
    {
        try
        {
            using var fs = new FileStream(_paths.BlobPath(fileId), FileMode.Open, FileAccess.Read, FileShare.Read);
            long length = fs.Length;
            byte[] wrapped = BlobFormat.ReadHeader(fs, out Guid idInBlob);
            if (idInBlob != fileId) return null;
            if (!BlobFormat.TryGetStreamInfo(fs, length, out int chunkSize, out long plain)) return null;
            return new BlobInfo(idInBlob, wrapped, chunkSize, plain, length);
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or CryptographicException)
        {
            return null;
        }
    }

    public IEnumerable<Guid> EnumerateBlobIds()
    {
        if (!Directory.Exists(_paths.BlobsDirectory)) yield break;
        foreach (string file in Directory.EnumerateFiles(_paths.BlobsDirectory))
        {
            if (VaultPaths.TryParseBlobFileName(Path.GetFileName(file), out Guid id, out bool isTemp) && !isTemp)
                yield return id;
        }
    }

    private void Preflight(Stream plaintext, int chunkSize)
    {
        if (_drive is null || !plaintext.CanSeek) return;
        long remaining = Math.Max(0, plaintext.Length - plaintext.Position);
        long blobBytes = BlobFormat.BlobLength(remaining, chunkSize);

        DriveCapacity cap = _drive.GetCapacity(_paths.DataDirectory);
        if (cap.MaxFileSizeBytes is long max && blobBytes > max)
            throw new FileTooLargeException(remaining, max, cap.FileSystem);
        if (blobBytes + ReserveBytes > cap.FreeBytes)
            throw new InsufficientSpaceException(blobBytes + ReserveBytes, cap.FreeBytes);
    }
}
