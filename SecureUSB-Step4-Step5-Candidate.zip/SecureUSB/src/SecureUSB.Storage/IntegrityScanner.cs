using System.Security.Cryptography;
using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Storage;

public enum IssueSeverity { Info = 0, Warning = 1, Error = 2 }

public enum IssueKind
{
    HeaderPrimaryDamaged,
    HeaderBackupMissing,
    HeaderBackupOutOfSync,
    HeaderTempLeftover,
    IndexTempLeftover,
    BlobMissing,
    BlobSizeMismatch,
    BlobUnreadable,
    BlobAuthenticationFailed,
    OrphanBlob,
    StaleBlobTemp,
    UnexpectedFile
}

public sealed record IntegrityIssue(IssueKind Kind, IssueSeverity Severity, string Message, Guid? FileId = null, string? Path = null);

public sealed record IntegrityProgress(int Done, int Total);

public sealed class IntegrityReport
{
    public IntegrityReport(IReadOnlyList<IntegrityIssue> issues, int filesChecked, bool deepVerified)
    {
        Issues = issues;
        FilesChecked = filesChecked;
        DeepVerified = deepVerified;
    }

    public IReadOnlyList<IntegrityIssue> Issues { get; }
    public int FilesChecked { get; }
    /// <summary>true if every blob was fully decrypted/authenticated; false = only existence and size were checked.</summary>
    public bool DeepVerified { get; }
    public bool IsClean => Issues.Count == 0;
    public bool HasErrors => Issues.Any(i => i.Severity == IssueSeverity.Error);
    public IEnumerable<IntegrityIssue> OfKind(IssueKind kind) => Issues.Where(i => i.Kind == kind);
}

/// <summary>
/// Read-only consistency check of header, index leftovers and blobs. Shallow = existence + exact size (fast,
/// no key needed). Deep (pass keys) = authenticate every chunk of every file (slow, detects bit rot and tampering).
/// Repair is a separate, explicit step (<see cref="VaultRepository.Repair"/>).
/// </summary>
public static class IntegrityScanner
{
    public static IntegrityReport Scan(
        VaultPaths paths,
        BlobStore blobs,
        IReadOnlyList<FileEntry> entries,
        VaultKeys? deepKeys = null,
        IProgress<IntegrityProgress>? progress = null,
        CancellationToken ct = default)
    {
        var issues = new List<IntegrityIssue>();

        // ---- header ----
        HeaderState header = new VaultHeaderStore(paths).Inspect();
        if (!header.PrimaryValid)
            issues.Add(new(IssueKind.HeaderPrimaryDamaged, IssueSeverity.Error,
                header.BackupValid ? "The vault header is damaged; a backup copy is available." : "The vault header is damaged and no valid backup exists.",
                Path: paths.HeaderPath));
        if (!header.BackupValid)
            issues.Add(new(IssueKind.HeaderBackupMissing, IssueSeverity.Warning, "The backup vault header is missing or damaged.", Path: paths.HeaderBackupPath));
        else if (header.PrimaryValid && !header.InSync)
            issues.Add(new(IssueKind.HeaderBackupOutOfSync, IssueSeverity.Warning, "The backup vault header differs from the primary header.", Path: paths.HeaderBackupPath));
        if (header.TempPresent)
            issues.Add(new(IssueKind.HeaderTempLeftover, IssueSeverity.Info, "A leftover temporary header file from an interrupted write was found.", Path: paths.HeaderTempPath));

        if (File.Exists(paths.IndexTempPath))
            issues.Add(new(IssueKind.IndexTempLeftover, IssueSeverity.Info, "A leftover temporary index file from an interrupted write was found.", Path: paths.IndexTempPath));

        // ---- indexed files ----
        int done = 0;
        foreach (FileEntry entry in entries)
        {
            ct.ThrowIfCancellationRequested();
            string blobPath = paths.BlobPath(entry.Id);
            long? length = blobs.GetLength(entry.Id);

            if (length is null)
            {
                issues.Add(new(IssueKind.BlobMissing, IssueSeverity.Error, $"The encrypted data for '{entry.FullPath}' is missing.", entry.Id, blobPath));
            }
            else if (length.Value != BlobFormat.BlobLength(entry.SizeBytes, entry.ChunkSize))
            {
                issues.Add(new(IssueKind.BlobSizeMismatch, IssueSeverity.Error, $"The encrypted data for '{entry.FullPath}' has the wrong size (truncated or extended).", entry.Id, blobPath));
            }
            else if (deepKeys is not null)
            {
                try
                {
                    blobs.Verify(entry, deepKeys, ct);
                }
                catch (CryptographicException)
                {
                    issues.Add(new(IssueKind.BlobAuthenticationFailed, IssueSeverity.Error, $"'{entry.FullPath}' failed cryptographic verification (corrupted or tampered).", entry.Id, blobPath));
                }
                catch (Exception e) when (e is IOException or UnauthorizedAccessException)
                {
                    issues.Add(new(IssueKind.BlobUnreadable, IssueSeverity.Error, $"'{entry.FullPath}' could not be read: {e.Message}", entry.Id, blobPath));
                }
            }

            progress?.Report(new IntegrityProgress(++done, entries.Count));
        }

        // ---- files in blobs/ that the index does not know ----
        if (Directory.Exists(paths.BlobsDirectory))
        {
            var known = new HashSet<Guid>(entries.Select(e => e.Id));
            foreach (string file in Directory.EnumerateFiles(paths.BlobsDirectory))
            {
                string name = Path.GetFileName(file);
                if (!VaultPaths.TryParseBlobFileName(name, out Guid id, out bool isTemp))
                    issues.Add(new(IssueKind.UnexpectedFile, IssueSeverity.Warning, $"Unexpected file in the vault: {name}", Path: file));
                else if (isTemp)
                    issues.Add(new(IssueKind.StaleBlobTemp, IssueSeverity.Warning, $"An unfinished encrypted write was found ({name}).", id, file));
                else if (!known.Contains(id))
                    issues.Add(new(IssueKind.OrphanBlob, IssueSeverity.Warning, $"Encrypted data exists that is not listed in the index ({name}).", id, file));
            }
        }

        return new IntegrityReport(issues, entries.Count, deepKeys is not null);
    }
}
