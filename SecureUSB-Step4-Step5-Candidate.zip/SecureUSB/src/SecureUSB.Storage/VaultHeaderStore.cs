using SecureUSB.Models;

namespace SecureUSB.Storage;

public enum HeaderSource { Primary = 0, PendingTemp = 1, Backup = 2 }

public sealed record HeaderLoadResult(VaultHeader Header, HeaderSource Source);

public sealed record HeaderState(bool PrimaryValid, bool BackupValid, bool TempPresent, bool InSync);

/// <summary>
/// Persists vault.hdr with a backup copy.
///
/// Update protocol (password change):
///   1. write vault.hdr.tmp, flush, read back and compare
///   2. move vault.hdr.tmp over vault.hdr
///   3. rewrite vault.hdr.bak with the same bytes
///
/// Load order: the first STRUCTURALLY valid copy of primary, tmp, backup. We deliberately do NOT fall back
/// to another copy just because unlocking failed: after a password change the old header must stop working.
/// Bit-rot inside the wrapped key is indistinguishable from a wrong password, so the UI offers an explicit
/// "recover from backup header" action that uses <see cref="TryReadBackup"/>.
/// After a successful unlock call <see cref="Heal"/> to make primary and backup identical again.
/// </summary>
public sealed class VaultHeaderStore
{
    private readonly VaultPaths _paths;

    public VaultHeaderStore(VaultPaths paths)
    {
        _paths = paths ?? throw new ArgumentNullException(nameof(paths));
    }

    public bool Exists =>
        File.Exists(_paths.HeaderPath) || File.Exists(_paths.HeaderTempPath) || File.Exists(_paths.HeaderBackupPath);

    /// <summary>First-time creation. Backup first, primary last (primary's existence marks "initialised").</summary>
    public void Create(VaultHeader header)
    {
        ArgumentNullException.ThrowIfNull(header);
        if (File.Exists(_paths.HeaderPath))
            throw new InvalidOperationException("A vault header already exists here.");

        _paths.EnsureDirectories();
        byte[] bytes = header.ToBytes();
        AtomicFile.WriteAllBytes(_paths.HeaderBackupPath, bytes);
        AtomicFile.WriteAllBytes(_paths.HeaderPath, bytes);
    }

    /// <summary>Replaces the header (e.g. after VaultKeyManager.ChangePassword). Crash-safe.</summary>
    public void Commit(VaultHeader header)
    {
        ArgumentNullException.ThrowIfNull(header);
        byte[] bytes = header.ToBytes();

        try
        {
            AtomicFile.WriteDurable(_paths.HeaderTempPath, bytes);
            if (!File.ReadAllBytes(_paths.HeaderTempPath).AsSpan().SequenceEqual(bytes))
                throw new IOException("Header verification failed after writing (device error?).");
        }
        catch
        {
            AtomicFile.TryDelete(_paths.HeaderTempPath);
            throw;
        }

        AtomicFile.Replace(_paths.HeaderTempPath, _paths.HeaderPath);
        AtomicFile.WriteAllBytes(_paths.HeaderBackupPath, bytes);
    }

    /// <exception cref="VaultCorruptException">No structurally valid header copy exists.</exception>
    public HeaderLoadResult Load()
    {
        VaultHeader? h = TryRead(_paths.HeaderPath);
        if (h is not null) return new HeaderLoadResult(h, HeaderSource.Primary);

        h = TryRead(_paths.HeaderTempPath);
        if (h is not null) return new HeaderLoadResult(h, HeaderSource.PendingTemp);

        h = TryRead(_paths.HeaderBackupPath);
        if (h is not null) return new HeaderLoadResult(h, HeaderSource.Backup);

        throw new VaultCorruptException("No readable vault header was found. The vault cannot be opened.");
    }

    /// <summary>Explicit recovery path: the backup copy, if it is structurally valid.</summary>
    public VaultHeader? TryReadBackup() => TryRead(_paths.HeaderBackupPath);

    /// <summary>
    /// Makes primary and backup byte-identical to <paramref name="authoritative"/> (the header that just
    /// unlocked the vault) and removes a leftover temp file. Call only after a successful unlock.
    /// </summary>
    public void Heal(VaultHeader authoritative)
    {
        ArgumentNullException.ThrowIfNull(authoritative);
        byte[] bytes = authoritative.ToBytes();

        if (!FileEquals(_paths.HeaderPath, bytes)) AtomicFile.WriteAllBytes(_paths.HeaderPath, bytes);
        if (!FileEquals(_paths.HeaderBackupPath, bytes)) AtomicFile.WriteAllBytes(_paths.HeaderBackupPath, bytes);
        AtomicFile.TryDelete(_paths.HeaderTempPath);
    }

    public HeaderState Inspect()
    {
        VaultHeader? primary = TryRead(_paths.HeaderPath);
        VaultHeader? backup = TryRead(_paths.HeaderBackupPath);
        bool inSync = primary is not null && backup is not null && primary.ToBytes().AsSpan().SequenceEqual(backup.ToBytes());
        return new HeaderState(primary is not null, backup is not null, File.Exists(_paths.HeaderTempPath), inSync);
    }

    private static VaultHeader? TryRead(string path)
    {
        try
        {
            var info = new FileInfo(path);
            if (!info.Exists || info.Length != VaultHeader.TotalLength) return null;   // never read huge/foreign files
            return VaultHeader.Parse(File.ReadAllBytes(path));
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or InvalidVaultFormatException)
        {
            return null;
        }
    }

    private static bool FileEquals(string path, byte[] expected)
    {
        try
        {
            var info = new FileInfo(path);
            return info.Exists && info.Length == expected.Length && File.ReadAllBytes(path).AsSpan().SequenceEqual(expected);
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            return false;
        }
    }
}
