namespace SecureUSB.Models;

/// <summary>
/// Thrown when vault metadata is structurally invalid (wrong size, bad magic,
/// unsupported version, out-of-range KDF parameters). This is a parsing error,
/// not an authentication result.
/// </summary>
public sealed class InvalidVaultFormatException : Exception
{
    public InvalidVaultFormatException(string message) : base(message) { }
}
