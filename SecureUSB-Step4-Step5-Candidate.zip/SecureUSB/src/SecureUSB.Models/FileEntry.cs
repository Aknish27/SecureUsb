using System.Text.Json.Serialization;

namespace SecureUSB.Models;

/// <summary>
/// One protected file. Lives ONLY inside the encrypted index. The per-file key is NOT stored here: it is
/// wrapped inside the file's own blob, so the data stays recoverable if the index is lost.
/// </summary>
public sealed record FileEntry
{
    public Guid Id { get; init; }
    public string Name { get; init; } = "";
    /// <summary>Virtual folder inside the vault ("" = root, otherwise "A/B/C").</summary>
    public string FolderPath { get; init; } = "";
    public long SizeBytes { get; init; }
    public int ChunkSize { get; init; }
    public DateTimeOffset AddedUtc { get; init; }
    public DateTimeOffset ModifiedUtc { get; init; }

    [JsonIgnore]
    public string Extension
    {
        get
        {
            int i = Name.LastIndexOf('.');
            return i > 0 ? Name[i..].ToLowerInvariant() : "";
        }
    }

    [JsonIgnore]
    public string FullPath => FolderPath.Length == 0 ? Name : FolderPath + "/" + Name;
}
