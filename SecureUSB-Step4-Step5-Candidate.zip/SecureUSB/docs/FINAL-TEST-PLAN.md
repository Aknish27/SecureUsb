# SecureUSB Final Test Plan

## Release gate
Do not distribute a release candidate until the build succeeds, all expected automated tests pass, the published app launches on a clean supported Windows machine, and the manual USB scenarios below are completed. Do not weaken assertions or reduce expected test counts to obtain a pass.

## Automated checks
Run from the extracted project root on Windows with the .NET 8 SDK installed:

```bat
build-and-test.cmd
```

Expected test counts in the current project:

| Project | Expected |
|---|---:|
| SecureUSB.Cryptography.Tests | 71 |
| SecureUSB.Security.Tests | 105 |
| SecureUSB.Storage.Tests | 176 |
| SecureUSB.Core.Tests | 75 |
| SecureUSB.ViewModels.Tests | 188 |
| SecureUSB.UI.Tests | 33 |
| **Total** | **648** |

The script also checks named security-critical tests. A nonzero exit code means verification failed. Warnings are not automatically failures, but investigate new warnings. The WPF suite requires Windows.

## Publish check
After the automated suite passes, run:

```bat
publish-and-package.cmd
```

Confirm the release ZIP is created. Extract it to a different folder and launch `SecureUSB.exe` on a clean Windows 10/11 x64 machine without relying on the SDK or development output folders. Record Windows version, CPU architecture, package SHA-256, launch result, and any Windows security warnings.

## Manual functional scenarios
Use a spare USB drive and disposable files only. Record Pass/Fail, environment, steps, and evidence for each scenario.

1. First launch with no vault: welcome/create flow appears without an unhandled exception.
2. Create vault with weak password: creation is rejected and no usable vault is created.
3. Create vault with a strong password and confirm no-recovery acknowledgement: vault is created and dashboard opens.
4. Close and reopen app; unlock with correct password: expected files and names appear.
5. Wrong password: unlock is rejected without revealing sensitive details; cooldown appears after repeated failures and persists across app restart.
6. Import sample text, image, and binary files; lock and unlock; compare exported copies with original hashes.
7. Rename/delete: dangerous names are rejected, delete requires confirmation, and cancellation does not delete the entry.
8. Export: existing destination files are not overwritten; UI warns that exported copies are plaintext.
9. Preview supported text/image content; confirm no unintended plaintext file is created.
10. If external-application opening is enabled, verify the warning, temporary copy lifecycle, and cleanup behavior; keep this disabled by default.
11. Idle lock and manual lock: dashboard data is cleared and the vault returns to the locked state.
12. USB removal during idle: app locks and warns; removal during an operation aborts safely without corrupting the vault.
13. Health checks: a healthy vault reports clean; on a disposable copy, test corruption detection/recovery and verify repair does not touch files outside the vault.
14. Fill the drive close to capacity and test a safe refusal; separately test a FAT32 drive's single-file size limitation using a suitable disposable setup.
15. Eject safely after locking, reconnect, and unlock again.
16. Restart Windows and confirm the vault can be opened with the password.

## Security / negative scenarios
- Inspect a copy of the vault with a hex/text viewer: names and contents should not be readable in stored encrypted blobs/index.
- On a disposable vault copy, flip bytes, truncate a blob, and swap blobs between entries; the app should reject tampering rather than return corrupted plaintext.
- Interrupt an operation on a disposable drive; verify recovery/cleanup behavior and that the original remains usable where designed.
- Confirm no password, master key, plaintext content, or sensitive path is written to application logs or safe error messages.
- Verify no test modifies the only copy of important data.

## Evidence to retain
- Full build-and-test output and TRX files from `TestResults`.
- Published package hash (`certutil -hashfile <file> SHA256`).
- Windows version/build, CPU architecture, drive filesystem, and test date.
- Pass/Fail notes and sanitized screenshots/logs; never include passwords or private file contents.
