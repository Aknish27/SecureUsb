# Step 3 — Core and Security design (V1: one password, no key file)

## The user's path
`USB -> SecureUSB.exe -> ONE password -> Unlock`. Everything the UI will do goes through `VaultService`.
```
NotInitialized --CreateVault--> Unlocked --Lock / USB removed / exit--> Locked --Unlock--> Unlocked
```
Dependencies: `Core -> Security -> Storage -> Cryptography -> Models`. No cryptography in Core: it calls the verified Step 1/2 APIs.

## Failed attempts and delays (`AttemptGuard`, guard.dat)
| Consecutive failures | Delay before the next attempt |
|---|---|
| 1-2 | none (typing mistakes) |
| 3 / 4 / 5 / 6 | 5 s / 15 s / 30 s / 1 min |
| 7 / 8 / 9 and more | 5 min / 15 min / 30 min (cap) |

* Attempts made during a delay are refused **without checking the password** and are not counted (so the right password is also refused until the delay ends).
* The counter survives closing the application. A success clears it.
* Clock moved backwards: the full delay applies. A damaged or edited `guard.dat` is treated as 5 failures, never as zero.
* There is deliberately **no auto-wipe** after N failures: that would let anyone destroy your data by typing wrong passwords.
* **Honest limits:** the file must be readable before any key exists, so it cannot be secret or tamper-proof. Anyone with write access to the USB can delete it or move the PC clock forward, and an attacker who copies the vault and attacks it offline never uses this code. The delays slow down someone typing into the application; **Argon2id and password strength are the real defence** (this is why weak passwords are refused at creation and change).
* Failures cannot be written to the encrypted log when they happen (no key yet). The next successful unlock records "N failed unlock attempt(s) since the last successful unlock".

## Names and paths (`FilenameSanitizer`)
Names that come from the file system are sanitized: directory parts dropped, forbidden/control/invisible (bidi) characters removed or replaced, trailing dots/spaces removed, Unicode normalised, reserved device names prefixed, length limited without splitting characters. A property test feeds 4000 random hostile strings and requires every result to pass `EntryNames`. `CombineInsideDirectory` proves a written file is a direct child of its folder. Names the **user types** (rename) are validated and rejected with a reason instead of being silently changed. The vault's own files, and any folder that contains the vault (for example the USB root), cannot be added; exports into the vault's data folder are refused.

## Temporary decrypted files (`TempFileManager`)
* Prefer in-memory preview (`ReadFileForPreview`): no plaintext touches the disk.
* "Open in another program" uses a per-run session folder (put it under the host PC's temp folder, not on the USB). Files keep their real name, are read-only, and are zero-overwritten and deleted on **lock, USB removal, exit**, and on demand. Everything under the session folder is wiped, including editor autosaves next to the copy.
* A crash cannot leave them forever: the next start sweeps abandoned sessions. A live session is recognised by its held-open marker file, so a second running instance never deletes the first one's files; only folders named `SecureUSB-{32 hex}` with the marker are touched.
* If another program still has the copy open (Windows), it cannot be deleted: the lock event reports it (`TempCleanup.IsComplete == false`) so the UI can warn, and the next cleanup/sweep retries.
* **Edits to a temporary copy are not saved back** (V1). Export or re-add instead.
* **Limits:** wiping is best-effort (flash wear levelling, journals, search indexers, antivirus, backup tools may keep copies). Permissions are the host user's.

## Encrypted activity log (`ActivityLog`, log.sdb)
Append-only AES-256-GCM records (subkey of the master key); each record authenticates its number, so modified, removed, reordered or duplicated records are detected. A half-written last record after a power cut is detected and trimmed; a log that fails verification is kept as `log.sdb.damaged` and a new log starts. The log is compacted when it grows past 1 MiB. **Limits:** deleting the file or cutting records off its end cannot be detected; it is evidence for the owner, not a tamper-proof audit trail.

## USB removal (`UsbMonitor` + `VaultService`)
Polled every 500 ms (plus `CheckUsbNow()` for a device-change notification). The drive counts as present only if the volume is ready, the vault folder exists and **this vault's `vault.lock` still exists** (so a different stick under the same drive letter also counts as removal). On removal the service, in this order:
1. refuses all new operations, cancels running ones;
2. wipes temporary plaintext from the PC (and again after running operations stopped, for stragglers);
3. skips logging (the drive is gone), then disposes the storage engine and **zeroes all keys**;
4. raises `Locked(UsbRemoved)`; the next unlock records the removal in the log.

Storage's write ordering already guarantees the vault is consistent afterwards; interrupted imports leave recoverable orphan files (shown as warnings, recoverable by the repair option), never corruption.

## Change password (`ChangePassword`)
Validate the new password (policy, confirmation, different from the old one) -> verify the current password (counts toward the delays) -> build the new header -> **prove the new header opens with the new password and yields the same master key** -> atomic header replace, backup rewritten last. Files are not re-encrypted. Any failure leaves the old password working. **Limit:** the same master key is kept, so someone who copied the drive earlier and knows the old password can still open that copy; a master-key rotation (re-encrypt everything) is not in V1.

## Recovery paths exposed to the UI
`UnlockStatus.WrongPasswordOrDamagedVault` with `BackupHeaderAvailable` -> `UnlockUsingBackupHeader`; `IndexDamaged` -> `RebuildIndexAndUnlock`; `VaultInUse`; `UsbUnavailable`; `LockedOut` (with `RetryAfter`).

## Not in Step 3
WPF UI, launcher, publishing, auto-lock after inactivity, saving edits of temporary copies back into the vault, master-key rotation, organization key (future enterprise feature only).
