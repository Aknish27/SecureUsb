# SecureUSB Threat Model (V1 Release Candidate)

## Scope and security goals
SecureUSB aims to protect files stored inside its vault on a removable drive when that drive is disconnected or the vault is locked. The design uses a password-derived key to protect a random master key, authenticated encryption for file data, encrypted metadata, integrity checks, and managed temporary-file cleanup.

## Assets
- Plaintext file contents and file names before import or after export.
- Vault master key, per-file keys, password-derived wrapping key, and password input.
- Encrypted vault header, index, file blobs, backups, and activity records.
- Temporary decrypted files created for supported external-application workflows.

## Adversaries and threats considered
- Someone obtains the USB drive while the vault is locked and attempts to read or modify its contents.
- An attacker alters, truncates, reorders, or swaps encrypted data and metadata.
- A write is interrupted, the USB is removed, or the process crashes during a storage operation.
- Someone repeatedly guesses passwords using the application.
- Unsafe names or paths attempt to escape the vault or temporary directory.

## Intended controls
- Argon2id password-based key derivation and a wrapped random master key.
- AES-256-GCM authenticated encryption; authentication failure should reject modified ciphertext.
- Per-file keys and chunked encryption, with chunk context authenticated.
- Encrypted index/blob storage and atomic-write/recovery mechanisms.
- Password policy, progressive attempt delays/cooldown, filename/path sanitization, and managed temporary-file cleanup.
- Locking on user action, application close, idle timeout, and USB-removal detection as implemented.
- Safe user-facing error messages that avoid exposing internal paths or file names.

## Out of scope / not guaranteed
- A compromised host OS, kernel, firmware, malicious administrator, keylogger, screen recorder, or malware running as the user. Such an attacker may capture the password or plaintext while the vault is unlocked.
- Physical coercion, shoulder surfing, password reuse, weak user-selected passwords, or offline password cracking against a copied vault. KDF cost increases the cost of guessing but does not make weak passwords safe.
- Secure erasure from SSDs, copy-on-write filesystems, paging files, hibernation files, crash dumps, Windows search/indexing, cloud-sync tools, backup products, antivirus/EDR products, or external applications. File wiping is best effort and cannot guarantee physical erasure.
- Plaintext intentionally exported or opened in another application. Once outside the vault, other software may retain copies.
- Availability against loss, theft, physical damage, filesystem failure, USB controller failure, or ransomware. SecureUSB is not a backup system.
- Password recovery. V1 intentionally has no recovery key or organization key; a lost password can make data unrecoverable.
- Cross-platform execution. The UI is WPF and targets Windows.

## Trust boundaries
1. **User input to app:** password and file paths must be validated; secrets should not be logged.
2. **App to removable drive:** treat drive content as untrusted and validate formats/integrity before use.
3. **App to host filesystem:** any exported or externally opened plaintext leaves the encrypted-vault boundary.
4. **App to Windows and other processes:** Windows security, process isolation, memory handling, and endpoint configuration are assumed trustworthy.

## Residual risks and release gates
- Run the complete automated suite on Windows and verify all expected tests pass.
- Perform manual tests with a disposable USB, including safe eject, forced removal, crashes/interrupted operations, wrong-password cooldown, tampering, and low disk space.
- Inspect the final self-contained package on a clean Windows 10/11 x64 machine.
- Review password/KDF parameters, key lifetime, temporary-file handling, error handling, and recovery paths before production use.
- Obtain independent security review before describing the product as audited, certified, or suitable for high-assurance secrets.
