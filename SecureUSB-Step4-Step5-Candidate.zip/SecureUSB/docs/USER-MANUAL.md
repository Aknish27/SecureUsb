# SecureUSB User Manual (Release Candidate)

## What SecureUSB does
SecureUSB is a Windows desktop application designed to store files inside an encrypted vault on a removable drive. The intended V1 workflow is: select a USB/removable location, create or unlock the vault with one password, then manage files from the dashboard. File names and file contents are intended to remain encrypted in the vault.

## Before you begin
- Use a Windows 10/11 x64 computer. The release package is intended to be self-contained; a separate .NET runtime should not be needed.
- Keep a separate backup of important original files. Encryption is not a backup.
- Choose a strong, unique password and store it somewhere safe. **There is no password recovery or recovery key.** Losing the password may mean permanent loss of access.
- Do not test with your only copy of important data. First use disposable sample files and a spare USB drive.
- Do not remove the USB while an import, export, delete, rename, or integrity operation is in progress.

## Start the application
1. Extract `SecureUSB-v1.0.0-win-x64.zip` to a folder on your Windows PC.
2. Read `README-FIRST.txt` and this manual.
3. Double-click `SecureUSB.exe`. If Windows SmartScreen shows a warning because the app is unsigned, do not bypass it unless you built the package yourself and verified its source and hash.
4. Connect the intended removable drive and select the location offered by the app.

## Create a vault
1. Select the USB/removable location shown by SecureUSB.
2. Choose the create-vault option.
3. Enter a strong password and confirm it as requested.
4. Read and acknowledge the no-recovery warning.
5. Wait for creation to finish before disconnecting the drive.

## Unlock and lock
- Open SecureUSB and select the existing vault location.
- Enter the same password used when the vault was created. The product uses a single-password flow; there is no organization key or separate key file in V1.
- Use the Lock control when you finish. The application is designed to clear active vault state and clean its managed temporary files when locking.
- Repeated incorrect attempts trigger a cooldown. Wait for it to expire rather than repeatedly retrying.
- Removing the USB is intended to trigger locking. Still use the Lock control before safely ejecting whenever possible.

## Manage files
The dashboard provides the file operations implemented in this build, such as adding files, organizing entries, renaming/deleting entries, previewing supported content, and exporting a copy. Read each confirmation dialog before continuing.

**Export warning:** an exported file is plaintext outside the vault unless you separately protect it. Choose a secure destination and delete the exported copy when no longer needed. SecureUSB cannot guarantee that other applications, Windows indexing, backup software, or endpoint security tools will not retain copies.

**Open in another application:** this feature may create a temporary plaintext copy. Keep it disabled unless you understand the risk and explicitly need it. Close the other application and lock the vault after use.

## Integrity checks and recovery
Use the available vault health/integrity controls to check the vault. A quick check may not detect every form of silent corruption; use the full/deep check for a more thorough scan. If SecureUSB reports corruption or recovery is needed, stop writing to the drive and preserve a copy of the entire vault directory before attempting repair. Never run repair against the only copy of valuable data.

## Safely remove the USB
1. Lock the vault in SecureUSB.
2. Wait for any operation to finish.
3. Use Windows Safely Remove Hardware/Eject if available.
4. Disconnect only after Windows says it is safe.

## Troubleshooting
- **Wrong password/cooldown:** confirm keyboard layout and Caps Lock. Wait for the cooldown. There is no password reset.
- **Drive not listed:** reconnect the drive, confirm it appears in File Explorer, and check that Windows has assigned it a drive letter. Do not format the drive if it contains data.
- **Unexpected error:** note the safe message shown, lock the vault if possible, and preserve the drive contents. Do not post passwords, private files, or decrypted content in bug reports.
- **App does not start:** use a Windows 10/11 x64 PC and obtain a fresh package from a trusted source. This unsigned candidate release may trigger SmartScreen.

## Important limitations
This is a release candidate, not a security certification. It does not protect against a compromised computer, keyloggers, screen capture, an administrator or malware with access to the running process, physical coercion, or all forensic recovery of plaintext from the host. Password loss can be permanent. Test with noncritical data until the final release has been independently reviewed.
