# Step 1 — Cryptographic design (V1: single password)

## Key hierarchy
```
password ──Argon2id(salt, m,t,p)──► KEK (256-bit)
                                     │ AES-256-GCM, AAD = header bytes 0..70
                                     ▼
                         wrapped Master Key (stored in vault.hdr)
Master Key (random, 256-bit) ──HKDF-SHA256(salt = vaultId, info = label)──► subkeys:
     "SecureUSB/v1/index"           encrypts the file index
     "SecureUSB/v1/activity-log"    encrypts the activity log
     "SecureUSB/v1/file-key-wrap"   wraps per-file keys
per-file random key (256-bit) ──► ChunkedFileCipher (AES-256-GCM, 1 MiB chunks)
```
The password never encrypts data directly, so changing it never touches file blobs.

## vault.hdr (131 bytes, big-endian)
| Offset | Size | Field |
|---|---|---|
| 0 | 8 | magic `SUSBVLT1` |
| 8 | 2 | format version (1) |
| 10 | 16 | vault ID (random, unique per USB) |
| 26 | 1 | KDF id (1 = Argon2id) |
| 27 / 31 / 35 | 4 each | memory KiB / iterations / parallelism |
| 39 | 32 | salt |
| 71 | 60 | wrapped MK: nonce(12) ‖ ciphertext(32) ‖ tag(16) |

Bytes 0–70 are AES-GCM associated data for the wrapped key. Changing vault ID, salt, version or KDF cost
makes unlock fail. KDF parameters are bounds-checked on parse (8 MiB–1 GiB, 1–16 passes, 1–16 lanes) so a
malicious header cannot cause a memory/CPU denial of service.

## Encrypted file stream
```
"SUSBFIL1"(8) | chunkSize u32(4) | nonce prefix(8)            = 20-byte header
[ciphertext ≤ chunkSize | tag(16)] × N
nonce = prefix(8) ‖ chunkIndex u32(4)
AAD   = header(20) ‖ vaultId(16) ‖ fileId(16) ‖ chunkIndex(4) ‖ isFinal(1)
```
Detected by tests: any single-byte change, truncation at every possible length (including exact chunk
boundaries), appended data, reordered/duplicated chunks, wrong key, ciphertext moved to another file or vault.
**Rule for callers:** `Decrypt` emits each chunk after it authenticates, but a later chunk can still fail, so on
any exception delete the partial output and never open it.

## Why "wrong password" and "tampered header" look the same
Both fail the GCM tag check. The UI must say "wrong password or damaged vault" — it cannot tell which.

## What Step 1 does NOT protect against
* **Offline guessing of a weak password.** An attacker with a copy of the USB attacks `vault.hdr` directly;
  the app's login rate limiter (Step 3) does not apply. Defenses: Argon2id cost and `PasswordPolicy`.
* **Malware / keyloggers / memory dumps on the host PC** while the vault is unlocked.
* **A replaced SecureUSB.exe** that captures your password. Only run a signed, hash-verified executable.
* **Rollback** to an older consistent copy of the whole vault.
* .NET `string` passwords and the Unicode-normalized copy cannot be zeroed; only byte buffers and keys are wiped.
* This is a normal USB drive: no hardware key, no hardware-enforced anything. Anyone holding the drive can copy every file.

## Future enterprise features (not in V1)
Optional organization key / second factor (new header format version, key mixed into the KDF via HKDF),
recovery escrow wrapped to an organization public key and disclosed in the UI, Authenticode-signed builds,
central policy. None of these exist in V1, and the V1 header has no fields reserved for them.
